import { randomUUID } from 'node:crypto';
import { mkdir, readFile, writeFile, rename } from 'node:fs/promises';
import path from 'node:path';

const file = path.resolve(process.cwd(), '.skillquest-private', 'demo-chat.json');
let writes = Promise.resolve();
async function readStore() {
  try { return JSON.parse(await readFile(file, 'utf8')); }
  catch (error) { if (error.code === 'ENOENT') return { sessions: {}, members: {}, messages: {} }; throw error; }
}
async function mutate(change) {
  const task = writes.then(async () => {
    const store = await readStore();
    const result = change(store);
    await mkdir(path.dirname(file), { recursive: true });
    const temp = `${file}.${randomUUID()}.tmp`;
    await writeFile(temp, JSON.stringify(store), { mode: 0o600 });
    await rename(temp, file);
    return result;
  });
  writes = task.catch(() => {});
  return task;
}
const send = (res, code, value, extra = {}) => { res.writeHead(code, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store', ...extra }); res.end(JSON.stringify(value)); };
const sessionId = req => /(?:^|;\s*)sq_demo_session=([a-f0-9-]{36})/.exec(req.headers.cookie || '')?.[1];
export function chatMiddleware(req, res, next) {
  if (!req.url?.startsWith('/api/chat/')) return next();
  void (async () => {
    if (req.headers.origin && req.headers.origin !== `http://${req.headers.host}` && req.headers.origin !== `https://${req.headers.host}`) return send(res, 403, { error: 'Origin rejected.' });
    const match = /^\/api\/chat\/([a-zA-Z0-9_-]{1,80})\/(join|leave|messages)$/.exec(req.url.split('?')[0]);
    if (!match && req.url !== '/api/chat/session') return send(res, 404, { error: 'Unknown chat endpoint.' });
    let body = {};
    if (req.method === 'POST') {
      let raw = '';
      for await (const chunk of req) { raw += chunk; if (Buffer.byteLength(raw) > 4096) return send(res, 413, { error: 'Message too long.' }); }
      try { body = raw ? JSON.parse(raw) : {}; } catch { return send(res, 400, { error: 'Invalid request.' }); }
    }
    if (req.url === '/api/chat/session' && req.method === 'GET') {
      await writes; const s = await readStore(); const id = sessionId(req);
      return id && s.sessions[id] ? send(res, 200, { mode: 'shared local demo', name: s.sessions[id].name }) : send(res, 401, { error: 'No demo session.' });
    }
    if (req.url === '/api/chat/session' && req.method === 'POST') {
      const id = randomUUID();
      const name = typeof body.name === 'string' ? body.name.trim().slice(0, 60) : '';
      if (!name) return send(res, 400, { error: 'A demo display name is required.' });
      await mutate(s => { s.sessions[id] = { name, avatar: typeof body.avatar === 'string' && /^https:\/\//.test(body.avatar) ? body.avatar.slice(0, 400) : '', createdAt: new Date().toISOString() }; });
      return send(res, 200, { mode: 'shared local demo', name }, { 'Set-Cookie': `sq_demo_session=${id}; HttpOnly; SameSite=Strict; Path=/api/chat${req.socket.encrypted ? '; Secure' : ''}` });
    }
    await writes;
    const store = await readStore();
    const id = sessionId(req);
    if (!id || !store.sessions[id]) return send(res, 401, { error: 'Demo session expired. Reopen the chat.' });
    const action = match[2];
    const cohortId = match[1];
    const key = `${cohortId}:${id}`;
    if (action === 'join' && req.method === 'POST') { await mutate(s => { s.members[key] = true; }); return send(res, 200, { joined: true }); }
    if (action === 'leave' && req.method === 'POST') { await mutate(s => { delete s.members[key]; }); return send(res, 200, { joined: false }); }
    if (!store.members[key]) return send(res, 403, { error: 'Join this cohort to read or send messages.' });
    if (action === 'messages' && req.method === 'GET') return send(res, 200, { messages: (store.messages[cohortId] || []).map(({ senderId, ...m }) => ({ ...m, isOwn: senderId === id })) });
    if (action === 'messages' && req.method === 'POST') {
      const content = typeof body.content === 'string' ? body.content.trim() : '';
      if (!content || content.length > 1000) return send(res, 400, { error: 'Enter a message of 1 to 1000 characters.' });
      const message = await mutate(s => {
        if (!s.members[key]) throw new Error('Membership required.');
        const item = { id: randomUUID(), cohortId, senderId: id, senderName: s.sessions[id].name, avatar: s.sessions[id].avatar, content, sentAt: new Date().toISOString() };
        s.messages[cohortId] = [...(s.messages[cohortId] || []), item].slice(-500);
        return item;
      });
      const { senderId, ...publicMessage } = message;
      return send(res, 201, { message: { ...publicMessage, isOwn: true } });
    }
    return send(res, 405, { error: 'Method not allowed.' });
  })().catch(error => send(res, 500, { error: error.message || 'Chat unavailable.' }));
}
