import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { SkillQuestProvider } from './context/SkillQuestContext';
import { AppLayout } from './components/layout/AppLayout';
import { HomePage } from './pages/HomePage';
import { AuthPage } from './pages/AuthPage';
import { OnboardingPage } from './pages/OnboardingPage';
import { DashboardPage } from './pages/DashboardPage';
import { RoadmapPage } from './pages/RoadmapPage';
import { QuestsPage } from './pages/QuestsPage';
import { AchievementsPage } from './pages/AchievementsPage';
import { StreaksPage } from './pages/StreaksPage';
import { ResourcesPage } from './pages/ResourcesPage';
import { CohortsPage } from './pages/CohortsPage';
import { AnalyticsPage } from './pages/AnalyticsPage';
import { QuizPage } from './pages/QuizPage';
import { HomeworkPage } from './pages/HomeworkPage';
import { ProjectsPage } from './pages/ProjectsPage';
import { NotesPage } from './pages/NotesPage';
import { GoalsPage } from './pages/GoalsPage';

export const App: React.FC = () => {
  return (
    <SkillQuestProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<AppLayout />}>
            <Route index element={<HomePage />} />
            <Route path="login" element={<AuthPage />} />
            <Route path="signup" element={<AuthPage />} />
            <Route path="onboarding" element={<OnboardingPage />} />
            <Route path="dashboard" element={<DashboardPage />} />
            <Route path="goals" element={<GoalsPage />} />
            <Route path="roadmap" element={<RoadmapPage />} />
            <Route path="quests" element={<QuestsPage />} />
            <Route path="quiz" element={<QuizPage />} />
            <Route path="homework" element={<HomeworkPage />} />
            <Route path="projects" element={<ProjectsPage />} />
            <Route path="notes" element={<NotesPage />} />
            <Route path="achievements" element={<AchievementsPage />} />
            <Route path="streaks" element={<StreaksPage />} />
            <Route path="resources" element={<ResourcesPage />} />
            <Route path="cohorts" element={<CohortsPage />} />
            <Route path="analytics" element={<AnalyticsPage />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </SkillQuestProvider>
  );
};

export default App;
