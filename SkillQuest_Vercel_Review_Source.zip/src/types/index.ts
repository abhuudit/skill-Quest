export interface User {
  id: string;
  name: string;
  email: string;
  avatar: string;
  role: string;
  currentXP: number;
  currentLevel: number;
  currentStreak: number;
  assignmentXP?: number;
  projectXP?: number;
  longestStreak: number;
  lastActiveDate: string; // ISO string
  streakFrozen: boolean;
  learningPreferences: {
    dailyMinutes: number;
    preferredTime: 'morning' | 'afternoon' | 'evening' | 'flexible';
    notificationReminder: boolean;
  };
  settings: {
    soundEffects: boolean;
    demoMode: boolean;
    geminiApiKey: string;
    optInLeaderboard: boolean;
    theme?: 'light' | 'dark' | 'system';
    timeZone?: string;
  };
}

export type ProficiencyLevel = 'Beginner' | 'Intermediate' | 'Advanced';
export type TargetProficiency = 'Intermediate' | 'Advanced' | 'Mastery';

export interface LearningGoal {
  id: string;
  userId: string;
  skill: string;
  displayName?: string;
  status?: 'active' | 'completed' | 'archived';
  currentLevel: ProficiencyLevel;
  targetLevel: TargetProficiency;
  availableTime: string; // e.g. "30 minutes per day"
  daysPerWeek?: number;
  availableDays?: string[];
  deadline: string; // e.g. "3 months"
  targetDate: string; // YYYY-MM-DD
  schedulePreference: string;
  motivation: string;
  overallProgress: number; // 0 - 100
  isAiGenerated: boolean;
  createdAt: string;
  updatedAt: string;
}

export type MilestoneStatus = 'locked' | 'in-progress' | 'completed';

export interface Milestone {
  id: string;
  goalId: string;
  title: string;
  description: string;
  sequence: number;
  status: MilestoneStatus;
  criteria: string[];
  estimatedWeeks: number;
  completedAt?: string;
}

export type QuestDifficulty = 'Beginner' | 'Intermediate' | 'Medium' | 'Advanced';
export type QuestStatus = 'todo' | 'in-progress' | 'completed';

export type SubmissionType = 'code' | 'image' | 'video' | 'audio' | 'text' | 'document' | 'url';
export type EvaluationStatus = 'pending' | 'under_evaluation' | 'cleared' | 'needs_improvement' | 'submission_incomplete' | 'failed';

export interface RubricItem {
  id: string;
  criterion: string;
  description: string;
}

export interface EvaluationResult {
  status: EvaluationStatus;
  score: number; // 0 - 100
  criteriaMet: string[];
  criteriaNotMet: string[];
  feedback: string;
  suggestions: string[];
  recommendedNextAction: string;
  evaluatedAt: string;
  modelUsed?: string;
}

export interface QuestSubmission {
  id: string;
  questId: string;
  userId: string;
  attemptNumber: number;
  submissionType: SubmissionType;
  content: string; // submitted code, reflection text, or data URL / preview
  fileName?: string;
  fileSize?: string;
  submittedAt: string;
  evaluation?: EvaluationResult;
}

export interface BonusQuestion {
  id: string;
  questId: string;
  questionText: string;
  options: string[];
  correctAnswer: number; // 0-indexed index in options
  explanation: string;
  xpReward: number; // default 10 XP
  userAnswer?: number;
  isCorrect?: boolean;
}

export interface Quest {
  id: string;
  milestoneId: string;
  title: string;
  description: string;
  durationMinutes: number;
  difficulty: QuestDifficulty;
  xpReward: number;
  status: QuestStatus;
  isToday: boolean;
  scheduledDate?: string;
  completedAt?: string;
  reflection?: string;
  resourceTitle?: string;
  resourceUrl?: string;
  instructions: string[];
  isComebackQuest?: boolean;
  kind?: 'assignment' | 'midway';
  goalId?: string;
  sourceQuestId?: string;
  prerequisiteMilestoneIds?: string[];
  learningObjective?: string;
  projectObjectives?: string[];
  skillsAssessed?: string[];
  optionalEnhancements?: string[];

  // Practical skill evaluation properties
  submissionType: SubmissionType;
  submissionRequirements: string;
  rubric: RubricItem[];
  submissions: QuestSubmission[];
  latestEvaluation?: EvaluationResult;
  evaluationStatus?: EvaluationStatus;
  evaluationScore?: number;
  evaluationFeedback?: string;

  // Bonus Questions
  bonusQuestions?: BonusQuestion[];
  bonusCompleted?: boolean;
  bonusXpEarned?: number;
}

export interface Achievement {
  id: string;
  name: string;
  description: string;
  category: 'quest' | 'streak' | 'milestone' | 'consistency' | 'comeback' | 'xp';
  icon: string;
  earned: boolean;
  earnedAt?: string;
  xpReward: number;
  criteria: string;
}

export type ResourceType = 'video' | 'article' | 'course' | 'documentation' | 'project';

export interface LearningResource {
  id: string;
  title: string;
  description: string;
  provider: string;
  url: string;
  resourceType: ResourceType;
  difficulty: QuestDifficulty;
  duration: string;
  skill: string;
  saved: boolean;
  completed: boolean;
  isDemoResource?: boolean;
  associatedMilestoneSequence?: number;
}

export interface Cohort {
  id: string;
  name: string;
  skill: string;
  membersCount: number;
  description: string;
  isJoined: boolean;
  weeklyChallenge: {
    title: string;
    targetQuests: number;
    currentCompleted: number;
    rewardXP: number;
    daysLeft: number;
  };
  cohortProgress: number; // 0 - 100
  topMembers: { name: string; avatar: string; xp: number }[];
}

export interface LeaderboardUser {
  id: string;
  rank: number;
  name: string;
  avatar: string;
  skill: string;
  xpEarned: number;
  streak: number;
  completedQuests: number;
  isCurrentUser: boolean;
  badge: string;
}

export interface DailyActivity {
  date: string; // YYYY-MM-DD
  count: number; // completed quests
  xp: number;
  level: number; // 0 to 4 intensity for heatmap
}

export interface ComebackPlan {
  id: string;
  active: boolean;
  missedDays: number;
  message: string;
  suggestedSchedule: string;
  dailyQuests: Quest[];
  generatedAt: string;
}

export type TopicCategory = 'core' | 'additional' | 'advanced' | 'project';

export interface Topic {
  id: string;
  skill: string;
  name: string;
  category: TopicCategory;
  description: string;
  difficulty: QuestDifficulty;
  estimatedDuration: string;
  recommendedResources: { title: string; url: string; provider: string }[];
  practicalExercise: string;
  isAddedToRoadmap: boolean;
  practicalQuestTemplate?: Partial<Quest>;
}

export interface QuizQuestion {
  id: string;
  skill: string;
  milestoneSequence: number;
  questionText: string;
  codeSnippet?: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
  difficulty: QuestDifficulty;
  xpReward: number;
}

export interface QuizResult {
  id: string;
  skill: string;
  score: number;
  totalQuestions: number;
  xpEarned: number;
  date: string;
  answers: Record<string, number>;
}

export interface DailyQuizRecord {
  id: string;
  userId: string;
  goalId: string;
  localDate: string;
  questions: QuizQuestion[];
  source?: 'ai' | 'learning-plan-review';
  answers: Record<string, number>;
  score?: number;
  completedAt?: string;
  xpEarned?: number;
}

export interface NoteReviewIssue {
  passage: string;
  category: 'incorrect' | 'clarify' | 'correct' | 'unverified';
  explanation: string;
  suggestedCorrection: string;
  whyItMatters: string;
  decision?: 'accepted' | 'rejected';
}

export interface NoteReview {
  summary: string;
  issues: NoteReviewIssue[];
  reviewedAt: string;
  modelUsed?: string;
}

export interface PdfNoteReview {
  summary: string;
  pages: { pageNumber: number; status: 'readable' | 'partial' | 'unreadable'; extractedText: string; message: string }[];
  issues: (NoteReviewIssue & { pageNumber: number })[];
  reviewedAt: string;
  modelUsed?: string;
}

export interface PdfNoteVersion {
  id: string;
  fileName: string;
  fileSize: number;
  uploadedAt: string;
  review?: PdfNoteReview;
  reviewHistory?: PdfNoteReview[];
  reviewError?: string;
}

export interface LearningNote {
  id: string;
  userId: string;
  goalId?: string;
  skill: string;
  title: string;
  topic: string;
  questId?: string;
  resourceId?: string;
  context: string;
  content: string;
  createdAt: string;
  updatedAt: string;
  review?: NoteReview;
  reviewError?: string;
  revisions: { content: string; savedAt: string }[];
  pdfVersions?: PdfNoteVersion[];
}

export interface PortfolioEntry {
  id: string;
  userId: string;
  questId: string;
  goalId: string;
  title: string;
  description: string;
  skills: string[];
  tools: string;
  outcome: string;
  evidenceLink?: string;
  completedAt: string;
  savedAt: string;
}
