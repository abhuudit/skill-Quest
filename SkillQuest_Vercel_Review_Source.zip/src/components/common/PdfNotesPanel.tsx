import React, { useEffect, useRef, useState } from 'react';
import { LearningNote, PdfNoteVersion } from '../../types';
import { useSkillQuest } from '../../context/SkillQuestContext';
import { reviewPdfLearningNotes } from '../../services/geminiService';
import { PUBLIC_REVIEW_MODE } from '../../utils/reviewMode';
import { fileAsDataUrl, loadPdfFile, MAX_PDF_NOTE_BYTES, savePdfFile, validatePdfFile } from '../../utils/pdfNoteStorage';

interface Props {
  active?: LearningNote;
  ensureNote: () => LearningNote;
  userId: string;
  skill: string;
  context: string;
}

export const PdfNotesPanel: React.FC<Props> = ({ active, ensureNote, userId, skill, context }) => {
  const { addPdfNoteVersion, setPdfNoteReview } = useSkillQuest();
  const input = useRef<HTMLInputElement>(null);
  const [file, setFile] = useState<File | null>(null);
  const [selectedVersionId, setSelectedVersionId] = useState<string | null>(null);
  const [previewUrl, setPreviewUrl] = useState('');
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');
  const versions = active?.pdfVersions || [];
  const selectedVersion = versions.find(v => v.id === selectedVersionId) || versions.at(-1);

  useEffect(() => { setFile(null); setSelectedVersionId(active?.pdfVersions?.at(-1)?.id || null); setError(''); setMessage(''); }, [active?.id]);
  useEffect(() => {
    let cancelled = false;
    let url = '';
    const source = file ? Promise.resolve(file as Blob) : active && selectedVersion ? loadPdfFile(userId, active.id, selectedVersion.id) : Promise.resolve(null);
    void source.then(blob => {
      if (cancelled) return;
      if (!blob) { setPreviewUrl(''); if (selectedVersion) setError('The saved PDF is missing from this browser.'); return; }
      url = URL.createObjectURL(blob); setPreviewUrl(url);
    }).catch(err => { if (!cancelled) setError(err instanceof Error ? err.message : 'PDF preview is unavailable.'); });
    return () => { cancelled = true; if (url) URL.revokeObjectURL(url); };
  }, [file, active?.id, selectedVersion?.id, userId]);

  const chooseFile = async (candidate?: File) => {
    if (!candidate) return;
    try { await validatePdfFile(candidate); setFile(candidate); setError(''); setMessage(''); setProgress(0); }
    catch (err) { setFile(null); setError(err instanceof Error ? err.message : 'Invalid PDF.'); }
  };

  const saveSelected = async (): Promise<{ note: LearningNote; version: PdfNoteVersion; blob: Blob }> => {
    if (!file) throw new Error('Choose a PDF first.');
    await validatePdfFile(file);
    const note = ensureNote();
    const version: PdfNoteVersion = { id: `pdf_${crypto.randomUUID()}`, fileName: file.name, fileSize: file.size, uploadedAt: new Date().toISOString() };
    await savePdfFile(userId, note.id, version.id, file);
    addPdfNoteVersion(note.id, version);
    setSelectedVersionId(version.id); setFile(null);
    return { note, version, blob: file };
  };

  const save = async () => {
    setBusy(true); setError('');
    try { await saveSelected(); setMessage('PDF saved to your Notes library.'); }
    catch (err) { setError(err instanceof Error ? err.message : 'The PDF could not be saved.'); }
    finally { setBusy(false); }
  };

  const review = async () => {
    setBusy(true); setError(''); setMessage(''); setProgress(0);
    let note: LearningNote | undefined;
    let version: PdfNoteVersion | undefined;
    try {
      let blob: Blob | null;
      if (file) ({ note, version, blob } = await saveSelected());
      else { note = active; version = selectedVersion; blob = note && version ? await loadPdfFile(userId, note.id, version.id) : null; }
      if (!note || !version || !blob) throw new Error('Choose or reopen a saved PDF before review.');
      setMessage('Reading the PDF and reviewing its pages…');
      const content = await fileAsDataUrl(blob, setProgress);
      const result = await reviewPdfLearningNotes(content, context || note.context, skill || note.skill);
      setPdfNoteReview(note.id, version.id, result);
      setMessage('Review complete. Check each page and any uncertain handwriting.');
    } catch (err) {
      const detail = err instanceof Error ? err.message : 'PDF review is unavailable.';
      if (note && version) setPdfNoteReview(note.id, version.id, undefined, detail);
      setError(detail);
    } finally { setBusy(false); }
  };

  const grouped = selectedVersion?.review?.issues || [];
  const groups = [
    { label: 'What looks correct', category: 'correct' },
    { label: 'Possible corrections', category: 'incorrect' },
    { label: 'Needs clarification', category: 'clarify' },
    { label: 'Uncertain content', category: 'unverified' },
  ] as const;

  return <div className="space-y-4 min-w-0">
    <div><h2 className="text-lg font-bold text-slate-900">Upload Handwritten Notes (PDF)</h2><p className="text-xs text-slate-600">Add a scan of your notes to this skill and topic. PDFs up to {MAX_PDF_NOTE_BYTES / 1024 / 1024} MB are stored in this browser.</p></div>
    <div onDragOver={event => event.preventDefault()} onDrop={event => { event.preventDefault(); void chooseFile(event.dataTransfer.files[0]); }} className="border-2 border-dashed border-slate-300 rounded-2xl p-5 text-center space-y-2 bg-slate-50">
      <p className="text-sm font-semibold text-slate-800">Drag and drop a PDF here</p>
      <button type="button" onClick={() => input.current?.click()} className="px-4 py-2 rounded-xl bg-brand-600 text-white text-sm font-bold">{file ? 'Replace File' : 'Select PDF file'}</button>
      <input ref={input} type="file" accept=".pdf,application/pdf" className="sr-only" onChange={event => { void chooseFile(event.target.files?.[0]); event.target.value = ''; }} />
    </div>
    {file && <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-slate-200 p-3 text-sm"><span className="min-w-0 break-all font-semibold">{file.name} · {(file.size / 1024 / 1024).toFixed(2)} MB</span><button onClick={() => setFile(null)} className="text-rose-700 font-bold">Remove File</button></div>}
    {busy && <div role="status" className="text-xs text-brand-700">{message || 'Working…'} {progress ? `Reading ${progress}%` : ''}</div>}
    {error && <p role="alert" className="rounded-xl bg-rose-50 text-rose-700 p-3 text-sm break-words">{error}</p>}
    {!busy && message && <p role="status" className="text-sm text-emerald-700">{message}</p>}
    <div className="flex flex-wrap gap-2"><button onClick={() => void save()} disabled={!file || busy} className="px-4 py-2 border border-brand-300 text-brand-700 rounded-xl text-sm font-bold disabled:opacity-50">Save PDF to Notes</button><button onClick={() => void review()} disabled={PUBLIC_REVIEW_MODE || (!file && !selectedVersion) || busy} className="px-4 py-2 bg-brand-600 text-white rounded-xl text-sm font-bold disabled:opacity-50">{busy ? 'Reviewing…' : 'Submit for AI Review'}</button></div>
    {versions.length > 0 && <div className="space-y-2"><h3 className="text-sm font-bold text-slate-900">Saved PDF versions</h3><div className="flex flex-wrap gap-2">{versions.map((version, index) => <button key={version.id} onClick={() => { setFile(null); setSelectedVersionId(version.id); setError(''); }} className={`px-3 py-2 rounded-xl border text-xs font-semibold max-w-full break-all ${selectedVersion?.id === version.id && !file ? 'bg-brand-50 border-brand-400 text-brand-700' : 'border-slate-300 text-slate-700'}`}>Version {index + 1}: {version.fileName} · {new Date(version.uploadedAt).toLocaleDateString()}</button>)}</div></div>}
    {previewUrl && <div className="space-y-2"><div className="flex flex-wrap justify-between gap-2 text-xs text-slate-600"><span>{file?.name || selectedVersion?.fileName} · {((file?.size || selectedVersion?.fileSize || 0) / 1024 / 1024).toFixed(2)} MB</span><a href={previewUrl} target="_blank" rel="noreferrer" className="font-bold text-brand-700">Open PDF in new tab</a></div><iframe title="Handwritten PDF preview" src={previewUrl} className="w-full h-72 sm:h-96 rounded-xl border border-slate-300 bg-white" /></div>}
    {selectedVersion?.reviewError && <p role="alert" className="text-sm text-rose-700">{selectedVersion.reviewError}</p>}
    {Boolean(selectedVersion?.reviewHistory?.length) && <details className="rounded-xl border border-slate-200 p-3 text-xs text-slate-600"><summary className="cursor-pointer font-bold text-slate-900">Earlier reviews of this version ({selectedVersion!.reviewHistory!.length})</summary>{selectedVersion!.reviewHistory!.map((past, index) => <div key={index} className="pt-2"><strong>{new Date(past.reviewedAt).toLocaleString()}</strong><p>{past.summary}</p></div>)}</details>}
    {selectedVersion?.review && <section className="space-y-4 border-t border-slate-200 pt-4"><h3 className="text-base font-bold text-slate-900">PDF review · {new Date(selectedVersion.review.reviewedAt).toLocaleString()}</h3><p className="text-sm text-slate-700">{selectedVersion.review.summary}</p><div className="grid sm:grid-cols-2 gap-2">{selectedVersion.review.pages.map(page => <div key={page.pageNumber} className="rounded-xl bg-slate-50 border border-slate-200 p-3 text-xs"><strong className="text-slate-900">Page {page.pageNumber} · {page.status}</strong><p className="text-slate-600 break-words">{page.message || (page.status === 'unreadable' ? 'Upload a clearer scan of this page.' : 'Readable text extracted.')}</p>{page.extractedText && <details className="mt-1"><summary className="cursor-pointer text-brand-700 font-bold">View extracted text</summary><p className="whitespace-pre-wrap break-words mt-1 text-slate-700">{page.extractedText}</p></details>}</div>)}</div>{groups.map(group => <div key={group.category} className="space-y-2"><h4 className="text-sm font-bold text-slate-900">{group.label}</h4>{!grouped.some(issue => issue.category === group.category) && <p className="text-xs text-slate-500">No observations in this group.</p>}{grouped.filter(issue => issue.category === group.category).map((issue, index) => <div key={`${issue.pageNumber}-${index}`} className="p-3 rounded-xl border border-slate-200 bg-slate-50 text-sm space-y-1"><p className="font-semibold text-slate-900">Page {issue.pageNumber}{issue.passage ? ` · “${issue.passage}”` : ''}</p><p className="text-slate-700">{issue.explanation}</p>{issue.suggestedCorrection && <p className="text-slate-700">Suggestion: {issue.suggestedCorrection}</p>}<p className="text-xs text-slate-600">{issue.whyItMatters}</p></div>)}</div>)}</section>}
  </div>;
};
