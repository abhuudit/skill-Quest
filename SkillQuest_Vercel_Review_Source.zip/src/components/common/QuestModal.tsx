import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Quest, SubmissionType, EvaluationResult } from '../../types';
import { useSkillQuest } from '../../context/SkillQuestContext';
import { PUBLIC_REVIEW_MODE } from '../../utils/reviewMode';
import {
  X,
  Clock,
  Zap,
  CheckCircle2,
  ExternalLink,
  BookOpen,
  Sparkles,
  Upload,
  FileCode,
  FileText,
  Video,
  Image,
  AlertTriangle,
  RotateCcw,
  Check,
  ChevronDown,
  ChevronUp,
  History,
  HelpCircle,
  FileUp,
  Loader2,
  Trash2,
  ArrowRight
} from 'lucide-react';

interface QuestModalProps {
  quest: Quest | null;
  isOpen: boolean;
  onClose: () => void;
}

export const QuestModal: React.FC<QuestModalProps> = ({ quest, isOpen, onClose }) => {
  const { submitQuestForEvaluation, answerBonusQuestion, quests, milestones } = useSkillQuest();

  // Tab State
  const [activeTab, setActiveTab] = useState<'task' | 'submit' | 'bonus' | 'history'>('task');

  // Submission State
  const [submissionType, setSubmissionType] = useState<SubmissionType>('code');
  const [textContent, setTextContent] = useState('');
  const [uploadedFile, setUploadedFile] = useState<{ name: string; size: string; dataUrl: string; type: string } | null>(null);
  const [isEvaluating, setIsEvaluating] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadError, setUploadError] = useState('');
  const [evalResult, setEvalResult] = useState<EvaluationResult | null>(quest?.latestEvaluation || null);

  // Bonus Questions State
  const [bonusSelected, setBonusSelected] = useState<Record<string, number>>({});

  useEffect(() => {
    setActiveTab('task'); setTextContent(''); setUploadedFile(null);
    setEvalResult(quest?.latestEvaluation || null); setUploadError(''); setUploadProgress(0);
    setBonusSelected({});
  }, [quest?.id, isOpen]);

  if (!isOpen || !quest) return null;

  quest = quests.find(q => q.id === quest.id) || quest;

  const isCompleted = quest.status === 'completed';
  const rubric = quest.rubric || [];
  const submissions = quest.submissions || [];

  // Initialize submission type from quest default if available
  const currentSubmissionType = uploadedFile ? (uploadedFile.type.startsWith('image/') ? 'image' : uploadedFile.type.startsWith('video/') ? 'video' : uploadedFile.type.startsWith('audio/') ? 'audio' : uploadedFile.type === 'application/pdf' ? 'document' : 'code') : (quest.submissionType === 'code' ? 'code' : 'text');

  const handleFileUpload = (file?: File) => {
    if (!file) return;
    setUploadError(''); setUploadProgress(0);
    if (file.size > 8 * 1024 * 1024 || file.size === 0) {
      setUploadError('Choose a file between 1 byte and 8 MB.');
      return;
    }
    const supported = ['image/png', 'image/jpeg', 'image/webp', 'video/mp4', 'video/webm', 'audio/mpeg', 'audio/mp3', 'audio/wav', 'application/pdf', 'text/plain', 'text/html', 'text/css', 'text/javascript', 'application/json'];
    if (!supported.includes(file.type) && !/\.(js|ts|tsx|jsx|txt|html|css|json|md)$/i.test(file.name)) {
      setUploadError('Use PNG, JPG, WebP, MP4, WebM, PDF, or a source/text file. Archives cannot be evaluated.');
      return;
    }

    const sizeStr = file.size < 1024 * 1024
      ? `${(file.size / 1024).toFixed(1)} KB`
      : `${(file.size / (1024 * 1024)).toFixed(1)} MB`;

    const reader = new FileReader();
    reader.onprogress = event => { if (event.lengthComputable) setUploadProgress(Math.round(event.loaded / event.total * 100)); };
    reader.onerror = () => setUploadError('The file could not be read. Please try again.');
    reader.onload = (event) => {
      setUploadedFile({
        name: file.name,
        size: sizeStr,
        dataUrl: event.target?.result as string,
        type: file.type,
      });
      setUploadProgress(100);
    };
    if (/^(text\/|application\/json)/.test(file.type) || /\.(js|ts|tsx|jsx|md)$/i.test(file.name)) reader.readAsText(file);
    else reader.readAsDataURL(file);
  };

  const handleRemoveFile = () => {
    setUploadedFile(null);
  };

  const handleSubmitEvidence = async () => {
    const content = uploadedFile?.dataUrl || textContent;

    if (!content.trim() && !uploadedFile) {
      alert('Please provide code/text or select a file to submit.');
      return;
    }

    setIsEvaluating(true);
    setEvalResult(null);

    try {
      const result = await submitQuestForEvaluation(quest.id, {
        submissionType: currentSubmissionType,
        content: uploadedFile ? uploadedFile.dataUrl : textContent,
        fileName: uploadedFile?.name,
        fileSize: uploadedFile?.size,
      });

      setEvalResult(result);
    } catch (err: any) {
      console.error('Submission failed', err);
      setUploadError(err instanceof Error ? err.message : 'Evaluation failed. Please try again.');
    } finally {
      setIsEvaluating(false);
    }
  };

  const handleAnswerBonus = (questionId: string, optionIdx: number) => {
    setBonusSelected(prev => ({ ...prev, [questionId]: optionIdx }));
    answerBonusQuestion(quest.id, questionId, optionIdx);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-900/60 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white rounded-3xl shadow-2xl max-w-2xl w-full min-w-0 overflow-hidden border border-slate-100 flex flex-col max-h-[calc(100dvh-1rem)] sm:max-h-[calc(100dvh-2rem)]">
        {/* Header */}
        <div className="p-6 border-b border-slate-100 flex items-start justify-between bg-gradient-to-r from-slate-50 to-white dark:from-slate-800 dark:to-slate-900">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className={`px-2.5 py-0.5 rounded-full text-xs font-semibold ${
                quest.difficulty === 'Beginner' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' :
                quest.difficulty === 'Intermediate' ? 'bg-blue-50 text-blue-700 border border-blue-200' :
                'bg-purple-50 text-purple-700 border border-purple-200'
              }`}>
                {quest.difficulty}
              </span>
              <span className="flex items-center gap-1 text-xs font-medium text-slate-500">
                <Clock className="w-3.5 h-3.5" />
                {quest.durationMinutes} mins
              </span>
              <span className="text-xs text-slate-500">{milestones.find(m => m.id === quest.milestoneId)?.title || 'Learning milestone'}</span>
              {quest.scheduledDate && <span className="text-xs text-slate-500">Planned: {quest.scheduledDate}</span>}
              <span className="flex items-center gap-1 text-xs font-semibold text-brand-600 bg-brand-50 px-2 py-0.5 rounded-full border border-brand-200">
                <Zap className="w-3 h-3 fill-brand-600" />
                +{quest.xpReward} {quest.kind === 'assignment' ? 'assignment' : quest.kind === 'midway' ? 'project' : 'quest'} XP
              </span>
              {isCompleted && (
                <span className="text-[10px] font-extrabold text-emerald-700 bg-emerald-100 px-2.5 py-0.5 rounded-full">
                  ✓ Cleared
                </span>
              )}
            </div>
            <h3 className="text-xl font-black text-slate-900 leading-snug">
              {quest.title}
            </h3>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1 px-6 pt-3 border-b border-slate-100 bg-slate-50/60 text-xs font-bold">
          <button
            onClick={() => setActiveTab('task')}
            className={`pb-2.5 px-3 border-b-2 transition-all ${
              activeTab === 'task' ? 'border-brand-600 text-brand-600' : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            1. Task Briefing & Rubric
          </button>
          <button
            onClick={() => setActiveTab('submit')}
            className={`pb-2.5 px-3 border-b-2 transition-all flex items-center gap-1.5 ${
              activeTab === 'submit' ? 'border-brand-600 text-brand-600' : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            <span>2. Practical Submission</span>
            {evalResult?.status === 'cleared' && <span className="w-2 h-2 rounded-full bg-emerald-500" />}
          </button>
          {quest.bonusQuestions && quest.bonusQuestions.length > 0 && (
            <button
              onClick={() => setActiveTab('bonus')}
              className={`pb-2.5 px-3 border-b-2 transition-all flex items-center gap-1 ${
                activeTab === 'bonus' ? 'border-brand-600 text-brand-600' : 'border-transparent text-slate-500 hover:text-slate-900'
              }`}
            >
              <span>3. Bonus Questions</span>
              <span className="text-[10px] font-bold text-amber-600 bg-amber-50 px-1.5 rounded-full border border-amber-200">
                +{quest.bonusQuestions.length * 10} XP
              </span>
            </button>
          )}
          {submissions.length > 0 && (
            <button
              onClick={() => setActiveTab('history')}
              className={`pb-2.5 px-3 border-b-2 transition-all ${
                activeTab === 'history' ? 'border-brand-600 text-brand-600' : 'border-transparent text-slate-500 hover:text-slate-900'
              }`}
            >
              History ({submissions.length})
            </button>
          )}
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-6 text-sm text-slate-600">

          {/* TAB 1: TASK BRIEFING */}
          {activeTab === 'task' && (
            <div className="space-y-6 text-left animate-fadeIn">
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-1.5">Task Objective</h4>
                <p className="text-slate-800 text-sm leading-relaxed">{quest.description}</p>
                {quest.learningObjective && <p className="text-xs text-brand-700 mt-2">Learning objective: {quest.learningObjective}</p>}
                {quest.scheduledDate && <p className="text-xs text-slate-500 mt-1">Recommended completion: {quest.scheduledDate}</p>}
              </div>
              {quest.kind === 'midway' && <div className="p-4 rounded-2xl bg-brand-50 border border-brand-200 text-xs space-y-2"><h4 className="font-bold text-brand-800">Project objectives and assessed skills</h4><ul className="list-disc pl-5 text-slate-700">{quest.projectObjectives?.map((item,i) => <li key={i}>{item}</li>)}</ul><p>Skills: {quest.skillsAssessed?.join(', ')}</p><p>Optional enhancements: {quest.optionalEnhancements?.join(' ')}</p></div>}

              {quest.instructions && quest.instructions.length > 0 && (
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">Step-by-Step Action Plan</h4>
                  <ol className="space-y-2">
                    {quest.instructions.map((step, idx) => (
                      <li key={idx} className="flex items-start gap-2.5 text-xs text-slate-700">
                        <span className="flex-shrink-0 w-5 h-5 rounded-full bg-brand-50 text-brand-600 font-bold flex items-center justify-center border border-brand-200 mt-0.5">
                          {idx + 1}
                        </span>
                        <span className="mt-0.5">{step}</span>
                      </li>
                    ))}
                  </ol>
                </div>
              )}

              {/* Practical Evaluation Rubric */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-brand-600" />
                    AI Evaluation Rubric ({rubric.length} Criteria)
                  </h4>
                  <span className="text-[11px] font-semibold text-slate-500">Required for Quest Clearance</span>
                </div>

                <div className="space-y-2">
                  {rubric.map(item => (
                    <div key={item.id} className="p-2.5 rounded-xl bg-white border border-slate-200 text-xs flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-brand-600 flex-shrink-0 mt-0.5" />
                      <div>
                        <div className="font-bold text-slate-900">{item.criterion}</div>
                        <div className="text-[11px] text-slate-500">{item.description}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {quest.resourceUrl && (
                <div className="p-3.5 rounded-xl bg-indigo-50/50 border border-indigo-100 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-white border border-indigo-200 flex items-center justify-center text-brand-600 shadow-sm">
                      <BookOpen className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-[10px] text-slate-500 font-medium uppercase tracking-wider">Curated Study Reference</div>
                      <div className="text-xs font-bold text-slate-800 line-clamp-1">{quest.resourceTitle || 'Documentation'}</div>
                    </div>
                  </div>
                  <a
                    href={quest.resourceUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center gap-1 px-3 py-1.5 text-xs font-bold text-brand-600 hover:text-brand-700 hover:bg-brand-50 rounded-lg border border-brand-200 transition-colors"
                  >
                    <span>Read Guide</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              )}

              <div className="pt-2 flex justify-end">
                <Link to={`/notes?questId=${encodeURIComponent(quest.id)}`} onClick={onClose} className="mr-auto px-4 py-2.5 border border-brand-200 text-brand-700 rounded-xl text-xs font-bold">Take Notes</Link>
                <button
                  type="button"
                  onClick={() => setActiveTab('submit')}
                  className="flex items-center gap-1.5 px-5 py-2.5 bg-brand-600 hover:bg-brand-700 text-white rounded-xl text-xs font-bold transition-all shadow-md shadow-brand-500/20"
                >
                  <span>Ready to Submit Evidence</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* TAB 2: PRACTICAL SUBMISSION & EVALUATION */}
          {activeTab === 'submit' && (
            <div className="space-y-6 text-left animate-fadeIn">
              <div className="p-3.5 rounded-2xl bg-amber-50/70 border border-amber-200 text-xs space-y-1">
                <div className="font-bold text-amber-900 flex items-center gap-1.5">
                  <Upload className="w-4 h-4 text-amber-600" />
                  <span>Submission Requirement</span>
                </div>
                <p className="text-amber-800 leading-relaxed">
                  {quest.submissionRequirements || 'Submit your code, document, or upload visual evidence demonstrating your work.'}
                </p>
                <p className="text-amber-800">Recommended evidence: {quest.submissionType}. Written explanations alone may be insufficient for a physical or visual task.</p>
              </div>

              {/* Submission Mode: Code / Text vs File Upload */}
              <div className="space-y-3">
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-500">
                  Provide Your Practical Implementation
                </label>

                {/* Upload Zone */}
                <div onDragOver={e => e.preventDefault()} onDrop={e => { e.preventDefault(); handleFileUpload(e.dataTransfer.files[0]); }} className="border-2 border-dashed border-slate-200 rounded-2xl p-4 sm:p-6 text-center hover:border-brand-400 transition-colors bg-slate-50/50">
                  {uploadedFile ? (
                    <div className="flex items-center justify-between p-3 bg-white rounded-xl border border-slate-200 text-xs">
                      <div className="flex items-center gap-3">
                        <FileCode className="w-5 h-5 text-brand-600" />
                        <div className="text-left">
                          <div className="font-bold text-slate-800 line-clamp-1">{uploadedFile.name}</div>
                          <div className="text-[10px] text-slate-500">{uploadedFile.size}</div>
                        </div>
                      </div>
                      <button
                        onClick={handleRemoveFile}
                        className="p-1.5 text-rose-500 hover:bg-rose-50 rounded-lg transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                      {uploadedFile.type.startsWith('video/') && <video className="w-full max-h-48 mt-3 rounded-lg" controls src={uploadedFile.dataUrl} />}
                      {uploadedFile.type.startsWith('audio/') && <audio className="w-full mt-3" controls src={uploadedFile.dataUrl} />}
                      {uploadedFile.type.startsWith('image/') && <img className="max-h-48 mx-auto mt-3 rounded-lg" alt="Submission preview" src={uploadedFile.dataUrl} />}
                    </div>
                  ) : (
                    <div>
                      <FileUp className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                      <p className="text-xs font-bold text-slate-700">
                        Upload Project File, Screenshot, or Demonstration Video
                      </p>
                      <p className="text-[11px] text-slate-500 mt-0.5 mb-3">
                        Drop a file here or browse. PNG, JPG, WebP, MP4, WebM, MP3, WAV, PDF, or source/text (max 8 MB)
                      </p>
                      <label className="cursor-pointer inline-flex items-center gap-1.5 px-4 py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-700 hover:bg-slate-50 transition-colors shadow-sm">
                        <span>Browse Files</span>
                        <input
                          type="file"
                          onChange={e => handleFileUpload(e.target.files?.[0])}
                          className="hidden"
                          accept=".png,.jpg,.jpeg,.webp,.mp4,.webm,.mp3,.wav,.pdf,.txt,.js,.ts,.tsx,.jsx,.html,.css,.json,.md"
                        />
                      </label>
                    </div>
                  )}
                </div>
                {uploadProgress > 0 && uploadProgress < 100 && <div className="text-xs text-brand-600">Reading file: {uploadProgress}%</div>}
                {uploadError && <p role="alert" className="text-xs text-rose-700">{uploadError}</p>}

                {/* Text / Code Input Option */}
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-xs font-bold text-slate-700">Or Paste Code / Written Answer:</span>
                    <span className="text-[11px] text-slate-400 font-mono">{textContent.length} chars</span>
                  </div>
                  <textarea
                    value={textContent}
                    onChange={(e) => setTextContent(e.target.value)}
                    rows={5}
                    placeholder="Paste your implementation HTML/CSS/JS, query results, or step-by-step performance explanation..."
                    className="w-full p-3 text-xs font-mono rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-brand-500 text-slate-800"
                  />
                </div>
              </div>

              {/* Submit Button & Evaluation Trigger */}
              <div className="pt-2 flex items-center justify-between">
                <span className="text-[11px] text-slate-500">
                  {PUBLIC_REVIEW_MODE ? 'AI evaluation is unavailable in this review preview' : isEvaluating ? 'Evaluating with SkillQuest AI...' : 'AI checks evidence against all rubric criteria'}
                </span>

                <button
                  onClick={handleSubmitEvidence}
                  disabled={PUBLIC_REVIEW_MODE || isEvaluating || (!textContent.trim() && !uploadedFile)}
                  className="flex items-center gap-2 px-6 py-2.5 bg-brand-600 hover:bg-brand-700 text-white rounded-xl text-xs font-bold shadow-md shadow-brand-500/20 transition-all disabled:opacity-50"
                >
                  {isEvaluating ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Checking Rubric...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4" />
                      <span>Submit for AI Evaluation</span>
                    </>
                  )}
                </button>
              </div>

              {/* Loading State Animation */}
              {isEvaluating && (
                <div className="p-4 rounded-2xl bg-indigo-50/70 border border-indigo-200 text-xs text-indigo-900 space-y-2 animate-pulse">
                  <div className="flex items-center gap-2 font-bold">
                    <Loader2 className="w-4 h-4 animate-spin text-brand-600" />
                    <span>Your submission is being evaluated...</span>
                  </div>
                  <p className="text-slate-600 text-[11px] leading-relaxed">
                    SkillQuest is checking your evidence against this quest's rubric.
                  </p>
                </div>
              )}

              {/* Evaluation Result Display */}
              {evalResult && !isEvaluating && (
                <div className={`p-5 rounded-2xl border space-y-4 animate-fadeIn ${
                  evalResult.status === 'cleared'
                    ? 'bg-emerald-50/70 border-emerald-200 text-emerald-950'
                    : 'bg-amber-50/70 border-amber-200 text-amber-950'
                }`}>
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-2.5">
                      <div className={`w-8 h-8 rounded-xl flex items-center justify-center font-bold text-white ${
                        evalResult.status === 'cleared' ? 'bg-emerald-600' : 'bg-amber-600'
                      }`}>
                        {evalResult.status === 'cleared' ? '✓' : '!'}
                      </div>
                      <div>
                        <h4 className="text-sm font-black">
                          {evalResult.status === 'cleared' ? 'Quest Cleared & Verified!' : evalResult.status === 'failed' ? 'Evaluation Failed' : evalResult.status === 'submission_incomplete' ? 'Submission Incomplete' : 'Needs Improvement'}
                        </h4>
                        <div className="text-[11px] font-semibold text-slate-500">
                          Evaluation Score: <strong>{evalResult.score}/100</strong> • {new Date(evalResult.evaluatedAt).toLocaleTimeString()}
                        </div>
                      </div>
                    </div>

                    {evalResult.status === 'cleared' && (
                      <span className="text-xs font-extrabold text-emerald-700 bg-white px-3 py-1 rounded-full border border-emerald-200 shadow-sm">
                        +{quest.xpReward} {quest.kind === 'assignment' ? 'assignment' : quest.kind === 'midway' ? 'project' : 'quest'} XP Earned
                      </span>
                    )}
                  </div>

                  <p className="text-xs leading-relaxed text-slate-700">
                    {evalResult.feedback}
                  </p>
                  <p className="text-xs font-semibold">Next: {evalResult.recommendedNextAction}</p>

                  {/* Criteria Checklist Breakdown */}
                  <div className="space-y-1.5 pt-1">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block">
                      Rubric Criteria Breakdown
                    </span>
                    {evalResult.criteriaMet.map((c, i) => (
                      <div key={i} className="text-xs font-medium text-emerald-800 flex items-center gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                        <span>{c} (Satisfied)</span>
                      </div>
                    ))}
                    {evalResult.criteriaNotMet.map((c, i) => (
                      <div key={i} className="text-xs font-medium text-amber-900 flex items-center gap-1.5">
                        <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
                        <span>{c} (Missing or Incomplete)</span>
                      </div>
                    ))}
                  </div>

                  {evalResult.suggestions && evalResult.suggestions.length > 0 && (
                    <div className="p-3 bg-white/80 rounded-xl border border-slate-200 text-xs text-slate-700">
                      <strong>Coach Suggestion:</strong> {evalResult.suggestions[0]}
                    </div>
                  )}

                  {evalResult.status !== 'cleared' && (
                    <div className="pt-2 flex justify-end">
                      <button
                        onClick={() => {
                          setEvalResult(null);
                        }}
                        className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold transition-colors"
                      >
                        Try Again & Resubmit
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* TAB 3: BONUS QUESTIONS */}
          {activeTab === 'bonus' && quest.bonusQuestions && (
            <div className="space-y-6 text-left animate-fadeIn">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-brand-600">
                    Deeper Concept Understanding
                  </h4>
                  <p className="text-xs text-slate-500">
                    Optional bonus drills that test comprehension. Earn +10 XP per question, +25 bonus for all correct!
                  </p>
                </div>
                <div className="text-xs font-extrabold text-amber-600 bg-amber-50 px-2.5 py-1 rounded-full border border-amber-200">
                  Earned: +{quest.bonusXpEarned || 0} XP
                </div>
              </div>

              <div className="space-y-4">
                {quest.bonusQuestions.map((bq, qIdx) => {
                  const selected = bonusSelected[bq.id] ?? bq.userAnswer;
                  const answered = selected !== undefined;

                  return (
                    <div key={bq.id} className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                      <div className="flex items-start justify-between gap-2">
                        <h5 className="text-xs font-bold text-slate-900">
                          {qIdx + 1}. {bq.questionText}
                        </h5>
                        <span className="text-[10px] font-bold text-brand-600 bg-brand-50 px-2 py-0.5 rounded-full border border-brand-200">
                          +{bq.xpReward} XP
                        </span>
                      </div>

                      <div className="space-y-2">
                        {bq.options.map((opt, optIdx) => {
                          const isChosen = selected === optIdx;
                          const isCorrect = optIdx === bq.correctAnswer;

                          let btnStyle = 'bg-white border-slate-200 hover:bg-slate-100 text-slate-700';
                          if (answered) {
                            if (isCorrect) {
                              btnStyle = 'bg-emerald-100/80 border-emerald-300 text-emerald-900 font-bold';
                            } else if (isChosen) {
                              btnStyle = 'bg-rose-100/80 border-rose-300 text-rose-900 line-through';
                            } else {
                              btnStyle = 'bg-white/50 border-slate-200 text-slate-400';
                            }
                          }

                          return (
                            <button
                              key={optIdx}
                              disabled={answered}
                              onClick={() => handleAnswerBonus(bq.id, optIdx)}
                              className={`w-full text-left p-2.5 rounded-xl border text-xs transition-all flex items-center justify-between ${btnStyle}`}
                            >
                              <span>{String.fromCharCode(65 + optIdx)}. {opt}</span>
                              {answered && isCorrect && <Check className="w-3.5 h-3.5 text-emerald-600 stroke-[3]" />}
                            </button>
                          );
                        })}
                      </div>

                      {answered && (
                        <div className="p-2.5 bg-white rounded-xl border border-slate-200 text-[11px] text-slate-600">
                          <strong>Explanation:</strong> {bq.explanation}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 4: SUBMISSION HISTORY */}
          {activeTab === 'history' && (
            <div className="space-y-4 text-left animate-fadeIn">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Attempt History ({submissions.length})
              </h4>

              {submissions.map((sub, idx) => (
                <div key={sub.id} className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-900">
                      Attempt #{submissions.length - idx} • {new Date(sub.submittedAt).toLocaleDateString()} {new Date(sub.submittedAt).toLocaleTimeString()}
                    </span>
                    <span className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${
                      sub.evaluation?.status === 'cleared'
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-amber-100 text-amber-800'
                    }`}>
                      {sub.evaluation?.status === 'cleared' ? 'Cleared' : sub.evaluation?.status === 'failed' ? 'Evaluation Failed' : sub.evaluation?.status === 'submission_incomplete' ? 'Incomplete' : 'Needs Improvement'} ({sub.evaluation?.score}/100)
                    </span>
                  </div>

                  <p className="text-slate-600 text-[11px] leading-relaxed">
                    {sub.evaluation?.feedback || 'Evaluated submission.'}
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 px-6 border-t border-slate-100 bg-slate-50 flex items-center justify-between">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-bold text-slate-600 hover:text-slate-800 hover:bg-slate-200/50 rounded-xl transition-colors"
          >
            Close
          </button>

          <div className="flex items-center gap-2">
            {isCompleted ? (
              <div className="flex items-center gap-1.5 text-emerald-700 font-bold text-xs bg-emerald-50 px-3 py-1.5 rounded-xl border border-emerald-200">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>Verified Practical Competence</span>
              </div>
            ) : (
              <button
                onClick={() => setActiveTab('submit')}
                className="px-5 py-2 bg-brand-600 hover:bg-brand-700 text-white rounded-xl text-xs font-bold transition-all shadow-sm"
              >
                Submit Evidence
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
