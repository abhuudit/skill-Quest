import React, { useEffect, useRef, useState } from 'react';
import { Cohort, User } from '../../types';

interface Message { id: string; senderName: string; avatar: string; content: string; sentAt: string; isOwn: boolean }
const request = async (url: string, method = 'GET', body?: object) => {
  const response = await fetch(url, { method, headers: body ? { 'Content-Type': 'application/json' } : undefined, body: body ? JSON.stringify(body) : undefined, credentials: 'same-origin' });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || 'Chat unavailable.');
  return data;
};

export const CohortChat: React.FC<{ cohort: Cohort; user: User; onClose: () => void }> = ({ cohort, user, onClose }) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [draft, setDraft] = useState('');
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState('');
  const bottom = useRef<HTMLDivElement>(null);
  const list = useRef<HTMLDivElement>(null);
  useEffect(() => {
    let active = true;
    const base = `/api/chat/${cohort.id}`;
    const load = async () => {
      try {
        const nearBottom = !list.current || list.current.scrollHeight - list.current.scrollTop - list.current.clientHeight < 90;
        const result = await request(`${base}/messages`);
        if (!active) return;
        setMessages(result.messages);
        setError(''); setLoading(false);
        if (nearBottom) requestAnimationFrame(() => bottom.current?.scrollIntoView({ block: 'end' }));
      } catch (e) { if (active) { setError(e instanceof Error ? e.message : 'Could not load chat.'); setLoading(false); } }
    };
    const start = async () => {
      try {
        try { await request('/api/chat/session'); } catch { await request('/api/chat/session', 'POST', { name: user.name, avatar: user.avatar }); }
        await request(`${base}/join`, 'POST');
        await load();
      } catch (e) { if (active) { setError(e instanceof Error ? e.message : 'Could not join chat.'); setLoading(false); } }
    };
    void start();
    const timer = setInterval(() => { if (active && !document.hidden) void load(); }, 4000);
    return () => { active = false; clearInterval(timer); };
  }, [cohort.id, user.name, user.avatar]);
  const send = async (event: React.FormEvent) => {
    event.preventDefault();
    const content = draft.trim();
    if (!content || sending) return;
    setSending(true); setError('');
    try {
      const result = await request(`/api/chat/${cohort.id}/messages`, 'POST', { content });
      setMessages(prev => [...prev, result.message]); setDraft('');
      requestAnimationFrame(() => bottom.current?.scrollIntoView({ block: 'end' }));
    } catch (e) { setError(e instanceof Error ? e.message : 'Message was not sent.'); }
    finally { setSending(false); }
  };
  return <section className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden" aria-label={`${cohort.name} group chat`}>
    <div className="p-4 border-b border-slate-200 flex items-start justify-between gap-2"><div className="min-w-0"><h2 className="font-bold text-slate-900 break-words">{cohort.name} Chat</h2><p className="text-xs text-amber-700 break-words">Shared local demo chat · messages persist on this server · demo identities are not verified</p></div><button onClick={onClose} className="text-xs text-slate-600 flex-shrink-0">Close</button></div>
    <div ref={list} className="h-80 overflow-y-auto p-4 space-y-3" aria-live="polite">
      {loading && <p className="text-sm text-slate-500">Loading cohort messages…</p>}
      {!loading && !messages.length && <p className="text-sm text-slate-500 text-center py-16">No messages yet. Share a quest update or ask your cohort a question.</p>}
      {messages.map(m => <div key={m.id} className={`flex gap-2 ${m.isOwn ? 'justify-end' : 'justify-start'}`}>{!m.isOwn && (m.avatar ? <img src={m.avatar} alt="" className="w-8 h-8 rounded-full" /> : <span className="w-8 h-8 rounded-full bg-brand-100 text-brand-700 grid place-items-center">{m.senderName[0]}</span>)}<div className={`max-w-[80%] rounded-2xl px-3 py-2 ${m.isOwn ? 'bg-brand-600 text-white' : 'bg-slate-100 text-slate-900'}`}><div className="text-xs font-bold">{m.isOwn ? 'You' : m.senderName}</div><p className="text-sm whitespace-pre-wrap break-words">{m.content}</p><time className="text-[10px] opacity-75" dateTime={m.sentAt}>{new Date(m.sentAt).toLocaleString()}</time></div></div>)}
      <div ref={bottom} />
    </div>
    {error && <p role="alert" className="px-4 text-xs text-rose-600">{error}</p>}
    <form onSubmit={send} className="p-4 border-t border-slate-200 flex gap-2"><input aria-label="Cohort message" value={draft} maxLength={1000} onChange={e => setDraft(e.target.value)} placeholder="Share your progress or ask a question…" className="flex-1 min-w-0 px-3 py-2 border border-slate-300 rounded-xl text-sm" /><button type="submit" disabled={!draft.trim() || sending || loading} className="px-4 py-2 rounded-xl bg-brand-600 text-white text-sm font-bold disabled:opacity-50">{sending ? 'Sending…' : 'Send'}</button></form>
  </section>;
};
