import React from 'react';
import { useSkillQuest } from '../../context/SkillQuestContext';
import { Sparkles, Trophy, Zap, ArrowRight, Award } from 'lucide-react';
import { LEVEL_TIERS } from '../../utils/levels';

export const CelebrationModal: React.FC = () => {
  const { lastCompletionResult, clearLastCompletionResult } = useSkillQuest();

  if (!lastCompletionResult) return null;

  const { questTitle, xpAwarded, newLevel, unlockedAchievements, milestoneCompleted } = lastCompletionResult;
  const levelInfo = newLevel ? LEVEL_TIERS.find(t => t.level === newLevel) : null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white rounded-3xl shadow-2xl max-w-md w-full min-w-0 max-h-[calc(100dvh-2rem)] overflow-y-auto border border-slate-100 text-center p-5 sm:p-8 animate-scaleUp">
        {/* Animated Badge Icon */}
        <div className="relative mx-auto w-20 h-20 mb-5">
          <div className="absolute inset-0 rounded-full bg-brand-500/20 animate-ping opacity-75" />
          <div className="relative w-20 h-20 rounded-full bg-gradient-to-tr from-brand-600 to-indigo-500 flex items-center justify-center shadow-lg shadow-brand-500/30 text-white text-3xl">
            {newLevel ? '👑' : unlockedAchievements.length > 0 ? '🏆' : '✨'}
          </div>
        </div>

        <h3 className="text-2xl font-black text-slate-900 mb-1">
          {newLevel ? 'Level Up Achieved!' : 'Quest Completed!'}
        </h3>
        <p className="text-sm text-slate-500 mb-6 font-medium">
          {questTitle}
        </p>

        {/* Rewards Card */}
        <div className="bg-slate-50 border border-slate-100 rounded-2xl p-4 mb-6 space-y-3 text-left">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">XP Awarded</span>
            <span className="inline-flex items-center gap-1.5 text-base font-extrabold text-brand-600 bg-brand-50 px-3 py-1 rounded-full border border-brand-200">
              <Zap className="w-4 h-4 fill-brand-600" />
              +{xpAwarded} XP
            </span>
          </div>

          {newLevel && levelInfo && (
            <div className="pt-2 border-t border-slate-200/60 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-xl">{levelInfo.badge}</span>
                <div>
                  <div className="text-xs font-bold text-slate-900">Rank: Level {newLevel} - {levelInfo.title}</div>
                  <div className="text-[11px] text-slate-500">{levelInfo.description}</div>
                </div>
              </div>
              <Sparkles className="w-5 h-5 text-amber-500" />
            </div>
          )}

          {milestoneCompleted && (
            <div className="pt-2 border-t border-slate-200/60 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Trophy className="w-5 h-5 text-emerald-600" />
                <div>
                  <div className="text-xs font-bold text-slate-900">Milestone Conquered!</div>
                  <div className="text-[11px] text-slate-500">{milestoneCompleted.title}</div>
                </div>
              </div>
              <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
                +100 Bonus XP
              </span>
            </div>
          )}

          {unlockedAchievements.length > 0 && (
            <div className="pt-2 border-t border-slate-200/60 space-y-1.5">
              <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">New Badge Unlocked!</span>
              {unlockedAchievements.map(ach => (
                <div key={ach.id} className="flex items-center gap-2.5 p-2 rounded-xl bg-amber-50/60 border border-amber-200/80">
                  <span className="text-2xl">{ach.icon}</span>
                  <div className="text-left">
                    <div className="text-xs font-bold text-slate-900">{ach.name}</div>
                    <div className="text-[11px] text-slate-600">{ach.description}</div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Action Button */}
        <button
          onClick={clearLastCompletionResult}
          className="w-full flex items-center justify-center gap-2 py-3.5 px-6 bg-brand-600 hover:bg-brand-700 text-white rounded-xl font-bold text-sm shadow-md shadow-brand-500/25 transition-all"
        >
          <span>Keep Up The Momentum</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
