import React, { useEffect, useState } from 'react';
import { useSkillQuest } from '../../context/SkillQuestContext';
import { validateGeminiApiKey } from '../../services/geminiService';
import { PUBLIC_REVIEW_MODE } from '../../utils/reviewMode';
import {
  X,
  Key,
  Volume2,
  VolumeX,
  Users,
  RotateCcw,
  ShieldCheck,
  Sparkles,
  AlertTriangle,
  ExternalLink,
  CheckCircle2,
  Loader2,
  AlertCircle
} from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose }) => {
  const { user, updateSettings, resetAllData } = useSkillQuest();
  const [showConfirmReset, setShowConfirmReset] = useState(false);
  const [saveMessage, setSaveMessage] = useState(false);
  const [isTesting, setIsTesting] = useState(false);
  const [testResult, setTestResult] = useState<{ valid: boolean; message: string } | null>(null);
  const [timeZone, setTimeZone] = useState(user.settings.timeZone || Intl.DateTimeFormat().resolvedOptions().timeZone);
  const [timeZoneError, setTimeZoneError] = useState('');

  useEffect(() => {
    if (isOpen) { void validateGeminiApiKey().then(res => setTestResult({ valid: res.valid, message: res.valid ? `Gemini ready (${res.model}).` : (res.error || 'AI unavailable.') })); }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleReset = () => {
    resetAllData();
    setShowConfirmReset(false);
    onClose();
  };

  return (
    <div className="sq-settings fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-900/60 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full min-w-0 overflow-hidden border border-slate-100 flex flex-col max-h-[calc(100dvh-1rem)] sm:max-h-[calc(100dvh-2rem)]">
        {/* Header */}
        <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-brand-50 rounded-xl text-brand-600 border border-brand-200">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900">SkillQuest Preferences</h3>
              <p className="text-xs text-slate-600">Configure AI engine, audio, and platform state</p>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="Close settings"
            className="p-1.5 text-slate-600 hover:text-slate-900 rounded-lg hover:bg-slate-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-6 text-sm">
          {/* AI Engine Section */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="font-semibold text-slate-800 flex items-center gap-2">
                <Key className="w-4 h-4 text-brand-600" />
                <span>Gemini evaluation</span>
              </label>
              <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-full ${
                testResult?.valid ? 'bg-purple-100 text-purple-700' : 'bg-amber-100 text-amber-800'
              }`}>
                {PUBLIC_REVIEW_MODE ? 'Review preview' : testResult?.valid ? 'Live Gemini AI' : 'AI not configured'}
              </span>
            </div>

            {PUBLIC_REVIEW_MODE ? <p className="text-xs text-slate-500 leading-relaxed">This static review preview has no AI server. Roadmaps and quizzes use local fallbacks; evidence and notes cannot be reviewed here.</p> : <p className="text-xs text-slate-500 leading-relaxed">
              Set GEMINI_API_KEY in your local server .env file, then restart the server. Keys are never entered or stored in the browser. Get a key from{' '}
              <a
                href="https://aistudio.google.com/app/apikey"
                target="_blank"
                rel="noreferrer"
                className="text-brand-600 font-bold hover:underline inline-flex items-center gap-0.5"
              >
                Google AI Studio <ExternalLink className="w-3 h-3" />
              </a>.
            </p>}

            {testResult && (
              <div className={`p-2.5 rounded-xl text-xs flex items-center gap-2 animate-fadeIn ${
                testResult.valid
                  ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                  : 'bg-rose-50 text-rose-800 border border-rose-200'
              }`}>
                {testResult.valid ? <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" /> : <AlertCircle className="w-4 h-4 text-rose-600 flex-shrink-0" />}
                <span>{testResult.message}</span>
              </div>
            )}

            {saveMessage && !testResult && (
              <p className="text-xs text-emerald-600 font-medium animate-fadeIn">Settings saved successfully!</p>
            )}
          </div>

          <hr className="border-slate-100" />

          <div className="space-y-2"><h4 className="font-semibold text-slate-800">Appearance</h4><p className="text-xs text-slate-600">Choose how SkillQuest displays light and dark surfaces.</p><div className="flex flex-wrap gap-2" role="group" aria-label="Theme preference">{(['light', 'dark', 'system'] as const).map(theme => <button key={theme} type="button" aria-pressed={(user.settings.theme || 'system') === theme} onClick={() => updateSettings({ theme })} className={`px-3 py-2 rounded-xl border text-xs font-bold capitalize ${(user.settings.theme || 'system') === theme ? 'bg-brand-600 border-brand-600 text-white' : 'bg-white border-slate-400 text-slate-700'}`}>{theme}</button>)}</div></div>

          <hr className="border-slate-100" />

          <div className="space-y-2"><label htmlFor="learning-time-zone" className="font-semibold text-slate-800">Learning day time zone</label><p className="text-xs text-slate-500">Daily quizzes and streaks use this calendar time zone.</p><div className="flex gap-2"><input id="learning-time-zone" value={timeZone} onChange={e => setTimeZone(e.target.value)} placeholder="Asia/Kolkata" className="flex-1 min-w-0 p-2 border border-slate-300 rounded-xl text-xs" /><button onClick={() => { try { Intl.DateTimeFormat('en-US', { timeZone: timeZone.trim() }); updateSettings({ timeZone: timeZone.trim() }); setTimeZoneError('Saved.'); } catch { setTimeZoneError('Enter a valid IANA time zone, such as Asia/Kolkata.'); } }} className="px-3 py-2 bg-brand-600 text-white rounded-xl text-xs font-bold">Save</button></div>{timeZoneError && <p role="status" className="text-xs text-slate-600">{timeZoneError}</p>}</div>

          <hr className="border-slate-100" />

          {/* Sound Effects */}
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <div className="font-semibold text-slate-800 flex items-center gap-2">
                {user.settings.soundEffects ? <Volume2 className="w-4 h-4 text-brand-600" /> : <VolumeX className="w-4 h-4 text-slate-400" />}
                <span>Gamification Sound Effects</span>
              </div>
              <p className="text-xs text-slate-500">Play gentle harmonic chimes upon completing quests and unlocking badges.</p>
            </div>
            <button
              onClick={() => updateSettings({ soundEffects: !user.settings.soundEffects })}
              role="switch" aria-label="Gamification sound effects" aria-checked={user.settings.soundEffects}
              className={`w-11 h-6 flex items-center rounded-full p-1 transition-colors duration-200 ease-in-out ${
                user.settings.soundEffects ? 'bg-brand-600' : 'sq-switch-off bg-slate-600'
              }`}
            >
              <div
                className={`sq-toggle-knob bg-white w-4 h-4 rounded-full shadow-md transform transition-transform duration-200 ease-in-out ${
                  user.settings.soundEffects ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          <hr className="border-slate-100" />

          {/* Opt-In Leaderboard */}
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <div className="font-semibold text-slate-800 flex items-center gap-2">
                <Users className="w-4 h-4 text-brand-600" />
                <span>Peer Leaderboard Participation</span>
              </div>
              <p className="text-xs text-slate-500">Opt into supportive community rankings. Turn off for a zero-comparison private experience.</p>
            </div>
            <button
              onClick={() => updateSettings({ optInLeaderboard: !user.settings.optInLeaderboard })}
              role="switch" aria-label="Peer leaderboard participation" aria-checked={user.settings.optInLeaderboard}
              className={`w-11 h-6 flex items-center rounded-full p-1 transition-colors duration-200 ease-in-out ${
                user.settings.optInLeaderboard ? 'bg-brand-600' : 'sq-switch-off bg-slate-600'
              }`}
            >
              <div
                className={`sq-toggle-knob bg-white w-4 h-4 rounded-full shadow-md transform transition-transform duration-200 ease-in-out ${
                  user.settings.optInLeaderboard ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          <hr className="border-slate-100" />

          {/* Demo Data Reset */}
          <div className="pt-2">
            {!showConfirmReset ? (
              <button
                onClick={() => setShowConfirmReset(true)}
                className="flex items-center gap-2 text-xs font-semibold text-rose-600 hover:text-rose-700 hover:bg-rose-50 px-3 py-2 rounded-xl transition-colors border border-rose-200"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Reset Demo State to Alex Rivera's Baseline</span>
              </button>
            ) : (
              <div className="p-4 bg-rose-50 border border-rose-200 rounded-xl space-y-3">
                <div className="flex items-center gap-2 text-rose-800 font-bold text-xs">
                  <AlertTriangle className="w-4 h-4 text-rose-600" />
                  <span>Reset All Local Storage Data?</span>
                </div>
                <p className="text-xs text-rose-700">
                  This restores the initial baseline state with fresh quests, milestones, and achievements for evaluation.
                </p>
                <div className="flex gap-2">
                  <button
                    onClick={handleReset}
                    className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-semibold"
                  >
                    Yes, Reset Data
                  </button>
                  <button
                    onClick={() => setShowConfirmReset(false)}
                    className="px-3 py-1.5 bg-white text-slate-700 border border-slate-300 rounded-lg text-xs font-semibold"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 px-6 border-t border-slate-100 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center gap-1.5 text-xs text-slate-500 font-medium">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>Settings saved automatically to local storage</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-xl text-xs font-semibold transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
