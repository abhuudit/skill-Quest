import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useSkillQuest } from '../../context/SkillQuestContext';

export const GoalSwitcher: React.FC = () => {
  const { goal, goals, switchGoal } = useSkillQuest();
  const navigate = useNavigate();
  return <section className="bg-white rounded-2xl border border-slate-200 px-4 py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3 min-w-0" aria-label="Learning Goal Switcher">
    <div className="min-w-0"><p className="text-[11px] font-bold uppercase tracking-wide text-slate-600">Learning Goal Switcher</p><p className="text-sm font-bold text-slate-900 break-words">{goal.displayName || goal.skill}{goal.status === 'completed' ? ' · Completed' : goal.status === 'archived' ? ' · Archived' : ''}</p></div>
    <div className="flex flex-wrap items-center gap-2 min-w-0"><select aria-label="Select learning goal" value={goal.id} onChange={event => event.target.value === '__new__' ? navigate('/onboarding') : switchGoal(event.target.value)} className="min-w-0 max-w-full sm:w-56 px-3 py-2 rounded-xl border border-slate-300 bg-white text-slate-900 text-sm font-semibold">{goals.filter(item => item.status !== 'archived' || item.id === goal.id).map(item => <option key={item.id} value={item.id}>{item.displayName || item.skill}{item.status === 'completed' ? ' (completed)' : item.status === 'archived' ? ' (archived)' : ''}</option>)}<option value="__new__">+ Create New Goal</option></select><Link to="/goals" className="px-3 py-2 text-xs font-bold text-brand-700 border border-brand-200 rounded-xl">Manage goals</Link></div>
  </section>;
};
