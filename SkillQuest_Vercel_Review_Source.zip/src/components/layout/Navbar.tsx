import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useSkillQuest } from '../../context/SkillQuestContext';
import {
  Compass,
  Flame,
  Zap,
  Settings,
  Menu,
  X,
  Target,
  Trophy,
  BookOpen,
  Users,
  BarChart3,
  CheckSquare,
  Sparkles,
  HelpCircle
  ,Sun, Moon
} from 'lucide-react';
import { getLevelInfo } from '../../utils/levels';

interface NavbarProps {
  onOpenSettings: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenSettings }) => {
  const { user, updateSettings } = useSkillQuest();
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const levelInfo = getLevelInfo(user.currentXP);

  const navLinks = [
    { label: 'Dashboard', path: '/dashboard', icon: Target },
    { label: 'AI Roadmap', path: '/roadmap', icon: Compass },
    { label: 'Daily Quests', path: '/quests', icon: CheckSquare },
    { label: 'Homework', path: '/homework', icon: CheckSquare },
    { label: 'My Projects', path: '/projects', icon: Trophy },
    { label: 'Notes', path: '/notes', icon: BookOpen },
    { label: 'Skill Quiz', path: '/quiz', icon: HelpCircle },
    { label: 'Achievements', path: '/achievements', icon: Trophy },
    { label: 'Streaks & Comeback', path: '/streaks', icon: Flame },
    { label: 'Resources', path: '/resources', icon: BookOpen },
    { label: 'Cohorts', path: '/cohorts', icon: Users },
    { label: 'Analytics', path: '/analytics', icon: BarChart3 },
  ];

  const isActive = (path: string) => location.pathname === path;

  return (
    <header className="sticky top-0 z-40 bg-white/90 backdrop-blur-md border-b border-slate-200/80 transition-all">
      <div className="max-w-screen-2xl min-[1800px]:max-w-[1800px] mx-auto px-3 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-2 min-h-16">
          {/* Brand Logo */}
          <div className="flex items-center gap-4 min-w-0">
            <Link to="/" className="flex items-center gap-2.5 group">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-brand-600 via-indigo-600 to-violet-600 flex items-center justify-center text-white shadow-md shadow-brand-500/20 group-hover:scale-105 transition-transform">
                <Sparkles className="w-5 h-5" />
              </div>
              <div className="flex flex-col">
                <span className="text-xl font-extrabold text-navy-950 tracking-tight flex items-center gap-1">
                  Skill<span className="text-brand-600">Quest</span>
                </span>
                <span className="text-[10px] font-semibold text-slate-600 -mt-1 tracking-wider uppercase">
                  Intent to Habit
                </span>
              </div>
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden min-[1800px]:flex items-center gap-0.5 min-w-0" aria-label="Main navigation">
              {navLinks.map((link) => {
                const Icon = link.icon;
                const active = isActive(link.path);
                return (
                  <Link
                    key={link.path}
                    to={link.path}
                    className={`flex items-center gap-1 px-2 py-1.5 rounded-lg text-[11px] font-semibold whitespace-nowrap transition-all ${
                      active
                        ? 'bg-brand-50 text-brand-700 shadow-sm border border-brand-200/60'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                    }`}
                  >
                    <Icon className={`w-3.5 h-3.5 ${active ? 'text-brand-600' : 'text-slate-400'}`} />
                    <span>{link.label}</span>
                  </Link>
                );
              })}
            </nav>
          </div>

          {/* User Gamification Stats & Controls */}
          <div className="flex items-center gap-1.5 sm:gap-2 flex-shrink-0">
            <button type="button" aria-label="Toggle dark mode" title="Toggle dark mode" onClick={() => updateSettings({ theme: document.documentElement.classList.contains('dark') ? 'light' : 'dark' })} className="p-2 text-slate-600 hover:text-brand-600 rounded-xl border border-slate-200">{user.settings.theme === 'dark' || (!user.settings.theme || user.settings.theme === 'system') && document.documentElement.classList.contains('dark') ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}</button>
            {/* Streak Counter Chip */}
            <Link
              to="/streaks"
              title="View daily streak and activity calendar"
              className="hidden sm:flex items-center gap-1.5 px-3 py-1 bg-amber-50 border border-amber-200/80 rounded-full text-amber-800 hover:bg-amber-100/80 transition-colors cursor-pointer group"
            >
              <Flame className="w-4 h-4 text-amber-500 fill-amber-500 group-hover:animate-bounce" />
              <span className="text-xs font-bold">{user.currentStreak}d Streak</span>
            </Link>

            {/* XP Points Chip */}
            <div
              title={`Total: ${user.currentXP} XP. Level ${levelInfo.level} ${levelInfo.title}`}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1 bg-brand-50 border border-brand-200/80 rounded-full text-brand-700"
            >
              <Zap className="w-4 h-4 text-brand-600 fill-brand-600" />
              <span className="text-xs font-extrabold">{user.currentXP} XP</span>
              <span className="text-[11px] font-semibold text-brand-500 bg-white/80 px-1.5 py-0.2 rounded-full border border-brand-200/60">
                Lv.{levelInfo.level}
              </span>
            </div>

            {/* Settings Trigger */}
            <button
              onClick={onOpenSettings}
              title="Open preferences"
              className="p-2 text-slate-500 hover:text-slate-700 hover:bg-slate-100 rounded-xl transition-colors border border-transparent hover:border-slate-200"
            >
              <Settings className="w-4 h-4" />
            </button>

            {/* User Profile Avatar Link */}
            <Link to="/dashboard" className="flex items-center gap-2 pl-1 group">
              <div className="relative">
                <img
                  src={user.avatar}
                  alt={user.name}
                  className="w-8 h-8 rounded-full object-cover ring-2 ring-brand-500/30 group-hover:ring-brand-500 transition-all"
                />
                <span className="absolute -bottom-1 -right-1 text-xs">{levelInfo.badge}</span>
              </div>
              <div className="hidden lg:flex flex-col text-left">
                <span className="text-xs font-bold text-slate-800 leading-tight">{user.name}</span>
                <span className="text-[10px] text-slate-500 font-medium">{levelInfo.title}</span>
              </div>
            </Link>

            {/* Mobile Menu Toggle Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              aria-label={mobileMenuOpen ? 'Close navigation' : 'Open navigation'}
              aria-expanded={mobileMenuOpen}
              className="min-[1800px]:hidden p-2 text-slate-600 hover:text-slate-900 rounded-lg hover:bg-slate-100"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="min-[1800px]:hidden bg-white border-b border-slate-200 px-4 pt-3 pb-6 space-y-2 shadow-xl animate-fadeIn max-h-[calc(100dvh-4rem)] overflow-y-auto">
          <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 flex items-center justify-between mb-3">
            <div className="flex items-center gap-3">
              <img src={user.avatar} alt={user.name} className="w-10 h-10 rounded-full object-cover" />
              <div>
                <div className="text-sm font-bold text-slate-900">{user.name}</div>
                <div className="text-xs text-brand-600 font-semibold">Level {levelInfo.level} — {levelInfo.title}</div>
              </div>
            </div>
            <div className="flex flex-col items-end">
              <div className="text-xs font-extrabold text-brand-600">{user.currentXP} XP</div>
              <div className="text-[11px] font-bold text-amber-600">{user.currentStreak} Day Streak 🔥</div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2">
            {navLinks.map((link) => {
              const Icon = link.icon;
              const active = isActive(link.path);
              return (
                <Link
                  key={link.path}
                  to={link.path}
                  onClick={() => setMobileMenuOpen(false)}
                  className={`flex items-center gap-2 p-2.5 rounded-xl text-xs font-semibold ${
                    active
                      ? 'bg-brand-50 text-brand-700 border border-brand-200'
                      : 'text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  <Icon className="w-4 h-4 text-brand-500" />
                  <span>{link.label}</span>
                </Link>
              );
            })}
          </div>

          <div className="pt-2 border-t border-slate-100 flex flex-wrap gap-2">
            <Link to="/goals" onClick={() => setMobileMenuOpen(false)} className="flex-1 text-center py-2 text-xs font-semibold border border-brand-300 text-brand-700 rounded-xl">My Goals</Link>
            <Link
              to="/onboarding"
              onClick={() => setMobileMenuOpen(false)}
              className="flex-1 text-center py-2 text-xs font-semibold bg-brand-600 text-white rounded-xl shadow-sm"
            >
              + Create New Skill Goal
            </Link>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenSettings();
              }}
              className="px-3 py-2 text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl"
            >
              Settings
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
