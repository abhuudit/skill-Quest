import React, { useState } from 'react';
import { Outlet } from 'react-router-dom';
import { Navbar } from './Navbar';
import { SettingsModal } from '../common/SettingsModal';
import { CelebrationModal } from '../common/CelebrationModal';
import { useSkillQuest } from '../../context/SkillQuestContext';
import { PUBLIC_REVIEW_MODE } from '../../utils/reviewMode';

export const AppLayout: React.FC = () => {
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const { goal } = useSkillQuest();

  return (
    <div className="min-h-screen w-full min-w-0 flex flex-col bg-slate-50 text-slate-900 font-sans selection:bg-brand-500 selection:text-white">
      {/* Top Navbar */}
      <Navbar onOpenSettings={() => setIsSettingsOpen(true)} />
      {PUBLIC_REVIEW_MODE && <div role="status" className="border-b border-amber-200 bg-amber-50 px-4 py-2 text-center text-xs font-medium text-amber-950">Review preview · Progress and notes stay in this browser. AI evaluation, notes review, and shared chat are unavailable. Cohorts and leaderboard show demo data.</div>}

      {/* Main Page Body */}
      <main className="flex-1 w-full min-w-0 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5 sm:py-7">
        <Outlet key={goal.id} />
      </main>

      {/* Reusable Modals */}
      <SettingsModal isOpen={isSettingsOpen} onClose={() => setIsSettingsOpen(false)} />
      <CelebrationModal />
    </div>
  );
};
