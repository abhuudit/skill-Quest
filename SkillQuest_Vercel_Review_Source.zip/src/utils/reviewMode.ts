export const PUBLIC_REVIEW_MODE = import.meta.env?.VITE_PUBLIC_REVIEW === 'true';
