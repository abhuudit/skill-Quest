const DB_NAME = 'skillquest-private-pdf-notes';
const STORE = 'files';
export const MAX_PDF_NOTE_BYTES = 6 * 1024 * 1024;

function openDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, 1);
    request.onupgradeneeded = () => request.result.createObjectStore(STORE);
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(new Error('Browser file storage is unavailable.'));
  });
}

export async function savePdfFile(userId: string, noteId: string, versionId: string, file: File): Promise<void> {
  const db = await openDatabase();
  try {
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE, 'readwrite');
      tx.objectStore(STORE).put(file, `${userId}:${noteId}:${versionId}`);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(new Error('The PDF could not be saved in this browser. Check available storage.'));
      tx.onabort = () => reject(new Error('The PDF could not be saved in this browser.'));
    });
  } finally { db.close(); }
}

export async function loadPdfFile(userId: string, noteId: string, versionId: string): Promise<Blob | null> {
  const db = await openDatabase();
  try {
    return await new Promise<Blob | null>((resolve, reject) => {
      const tx = db.transaction(STORE, 'readonly');
      const request = tx.objectStore(STORE).get(`${userId}:${noteId}:${versionId}`);
      request.onsuccess = () => resolve(request.result || null);
      request.onerror = () => reject(new Error('The saved PDF could not be opened.'));
    });
  } finally { db.close(); }
}

export async function validatePdfFile(file: File): Promise<void> {
  if (!/\.pdf$/i.test(file.name) || file.type && file.type !== 'application/pdf') throw new Error('Choose a PDF file.');
  if (!file.size || file.size > MAX_PDF_NOTE_BYTES) throw new Error('Choose a PDF smaller than 6 MB.');
  const header = new TextDecoder('latin1').decode(await file.slice(0, 8).arrayBuffer());
  const end = new TextDecoder('latin1').decode(await file.slice(Math.max(0, file.size - 2048)).arrayBuffer());
  if (!header.startsWith('%PDF-') || !end.includes('startxref') || !end.includes('%%EOF')) throw new Error('This PDF appears damaged or incomplete. Export or scan it again.');
}

export function fileAsDataUrl(file: Blob, onProgress: (value: number) => void): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onprogress = e => { if (e.lengthComputable) onProgress(Math.round(e.loaded / e.total * 100)); };
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error('The PDF could not be read.'));
    reader.readAsDataURL(file);
  });
}
