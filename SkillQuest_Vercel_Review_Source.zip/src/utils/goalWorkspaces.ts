import { LearningGoal, Milestone, Quest, LearningResource, Topic, ComebackPlan } from '../types';

export interface GoalWorkspace {
  goal: LearningGoal;
  milestones: Milestone[];
  quests: Quest[];
  resources: LearningResource[];
  topics: Topic[];
  comebackPlan: ComebackPlan | null;
}

export function upsertGoalWorkspace(current: GoalWorkspace[], next: GoalWorkspace): GoalWorkspace[] {
  const index = current.findIndex(workspace => workspace.goal.id === next.goal.id);
  return index < 0 ? [...current, next] : current.map(workspace => workspace.goal.id === next.goal.id ? next : workspace);
}
