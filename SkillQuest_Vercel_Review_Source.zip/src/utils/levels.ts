export interface LevelTier {
  level: number;
  title: string;
  minXP: number;
  maxXP: number;
  badge: string;
  description: string;
  color: string;
}

export const LEVEL_TIERS: LevelTier[] = [
  { level: 1, title: 'Novice', minXP: 0, maxXP: 100, badge: '🌱', description: 'Just stepped into the realm of learning', color: 'from-emerald-500 to-teal-600' },
  { level: 2, title: 'Explorer', minXP: 100, maxXP: 250, badge: '🧭', description: 'Venturing into new concepts consistently', color: 'from-teal-500 to-cyan-600' },
  { level: 3, title: 'Apprentice', minXP: 250, maxXP: 450, badge: '⚔️', description: 'Developing core technical muscle memory', color: 'from-cyan-500 to-blue-600' },
  { level: 4, title: 'Practitioner', minXP: 450, maxXP: 700, badge: '🛡️', description: 'Applying skills to real problems reliably', color: 'from-blue-500 to-indigo-600' },
  { level: 5, title: 'Builder', minXP: 700, maxXP: 1000, badge: '🔨', description: 'Constructing robust projects independently', color: 'from-indigo-500 to-violet-600' },
  { level: 6, title: 'Achiever', minXP: 1000, maxXP: 1400, badge: '🏆', description: 'Crushing complex milestones with ease', color: 'from-violet-500 to-purple-600' },
  { level: 7, title: 'Specialist', minXP: 1400, maxXP: 1900, badge: '⚡', description: 'Mastering nuances and advanced techniques', color: 'from-purple-500 to-pink-600' },
  { level: 8, title: 'Expert', minXP: 1900, maxXP: 2500, badge: '🔮', description: 'Possessing deep theoretical and practical acumen', color: 'from-pink-500 to-rose-600' },
  { level: 9, title: 'Master', minXP: 2500, maxXP: 3300, badge: '👑', description: 'Fluency and instinct in the craft', color: 'from-amber-500 to-orange-600' },
  { level: 10, title: 'Skill Champion', minXP: 3300, maxXP: 5000, badge: '🌟', description: 'Apex discipline, perseverance, and mastery', color: 'from-yellow-400 to-amber-600' },
];

export const XP_RULES = {
  QUEST_REGULAR: 15,
  QUEST_DIFFICULT: 35,
  QUEST_BEGINNER: 15,
  QUEST_MEDIUM: 35,
  QUEST_ADVANCED: 70,
  MILESTONE_COMPLETION: 100,
  WEEKLY_CHALLENGE: 75,
  COMEBACK_QUEST: 25,
  STREAK_BONUS_3_DAYS: 30,
  STREAK_BONUS_7_DAYS: 70,
};

export function getQuestXP(difficulty: string): number {
  return difficulty === 'Advanced' || difficulty === 'Higher' ? 70 : difficulty === 'Medium' || difficulty === 'Intermediate' ? 35 : 15;
}

export function getLevelInfo(totalXP: number) {
  const currentTier = LEVEL_TIERS.find(
    (tier) => totalXP >= tier.minXP && (tier.level === 10 || totalXP < tier.maxXP)
  ) || LEVEL_TIERS[LEVEL_TIERS.length - 1];

  const isMaxLevel = currentTier.level === 10;
  const nextTier = isMaxLevel ? currentTier : LEVEL_TIERS[currentTier.level];

  const xpInCurrentTier = totalXP - currentTier.minXP;
  const xpNeededForTier = isMaxLevel ? 1700 : currentTier.maxXP - currentTier.minXP;
  const progressPercent = Math.min(100, Math.max(0, Math.round((xpInCurrentTier / xpNeededForTier) * 100)));
  const xpRemaining = isMaxLevel ? 0 : Math.max(0, currentTier.maxXP - totalXP);

  return {
    currentTier,
    nextTier,
    level: currentTier.level,
    title: currentTier.title,
    badge: currentTier.badge,
    color: currentTier.color,
    xpInCurrentTier,
    xpNeededForTier,
    progressPercent,
    xpRemaining,
    isMaxLevel,
  };
}
