import { LearningGoal, Milestone, Quest, QuizQuestion, QuestDifficulty } from '../types';
import { getQuestXP } from './levels';

export function localDate(timeZone?: string, date = new Date()): string {
  const parts = new Intl.DateTimeFormat('en-US', { timeZone: timeZone || Intl.DateTimeFormat().resolvedOptions().timeZone, year: 'numeric', month: '2-digit', day: '2-digit' }).formatToParts(date);
  const value = (type: string) => parts.find(p => p.type === type)?.value || '';
  return `${value('year')}-${value('month')}-${value('day')}`;
}
const dailyMinutes = (time: string) => time.includes('hour') ? (parseInt(time, 10) || 2) * 60 : parseInt(time, 10) || 30;

export function assignmentForQuest(goal: LearningGoal, quest: Quest, date: string): Quest {
  const skill = goal.skill.toLowerCase();
  const extension = /guitar|piano|music|speaking|speech|dance/.test(skill)
    ? 'Perform a second take with one deliberate improvement. Include the complete performance in your evidence.'
    : /design|draw|paint|photograph/.test(skill)
    ? 'Create a second variation and explain the design choice you changed.'
    : /data|analytics|statistics/.test(skill)
    ? 'Apply the technique to a small new example and explain three observations supported by your result.'
    : /writing/.test(skill)
    ? 'Revise your work for clarity, then explain two specific improvements you made.'
    : 'Apply the technique to a fresh example and demonstrate one improvement beyond the original quest.';
  return {
    ...quest,
    id: `assignment_${quest.id}`,
    kind: 'assignment',
    goalId: goal.id,
    sourceQuestId: quest.id,
    title: `Daily Homework: ${quest.title}`,
    description: `Use what you learned in ${quest.title}. ${extension}`,
    learningObjective: `Apply ${quest.title} independently in ${goal.skill}.`,
    instructions: ['Review the linked quest and its learning material.', extension, 'Submit the actual result and briefly explain what you changed.'],
    submissionRequirements: `Submit practical ${quest.submissionType} evidence of your independent exercise. ${quest.submissionRequirements}`,
    rubric: [
      { id: 'application', criterion: 'Independent application', description: `The work applies the ${quest.title} technique to a new example.` },
      { id: 'evidence', criterion: 'Practical evidence', description: 'The submission shows the completed work and the deliberate improvement.' },
    ],
    xpReward: Math.max(10, Math.round(getQuestXP(quest.difficulty) * 0.6)),
    durationMinutes: Math.max(10, Math.min(quest.durationMinutes, dailyMinutes(goal.availableTime))),
    scheduledDate: date,
    isToday: date === localDate(),
    status: 'todo', submissions: [], latestEvaluation: undefined, completedAt: undefined,
    bonusQuestions: [], bonusXpEarned: 0, bonusCompleted: false,
  };
}

export function createAssignments(goal: LearningGoal, quests: Quest[], today = localDate()): Quest[] {
  const core = quests.filter(q => !q.kind && !q.isComebackQuest && q.status !== 'completed');
  const dates = new Set<string>();
  return core.flatMap((quest, index) => {
    const date = quest.scheduledDate || (index === 0 ? today : localDate(undefined, new Date(Date.now() + index * 86400000)));
    if (dates.has(date)) return [];
    dates.add(date);
    return [assignmentForQuest(goal, quest, date)];
  });
}

export function createMidwayProject(goal: LearningGoal, milestones: Milestone[], quests: Quest[], template?: Partial<Quest>): Quest | null {
  if (milestones.length < 2) return null;
  const halfway = Math.ceil(milestones.length / 2);
  const foundations = milestones.slice(0, halfway);
  const skill = goal.skill.toLowerCase();
  const task = /guitar|piano|music/.test(skill) ? 'Record a complete performance combining the techniques you have learned.'
    : /speaking|speech/.test(skill) ? 'Record a structured presentation with a clear opening, body, and conclusion.'
    : /data|analytics/.test(skill) ? 'Analyze a dataset, create visualizations, and explain the evidence behind your findings.'
    : /design|draw|paint/.test(skill) ? 'Create a cohesive visual project that combines the principles you have practiced.'
    : /writing/.test(skill) ? 'Write and revise a complete article that demonstrates the techniques covered so far.'
    : /web|frontend|react|html|css/.test(skill) ? 'Build a responsive personal portfolio that demonstrates the techniques covered so far.'
    : `Create a substantial ${goal.skill} project combining the techniques covered so far.`;
  const submissionType = template?.submissionType || (/guitar|piano|music|speaking|speech/.test(skill) ? 'video' : /design|draw|paint/.test(skill) ? 'image' : /writing/.test(skill) ? 'text' : 'document');
  const firstQuest = quests.find(q => !q.kind);
  return {
    id: `midway_${goal.id}`, goalId: goal.id, kind: 'midway', milestoneId: foundations.at(-1)!.id,
    prerequisiteMilestoneIds: foundations.map(m => m.id),
    title: template?.title || 'Midway Project — Put Your Skills Into Practice',
    description: template?.description || task,
    projectObjectives: template?.projectObjectives || foundations.map(m => `Apply ${m.title}`),
    skillsAssessed: template?.skillsAssessed || foundations.map(m => m.title),
    optionalEnhancements: template?.optionalEnhancements || [`Add one thoughtful improvement beyond the core ${goal.skill} requirements.`],
    instructions: template?.instructions?.length ? template.instructions : ['Review the first half of your roadmap.', task, 'Test or rehearse your result.', 'Submit evidence and describe the outcome.'],
    submissionType, submissionRequirements: template?.submissionRequirements || `Submit the actual ${goal.skill} project as ${submissionType} evidence, with a brief explanation of its outcome.`,
    rubric: template?.rubric?.length ? template.rubric : [
      { id: 'foundation', criterion: 'Foundational skills applied', description: `The project demonstrates concepts from ${foundations.map(m => m.title).join(', ')}.` },
      { id: 'deliverable', criterion: 'Complete practical deliverable', description: 'The submitted evidence shows a finished project rather than a plan or claim.' },
      { id: 'reflection', criterion: 'Outcome explained', description: 'The learner explains what was built or performed and how it was checked.' },
    ],
    durationMinutes: Math.max(60, dailyMinutes(goal.availableTime) * 3),
    difficulty: template?.difficulty || (firstQuest?.difficulty === 'Advanced' ? 'Advanced' : 'Medium'),
    xpReward: 100, status: 'todo', isToday: false, submissions: [],
  };
}

export function midwayUnlocked(project: Quest, milestones: Milestone[]): boolean {
  return Boolean(project.kind === 'midway' && project.prerequisiteMilestoneIds?.every(id => milestones.find(m => m.id === id)?.status === 'completed'));
}

export function fallbackDailyQuestions(goal: LearningGoal, milestones: Milestone[], quests: Quest[], bank: QuizQuestion[]): QuizQuestion[] {
  const current = Math.max(1, ...milestones.filter(m => m.status !== 'locked').map(m => m.sequence));
  const related = quests.filter(q => !q.kind && milestones.find(m => m.id === q.milestoneId && m.sequence <= current));
  const pool = bank.filter(q => q.skill.toLowerCase() === goal.skill.toLowerCase() && q.milestoneSequence <= current);
  for (const quest of related) for (const b of quest.bonusQuestions || []) {
    if (b.options.length >= 2 && b.correctAnswer >= 0 && b.correctAnswer < b.options.length) pool.push({ id: `review_${b.id}`, skill: goal.skill, milestoneSequence: current, questionText: b.questionText, options: b.options, correctAnswer: b.correctAnswer, explanation: b.explanation, difficulty: quest.difficulty, xpReward: 10 });
  }
  const facts = related.flatMap(q => [...q.instructions, ...q.rubric.map(r => `${r.criterion}: ${r.description}`)]).filter(Boolean);
  const safeFacts = facts.length ? facts : milestones.flatMap(m => m.criteria);
  for (let i = 0; pool.length < 10 && i < 30; i++) {
    const fact = safeFacts[i % Math.max(1, safeFacts.length)] || `Practice ${goal.skill} regularly`;
    const source = related[i % Math.max(1, related.length)];
    pool.push({ id: `plan_review_${goal.id}_${i}`, skill: goal.skill, milestoneSequence: current, questionText: `For ${source?.title || goal.skill}, which action matches your current learning plan?`, options: [fact, 'Skip the practical work and mark the lesson complete.', 'Use a result from another learner without checking it.', 'Ignore the stated completion requirements.'], correctAnswer: 0, explanation: `Your learning plan asks you to: ${fact}`, difficulty: (source?.difficulty || 'Beginner') as QuestDifficulty, xpReward: 10 });
  }
  return pool.slice(0, 10).map((q, index) => ({ ...q, id: `daily_${index}_${q.id}` }));
}
