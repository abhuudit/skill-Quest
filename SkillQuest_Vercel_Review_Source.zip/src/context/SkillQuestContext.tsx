import React, { createContext, useContext, useState, useEffect, useRef, ReactNode } from 'react';
import confetti from 'canvas-confetti';
import {
  User,
  LearningGoal,
  Milestone,
  Quest,
  Achievement,
  LearningResource,
  Cohort,
  LeaderboardUser,
  DailyActivity,
  ComebackPlan,
  Topic,
  QuizQuestion,
  EvaluationResult,
  SubmissionType,
  QuestSubmission
  ,DailyQuizRecord, LearningNote, NoteReview, PdfNoteReview, PdfNoteVersion, PortfolioEntry
} from '../types';
import {
  INITIAL_USER,
  INITIAL_GOAL,
  INITIAL_MILESTONES,
  INITIAL_QUESTS,
  INITIAL_ACHIEVEMENTS,
  INITIAL_RESOURCES,
  INITIAL_COHORTS,
  INITIAL_LEADERBOARD,
  INITIAL_TOPICS,
  INITIAL_QUIZ_QUESTIONS,
  generateInitialActivityHistory,
} from '../data/initialData';
import { getLevelInfo, getQuestXP, XP_RULES } from '../utils/levels';
import { sound } from '../utils/soundEffects';
import { generateComebackPlan, evaluateQuestSubmission, generateTopicsForSkill, reviewLearningNotes, generateDailyQuizQuestions } from '../services/geminiService';
import { createAssignments, createMidwayProject, fallbackDailyQuestions, localDate, midwayUnlocked } from '../utils/dailyLearning';
import { GoalWorkspace, upsertGoalWorkspace } from '../utils/goalWorkspaces';

const STORAGE_KEYS = {
  USER: 'skillquest_user_v1',
  GOAL: 'skillquest_goal_v1',
  MILESTONES: 'skillquest_milestones_v1',
  QUESTS: 'skillquest_quests_v1',
  ACHIEVEMENTS: 'skillquest_achievements_v1',
  RESOURCES: 'skillquest_resources_v1',
  COHORTS: 'skillquest_cohorts_v1',
  LEADERBOARD: 'skillquest_leaderboard_v1',
  ACTIVITY: 'skillquest_activity_v1',
  COMEBACK: 'skillquest_comeback_v1',
  TOPICS: 'skillquest_topics_v1',
  DAILY_QUIZZES: 'skillquest_daily_quizzes_v1',
  DAILY_CREDITS: 'skillquest_daily_credits_v1',
  NOTES: 'skillquest_notes_v1',
  PORTFOLIO: 'skillquest_portfolio_v1',
  GOAL_WORKSPACES: 'skillquest_goal_workspaces_v2',
  ACTIVE_GOAL: 'skillquest_active_goal_v2',
};

function applyState<T>(current: T, next: React.SetStateAction<T>): T {
  return typeof next === 'function' ? (next as (value: T) => T)(current) : next;
}

interface CompletionResult {
  questTitle: string;
  xpAwarded: number;
  newLevel?: number;
  unlockedAchievements: Achievement[];
  milestoneCompleted?: Milestone;
}

interface SkillQuestContextType {
  user: User;
  goal: LearningGoal;
  goals: LearningGoal[];
  switchGoal: (goalId: string) => void;
  renameGoal: (goalId: string, name: string) => void;
  setGoalStatus: (goalId: string, status: 'active' | 'completed' | 'archived') => void;
  milestones: Milestone[];
  quests: Quest[];
  achievements: Achievement[];
  resources: LearningResource[];
  cohorts: Cohort[];
  leaderboard: LeaderboardUser[];
  activityHistory: DailyActivity[];
  comebackPlan: ComebackPlan | null;
  topics: Topic[];
  quizQuestions: QuizQuestion[];
  dailyQuizzes: DailyQuizRecord[];
  notes: LearningNote[];
  portfolio: PortfolioEntry[];
  dailyCredits: string[];
  lastCompletionResult: CompletionResult | null;
  clearLastCompletionResult: () => void;
  
  // Actions
  completeQuest: (questId: string, reflection?: string) => Promise<CompletionResult | null>;
  submitQuestForEvaluation: (
    questId: string,
    submission: { submissionType: SubmissionType; content: string; fileName?: string; fileSize?: string }
  ) => Promise<EvaluationResult>;
  answerBonusQuestion: (
    questId: string,
    questionId: string,
    selectedOption: number
  ) => { isCorrect: boolean; xpAwarded: number; bonusCompleted: boolean };
  addTopicToRoadmap: (topicId: string) => void;
  recordQuizScore: (score: number, total: number) => number;
  ensureDailyQuiz: () => Promise<DailyQuizRecord>;
  saveDailyQuizAnswers: (answers: Record<string, number>) => void;
  submitDailyQuiz: (answers: Record<string, number>) => { score: number; xpEarned: number };
  saveNote: (note: Partial<LearningNote> & { title: string; content: string; topic: string; context: string }) => LearningNote;
  reviewNote: (noteId: string, draft?: LearningNote) => Promise<NoteReview | null>;
  decideNoteIssue: (noteId: string, index: number, decision: 'accepted' | 'rejected') => void;
  addPdfNoteVersion: (noteId: string, version: PdfNoteVersion) => void;
  setPdfNoteReview: (noteId: string, versionId: string, review?: PdfNoteReview, error?: string) => void;
  savePortfolioEntry: (entry: Omit<PortfolioEntry, 'id' | 'savedAt' | 'userId' | 'goalId' | 'completedAt'>) => PortfolioEntry;
  resetQuest: (questId: string) => void;
  updateUser: (updatedUser: Partial<User>) => void;
  updateGoal: (updatedGoal: Partial<LearningGoal>) => void;
  setNewLearningRoadmap: (
    newGoal: LearningGoal,
    newMilestones: Milestone[],
    newQuests: Quest[],
    newResources: LearningResource[],
    newTopics?: Topic[],
    midwayTemplate?: Partial<Quest>
  ) => void;
  toggleSaveResource: (id: string) => void;
  toggleCompleteResource: (id: string) => void;
  joinCohort: (id: string) => void;
  leaveCohort: (id: string) => void;
  setOptInLeaderboard: (optIn: boolean) => void;
  triggerComebackPlan: (missedDays?: number) => Promise<void>;
  dismissComebackPlan: () => void;
  updateSettings: (settings: Partial<User['settings']>) => void;
  resetAllData: () => void;
  triggerConfetti: () => void;
}

const SkillQuestContext = createContext<SkillQuestContextType | undefined>(undefined);

function loadStorage<T>(key: string, defaultValue: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return defaultValue;
    return JSON.parse(raw);
  } catch (err) {
    console.warn(`Failed to parse localStorage key ${key}`, err);
    return defaultValue;
  }
}

export const SkillQuestProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User>(() => {
    const saved = loadStorage(STORAGE_KEYS.USER, INITIAL_USER);
    return { ...saved, settings: { ...saved.settings, geminiApiKey: '' } };
  });
  const [workspaces, setWorkspaces] = useState<GoalWorkspace[]>(() => {
    const saved = loadStorage<GoalWorkspace[] | null>(STORAGE_KEYS.GOAL_WORKSPACES, null);
    if (Array.isArray(saved) && saved.some(w => w?.goal?.userId === user.id)) return saved.filter(w => w?.goal?.userId === user.id);
    const legacyGoal = loadStorage(STORAGE_KEYS.GOAL, INITIAL_GOAL);
    const legacyMilestones = loadStorage(STORAGE_KEYS.MILESTONES, INITIAL_MILESTONES);
    const legacyQuests = loadStorage<Quest[]>(STORAGE_KEYS.QUESTS, INITIAL_QUESTS).map(q => ({
      ...q, xpReward: q.kind ? q.xpReward : getQuestXP(q.difficulty),
      submissions: (q.submissions || []).map(s => ({ ...s, content: s.content.startsWith('data:') ? '[Older media removed from browser storage]' : s.content })),
    }));
    const core = legacyQuests.filter(q => !q.kind);
    const existingIds = new Set(legacyQuests.map(q => q.id));
    const midway = createMidwayProject(legacyGoal, legacyMilestones, core);
    return [{ goal: { ...legacyGoal, status: legacyGoal.status || 'active' }, milestones: legacyMilestones,
      quests: [...legacyQuests, ...createAssignments(legacyGoal, core, localDate(user.settings.timeZone)).filter(q => !existingIds.has(q.id)), ...(midway && !existingIds.has(midway.id) ? [midway] : [])],
      resources: loadStorage(STORAGE_KEYS.RESOURCES, INITIAL_RESOURCES), topics: loadStorage(STORAGE_KEYS.TOPICS, INITIAL_TOPICS),
      comebackPlan: loadStorage(STORAGE_KEYS.COMEBACK, null) }];
  });
  const [activeGoalId, setActiveGoalId] = useState<string>(() => {
    const saved = loadStorage(STORAGE_KEYS.ACTIVE_GOAL, workspaces[0].goal.id);
    return workspaces.some(w => w.goal.id === saved) ? saved : workspaces[0].goal.id;
  });
  const activeWorkspace = workspaces.find(w => w.goal.id === activeGoalId) || workspaces[0];
  const goal = activeWorkspace.goal;
  const milestones = activeWorkspace.milestones;
  const quests = activeWorkspace.quests;
  const resources = activeWorkspace.resources;
  const topics = activeWorkspace.topics;
  const comebackPlan = activeWorkspace.comebackPlan;
  const goals = workspaces.map(w => w.goal);
  const updateActive = (change: (w: GoalWorkspace) => GoalWorkspace) => setWorkspaces(prev => prev.map(w => w.goal.id === activeGoalId ? change(w) : w));
  const setGoal: React.Dispatch<React.SetStateAction<LearningGoal>> = next => updateActive(w => ({ ...w, goal: applyState(w.goal, next) }));
  const setMilestones: React.Dispatch<React.SetStateAction<Milestone[]>> = next => updateActive(w => ({ ...w, milestones: applyState(w.milestones, next) }));
  const setQuests: React.Dispatch<React.SetStateAction<Quest[]>> = next => updateActive(w => ({ ...w, quests: applyState(w.quests, next) }));
  const setResources: React.Dispatch<React.SetStateAction<LearningResource[]>> = next => updateActive(w => ({ ...w, resources: applyState(w.resources, next) }));
  const setTopics: React.Dispatch<React.SetStateAction<Topic[]>> = next => updateActive(w => ({ ...w, topics: applyState(w.topics, next) }));
  const setComebackPlan: React.Dispatch<React.SetStateAction<ComebackPlan | null>> = next => updateActive(w => ({ ...w, comebackPlan: applyState(w.comebackPlan, next) }));
  const [achievements, setAchievements] = useState<Achievement[]>(() => loadStorage(STORAGE_KEYS.ACHIEVEMENTS, INITIAL_ACHIEVEMENTS));
  const [cohorts, setCohorts] = useState<Cohort[]>(() => loadStorage(STORAGE_KEYS.COHORTS, INITIAL_COHORTS));
  const [leaderboard, setLeaderboard] = useState<LeaderboardUser[]>(() => loadStorage(STORAGE_KEYS.LEADERBOARD, INITIAL_LEADERBOARD));
  const [activityHistory, setActivityHistory] = useState<DailyActivity[]>(() =>
    loadStorage(STORAGE_KEYS.ACTIVITY, generateInitialActivityHistory())
  );
  const [quizQuestions] = useState<QuizQuestion[]>(INITIAL_QUIZ_QUESTIONS);
  const [dailyQuizzes, setDailyQuizzes] = useState<DailyQuizRecord[]>(() => loadStorage(STORAGE_KEYS.DAILY_QUIZZES, []));
  const [dailyCredits, setDailyCredits] = useState<string[]>(() => loadStorage<string[]>(STORAGE_KEYS.DAILY_CREDITS, []).map(credit => credit.includes(':') ? credit : `${workspaces[0].goal.id}:${credit}`));
  const [notes, setNotes] = useState<LearningNote[]>(() => loadStorage<LearningNote[]>(STORAGE_KEYS.NOTES, []).map(note => ({ ...note, goalId: note.goalId || workspaces.find(w => w.goal.skill === note.skill)?.goal.id || workspaces[0].goal.id })));
  const [portfolio, setPortfolio] = useState<PortfolioEntry[]>(() => loadStorage(STORAGE_KEYS.PORTFOLIO, []));
  const [lastCompletionResult, setLastCompletionResult] = useState<CompletionResult | null>(null);
  const evaluatingQuests = useRef(new Set<string>());
  const awardedQuests = useRef(new Set<string>());
  const awardedBonusQuestions = useRef(new Set<string>());
  const dailyCreditLock = useRef(new Set(dailyCredits.map(credit => credit.slice(-10))));
  const dailyQuizSubmissionLock = useRef(new Set<string>());
  const createdDailyQuizzes = useRef(new Map<string, DailyQuizRecord>());
  const pendingDailyQuizzes = useRef(new Map<string, Promise<DailyQuizRecord>>());

  // Sync sound settings with sound utility
  useEffect(() => {
    sound.setEnabled(user.settings.soundEffects);
  }, [user.settings.soundEffects]);
  useEffect(() => {
    const preference = user.settings.theme || 'system';
    const apply = () => document.documentElement.classList.toggle('dark', preference === 'dark' || preference === 'system' && matchMedia('(prefers-color-scheme: dark)').matches);
    apply();
    const media = matchMedia('(prefers-color-scheme: dark)');
    media.addEventListener('change', apply);
    return () => media.removeEventListener('change', apply);
  }, [user.settings.theme]);

  // Persist to localStorage on change
  useEffect(() => { localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(user)); }, [user]);
  useEffect(() => { localStorage.setItem(STORAGE_KEYS.GOAL_WORKSPACES, JSON.stringify(workspaces)); }, [workspaces]);
  useEffect(() => { localStorage.setItem(STORAGE_KEYS.ACTIVE_GOAL, JSON.stringify(activeGoalId)); }, [activeGoalId]);
  useEffect(() => { localStorage.setItem(STORAGE_KEYS.GOAL, JSON.stringify(goal)); }, [goal]);
  useEffect(() => { localStorage.setItem(STORAGE_KEYS.MILESTONES, JSON.stringify(milestones)); }, [milestones]);
  useEffect(() => { localStorage.setItem(STORAGE_KEYS.QUESTS, JSON.stringify(quests)); }, [quests]);
  useEffect(() => { localStorage.setItem(STORAGE_KEYS.ACHIEVEMENTS, JSON.stringify(achievements)); }, [achievements]);
  useEffect(() => { localStorage.setItem(STORAGE_KEYS.RESOURCES, JSON.stringify(resources)); }, [resources]);
  useEffect(() => { localStorage.setItem(STORAGE_KEYS.COHORTS, JSON.stringify(cohorts)); }, [cohorts]);
  useEffect(() => { localStorage.setItem(STORAGE_KEYS.LEADERBOARD, JSON.stringify(leaderboard)); }, [leaderboard]);
  useEffect(() => { localStorage.setItem(STORAGE_KEYS.ACTIVITY, JSON.stringify(activityHistory)); }, [activityHistory]);
  useEffect(() => { localStorage.setItem(STORAGE_KEYS.COMEBACK, JSON.stringify(comebackPlan)); }, [comebackPlan]);
  useEffect(() => { localStorage.setItem(STORAGE_KEYS.TOPICS, JSON.stringify(topics)); }, [topics]);
  useEffect(() => { localStorage.setItem(STORAGE_KEYS.DAILY_QUIZZES, JSON.stringify(dailyQuizzes)); }, [dailyQuizzes]);
  useEffect(() => { localStorage.setItem(STORAGE_KEYS.DAILY_CREDITS, JSON.stringify(dailyCredits)); }, [dailyCredits]);
  useEffect(() => { localStorage.setItem(STORAGE_KEYS.NOTES, JSON.stringify(notes)); }, [notes]);
  useEffect(() => { localStorage.setItem(STORAGE_KEYS.PORTFOLIO, JSON.stringify(portfolio)); }, [portfolio]);

  const triggerConfetti = () => {
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#6366f1', '#10b981', '#f59e0b', '#8b5cf6', '#3b82f6'],
      });
    } catch {
      // Confetti fallback
    }
  };

  const clearLastCompletionResult = () => setLastCompletionResult(null);

  const creditDailyGoalIfReady = (clearedAssignmentId?: string, completedQuizDate?: string) => {
    const date = localDate(user.settings.timeZone);
    const creditKey = `${goal.id}:${date}`;
    const assignment = quests.find(q => q.kind === 'assignment' && q.goalId === goal.id && q.scheduledDate === date);
    const assignmentDone = !assignment || assignment.status === 'completed' || assignment.id === clearedAssignmentId;
    const quizDone = completedQuizDate === date || dailyQuizzes.some(q => q.userId === user.id && q.goalId === goal.id && q.localDate === date && q.completedAt);
    if (!assignmentDone || !quizDone || dailyCredits.includes(creditKey)) return;
    setDailyCredits(prev => prev.includes(creditKey) ? prev : [...prev, creditKey]);
    if (dailyCreditLock.current.has(date)) return;
    dailyCreditLock.current.add(date);
    const [year, month, day] = date.split('-').map(Number);
    const previousDate = localDate('UTC', new Date(Date.UTC(year, month - 1, day - 1)));
    setUser(prev => {
      const last = prev.lastActiveDate ? localDate(prev.settings.timeZone, new Date(prev.lastActiveDate)) : '';
      const streak = last === previousDate ? prev.currentStreak + 1 : last === date ? prev.currentStreak : 1;
      return { ...prev, currentStreak: streak, longestStreak: Math.max(prev.longestStreak, streak), lastActiveDate: new Date().toISOString() };
    });
    setActivityHistory(prev => prev.some(a => a.date === date)
      ? prev.map(a => a.date === date ? { ...a, count: 1, level: Math.max(1, a.level) } : a)
      : [...prev.slice(1), { date, count: 1, xp: 0, level: 1 }]);
  };

  /**
   * Submit practical evidence for a quest and evaluate with AI
   */
  const submitQuestForEvaluation = async (
    questId: string,
    submission: { submissionType: SubmissionType; content: string; fileName?: string; fileSize?: string }
  ): Promise<EvaluationResult> => {
    const targetQuest = quests.find(q => q.id === questId);
    if (!targetQuest) {
      throw new Error('Quest not found');
    }
    if (targetQuest.status === 'completed' || awardedQuests.current.has(questId)) {
      throw new Error('This quest has already been cleared.');
    }
    if (targetQuest.kind === 'midway' && !midwayUnlocked(targetQuest, milestones)) throw new Error('Complete the prerequisite milestones to unlock the midway project.');
    if (evaluatingQuests.current.has(questId)) throw new Error('This quest is already under evaluation.');
    evaluatingQuests.current.add(questId);
    setQuests(prev => prev.map(q => q.id === questId ? { ...q, evaluationStatus: 'under_evaluation' } : q));

    try {
    const evaluation = await evaluateQuestSubmission({
      quest: targetQuest,
      submissionType: submission.submissionType,
      content: submission.content,
      fileName: submission.fileName,
      fileSize: submission.fileSize,
      apiKey: user.settings.geminiApiKey,
    });

    const newSubmission: QuestSubmission = {
      id: `sub_${Date.now()}`,
      questId,
      userId: user.id,
      attemptNumber: (targetQuest.submissions?.length || 0) + 1,
      submissionType: submission.submissionType,
      // Keep attempt metadata and feedback, but never persist private media locally.
      content: submission.content.startsWith('data:') ? '[Media sent for evaluation and discarded]' : submission.content.slice(0, 12000),
      fileName: submission.fileName,
      fileSize: submission.fileSize,
      submittedAt: new Date().toISOString(),
      evaluation,
    };

    // If cleared, award completion XP and mark as completed
    if (evaluation.status === 'cleared') {
      await completeQuest(questId, `Cleared with score ${evaluation.score}/100: ${evaluation.feedback}`, evaluation);
    }

    // Update quest with the new submission and latest evaluation
    setQuests(prev =>
      prev.map(q => {
        if (q.id === questId) {
          return {
            ...q,
            submissions: [newSubmission, ...(q.submissions || [])],
            latestEvaluation: evaluation,
            evaluationStatus: evaluation.status,
            evaluationScore: evaluation.score,
            evaluationFeedback: evaluation.feedback,
          };
        }
        return q;
      })
    );

    return evaluation;
    } finally {
      evaluatingQuests.current.delete(questId);
    }
  };

  /**
   * Answer a bonus conceptual question for immediate Bonus XP
   */
  const answerBonusQuestion = (
    questId: string,
    questionId: string,
    selectedOption: number
  ): { isCorrect: boolean; xpAwarded: number; bonusCompleted: boolean } => {
    const targetQuest = quests.find(q => q.id === questId);
    if (!targetQuest || !targetQuest.bonusQuestions) {
      return { isCorrect: false, xpAwarded: 0, bonusCompleted: false };
    }

    const bq = targetQuest.bonusQuestions.find(b => b.id === questionId);
    if (!bq) {
      return { isCorrect: false, xpAwarded: 0, bonusCompleted: false };
    }

    // If already answered correctly, do not award repeated XP
    const bonusRewardKey = `${questId}:${questionId}`;
    if (bq.isCorrect || awardedBonusQuestions.current.has(bonusRewardKey)) {
      return { isCorrect: true, xpAwarded: 0, bonusCompleted: targetQuest.bonusCompleted || false };
    }

    const isCorrect = selectedOption === bq.correctAnswer;
    let xpAwarded = 0;

    if (isCorrect) {
      awardedBonusQuestions.current.add(bonusRewardKey);
      xpAwarded = bq.xpReward || 10;
    }

    let allCompleted = false;

    const updatedBonusQuestions = targetQuest.bonusQuestions.map(b => {
      if (b.id === questionId) {
        return {
          ...b,
          userAnswer: selectedOption,
          isCorrect,
        };
      }
      return b;
    });

    // Check if all bonus questions are answered correctly
    const allCorrect = updatedBonusQuestions.length > 0 && updatedBonusQuestions.every(b => b.isCorrect);
    if (allCorrect && !targetQuest.bonusCompleted) {
      allCompleted = true;
      xpAwarded += 25; // Bonus completion reward!
      sound.playBadgeUnlock();
      triggerConfetti();

      // Check achievement
      setAchievements(prev =>
        prev.map(a => a.id === 'ach_bonus_master' ? { ...a, earned: true, earnedAt: new Date().toISOString() } : a)
      );
    } else if (isCorrect) {
      sound.playQuestComplete();
    }

    // Update user XP
    if (xpAwarded > 0) {
      setUser(prev => ({
        ...prev,
        currentXP: prev.currentXP + xpAwarded,
        currentLevel: getLevelInfo(prev.currentXP + xpAwarded).level,
      }));
    }

    // Update quest
    setQuests(prev =>
      prev.map(q => {
        if (q.id === questId) {
          return {
            ...q,
            bonusQuestions: updatedBonusQuestions,
            bonusCompleted: allCorrect || q.bonusCompleted,
            bonusXpEarned: (q.bonusXpEarned || 0) + xpAwarded,
          };
        }
        return q;
      })
    );

    return { isCorrect, xpAwarded, bonusCompleted: allCompleted };
  };

  const dailyQuizKey = () => `${user.id}:${goal.id}:${localDate(user.settings.timeZone)}`;
  const ensureDailyQuiz = async (): Promise<DailyQuizRecord> => {
    const id = dailyQuizKey();
    const existing = dailyQuizzes.find(record => record.id === id) || createdDailyQuizzes.current.get(id);
    if (existing) return existing;
    if (pendingDailyQuizzes.current.has(id)) return pendingDailyQuizzes.current.get(id)!;
    const task = (async () => {
      const aiQuestions = await generateDailyQuizQuestions(goal.skill, goal.currentLevel, milestones, quests);
      const questions = aiQuestions || fallbackDailyQuestions(goal, milestones, quests, quizQuestions);
      const record: DailyQuizRecord = { id, userId: user.id, goalId: goal.id, localDate: localDate(user.settings.timeZone), questions, source: aiQuestions ? 'ai' : 'learning-plan-review', answers: {} };
      createdDailyQuizzes.current.set(id, record);
      setDailyQuizzes(prev => prev.some(q => q.id === id) ? prev : [...prev, record]);
      return record;
    })();
    pendingDailyQuizzes.current.set(id, task);
    try { return await task; } finally { pendingDailyQuizzes.current.delete(id); }
  };

  const saveDailyQuizAnswers = (answers: Record<string, number>) => {
    const id = dailyQuizKey();
    setDailyQuizzes(prev => prev.map(q => q.id === id && !q.completedAt ? { ...q, answers } : q));
  };

  const submitDailyQuiz = (answers: Record<string, number>): { score: number; xpEarned: number } => {
    const record = dailyQuizzes.find(q => q.id === dailyQuizKey()) || createdDailyQuizzes.current.get(dailyQuizKey());
    if (!record) throw new Error('Daily quiz is still loading.');
    if (record.questions.length !== 10 || record.questions.some(q => !Number.isInteger(answers[q.id]) || answers[q.id] < 0 || answers[q.id] >= q.options.length)) {
      throw new Error('Answer all 10 questions before submitting.');
    }
    if (record.completedAt || dailyQuizSubmissionLock.current.has(record.id)) return { score: record.score || 0, xpEarned: 0 };
    dailyQuizSubmissionLock.current.add(record.id);
    const score = record.questions.reduce((sum, q) => sum + Number(answers[q.id] === q.correctAnswer), 0);
    const xpEarned = score * 5 + (score === 10 ? 25 : 0);
    const completedAt = new Date().toISOString();
    createdDailyQuizzes.current.set(record.id, { ...record, answers, score, xpEarned, completedAt });
    setDailyQuizzes(prev => prev.map(q => q.id === record.id ? { ...q, answers, score, xpEarned, completedAt } : q));
    if (xpEarned) setUser(prev => ({ ...prev, currentXP: prev.currentXP + xpEarned, currentLevel: getLevelInfo(prev.currentXP + xpEarned).level }));
    creditDailyGoalIfReady(undefined, record.localDate);
    return { score, xpEarned };
  };

  const saveNote = (input: Partial<LearningNote> & { title: string; content: string; topic: string; context: string }): LearningNote => {
    const existing = notes.find(n => n.id === input.id && n.userId === user.id && n.goalId === goal.id);
    const now = new Date().toISOString();
    const note: LearningNote = {
      id: existing?.id || `note_${crypto.randomUUID()}`, userId: user.id, goalId: goal.id, skill: goal.skill,
      title: input.title.trim().slice(0, 120) || 'Untitled notes', topic: input.topic.trim().slice(0, 120),
      questId: input.questId || existing?.questId, resourceId: input.resourceId || existing?.resourceId,
      context: input.context.slice(0, 6000), content: input.content.slice(0, 20000),
      createdAt: existing?.createdAt || now, updatedAt: now,
      review: existing?.content === input.content ? existing?.review : undefined,
      revisions: existing ? [...existing.revisions, ...(existing.content !== input.content ? [{ content: existing.content, savedAt: now }] : [])].slice(-20) : [],
      pdfVersions: existing?.pdfVersions || [],
    };
    setNotes(prev => existing ? prev.map(n => n.id === note.id ? note : n) : [note, ...prev]);
    return note;
  };

  const reviewNote = async (noteId: string, draft?: LearningNote): Promise<NoteReview | null> => {
    const note = draft?.id === noteId && draft.userId === user.id && draft.goalId === goal.id ? draft : notes.find(n => n.id === noteId && n.userId === user.id && n.goalId === goal.id);
    if (!note || !note.content.trim()) return null;
    try {
      const review = await reviewLearningNotes(note.content, note.context, note.skill);
      setNotes(prev => prev.map(n => n.id === noteId && n.userId === user.id && n.goalId === goal.id ? { ...n, review, reviewError: undefined } : n));
      return review;
    } catch (error) {
      setNotes(prev => prev.map(n => n.id === noteId && n.userId === user.id && n.goalId === goal.id ? { ...n, reviewError: error instanceof Error ? error.message : 'Review unavailable.' } : n));
      return null;
    }
  };

  const decideNoteIssue = (noteId: string, index: number, decision: 'accepted' | 'rejected') => {
    setNotes(prev => prev.map(note => {
      if (note.id !== noteId || note.userId !== user.id || note.goalId !== goal.id || !note.review?.issues[index]) return note;
      const issue = note.review.issues[index];
      const issues = note.review.issues.map((item, i) => i === index ? { ...item, decision } : item);
      const replace = decision === 'accepted' && issue.passage && issue.suggestedCorrection && note.content.includes(issue.passage);
      return { ...note, content: replace ? note.content.replace(issue.passage, issue.suggestedCorrection) : note.content,
        revisions: replace ? [...note.revisions, { content: note.content, savedAt: new Date().toISOString() }].slice(-20) : note.revisions,
        review: { ...note.review, issues }, updatedAt: new Date().toISOString() };
    }));
  };

  const addPdfNoteVersion = (noteId: string, version: PdfNoteVersion) => {
    setNotes(prev => prev.map(note => note.id === noteId && note.userId === user.id && note.goalId === goal.id
      ? { ...note, pdfVersions: [...(note.pdfVersions || []), version], updatedAt: version.uploadedAt }
      : note));
  };

  const setPdfNoteReview = (noteId: string, versionId: string, review?: PdfNoteReview, error?: string) => {
    setNotes(prev => prev.map(note => note.id === noteId && note.userId === user.id && note.goalId === goal.id
      ? { ...note, pdfVersions: (note.pdfVersions || []).map(version => version.id === versionId ? {
          ...version,
          review: review || version.review,
          reviewHistory: review && version.review ? [...(version.reviewHistory || []), version.review].slice(-3) : version.reviewHistory,
          reviewError: error,
        } : version) }
      : note));
  };

  const savePortfolioEntry = (entry: Omit<PortfolioEntry, 'id' | 'savedAt' | 'userId' | 'goalId' | 'completedAt'>): PortfolioEntry => {
    const project = quests.find(q => q.id === entry.questId && q.kind === 'midway' && q.goalId === goal.id && q.status === 'completed' && q.latestEvaluation?.status === 'cleared');
    if (!project) throw new Error('Only a verified, cleared midway project can be added to the portfolio.');
    const saved: PortfolioEntry = {
      ...entry, id: `portfolio_${project.id}`, userId: user.id, goalId: goal.id,
      title: entry.title.trim().slice(0, 160), description: entry.description.trim().slice(0, 1000),
      skills: entry.skills.map(s => s.trim()).filter(Boolean).slice(0, 15),
      tools: entry.tools.trim().slice(0, 250), outcome: entry.outcome.trim().slice(0, 500),
      evidenceLink: entry.evidenceLink && /^https:\/\//.test(entry.evidenceLink) ? entry.evidenceLink : undefined,
      completedAt: project.completedAt!, savedAt: new Date().toISOString(),
    };
    setPortfolio(prev => [saved, ...prev.filter(p => p.id !== saved.id)]);
    return saved;
  };

  /**
   * Complete a quest with XP award, streak updating, milestone checking, achievement unlocking
   */
  const completeQuest = async (questId: string, reflection?: string, verifiedEvaluation?: EvaluationResult): Promise<CompletionResult | null> => {
    const targetQuest = quests.find(q => q.id === questId);
    if (!targetQuest) return null;
    if (verifiedEvaluation?.status !== 'cleared' || awardedQuests.current.has(questId)) return null;

    // A quest should not award XP repeatedly if it has already been completed
    if (targetQuest.status === 'completed') {
      return null;
    }
    if (targetQuest.kind === 'midway' && !midwayUnlocked(targetQuest, milestones)) return null;
    awardedQuests.current.add(questId);

    // Calculate XP
    const xpToAward = targetQuest.kind ? targetQuest.xpReward : getQuestXP(targetQuest.difficulty);

    const newTotalXP = user.currentXP + xpToAward;
    const oldLevelInfo = getLevelInfo(user.currentXP);
    const newLevelInfo = getLevelInfo(newTotalXP);
    const hasLeveledUp = newLevelInfo.level > oldLevelInfo.level;

    // Update quest status
    const updatedQuests = quests.map(q => {
      if (q.id === questId) {
        return {
          ...q,
          status: 'completed' as const,
          completedAt: new Date().toISOString(),
          reflection: reflection || q.reflection,
        };
      }
      return q;
    });
    setQuests(updatedQuests);

    // Update user state
    setUser(prev => ({
      ...prev,
      currentXP: prev.currentXP + xpToAward,
      currentLevel: getLevelInfo(prev.currentXP + xpToAward).level,
      assignmentXP: (prev.assignmentXP || 0) + (targetQuest.kind === 'assignment' ? xpToAward : 0),
      projectXP: (prev.projectXP || 0) + (targetQuest.kind === 'midway' ? xpToAward : 0),
    }));
    if (targetQuest.kind === 'assignment' && targetQuest.scheduledDate === localDate(user.settings.timeZone)) creditDailyGoalIfReady(targetQuest.id);

    // Check Milestone completion
    let completedMilestoneObj: Milestone | undefined;
    const associatedMilestone = milestones.find(m => m.id === targetQuest.milestoneId);
    let updatedMilestones = [...milestones];

    if (associatedMilestone && associatedMilestone.status !== 'completed') {
      const milestoneQuests = updatedQuests.filter(q => q.milestoneId === associatedMilestone.id && !q.kind);
      const allDone = milestoneQuests.length > 0 && milestoneQuests.every(q => q.status === 'completed');

      if (allDone) {
        completedMilestoneObj = {
          ...associatedMilestone,
          status: 'completed',
          completedAt: new Date().toISOString(),
        };

        updatedMilestones = milestones.map(m => {
          if (m.id === associatedMilestone.id) {
            return completedMilestoneObj!;
          }
          if (m.sequence === associatedMilestone.sequence + 1 && m.status === 'locked') {
            return { ...m, status: 'in-progress' as const };
          }
          return m;
        });

        setMilestones(updatedMilestones);
        setUser(u => {
          const total = u.currentXP + XP_RULES.MILESTONE_COMPLETION;
          return { ...u, currentXP: total, currentLevel: getLevelInfo(total).level };
        });
      }
    }

    // Recalculate overall goal progress
    const totalAllQuests = updatedQuests.filter(q => !q.kind).length;
    const completedAllQuests = updatedQuests.filter(q => !q.kind && q.status === 'completed').length;
    const newGoalProgress = totalAllQuests > 0 ? Math.round((completedAllQuests / totalAllQuests) * 100) : 0;
    setGoal(g => ({ ...g, overallProgress: newGoalProgress, updatedAt: new Date().toISOString() }));

    // Check and unlock achievements
    const newlyUnlockedAchievements: Achievement[] = [];
    const updatedAchievements = achievements.map(ach => {
      if (ach.earned) return ach;
      let shouldUnlock = false;

      if (ach.id === 'ach_first_quest') {
        shouldUnlock = true;
      } else if (ach.id === 'ach_streak_3' && user.currentStreak >= 3) {
        shouldUnlock = true;
      } else if (ach.id === 'ach_streak_7' && user.currentStreak >= 7) {
        shouldUnlock = true;
      } else if (ach.id === 'ach_consistency_14' && user.currentStreak >= 14) {
        shouldUnlock = true;
      } else if (ach.id === 'ach_first_milestone' && completedMilestoneObj) {
        shouldUnlock = true;
      } else if (ach.id === 'ach_comeback_hero' && targetQuest.isComebackQuest) {
        shouldUnlock = true;
      } else if (ach.id === 'ach_xp_500' && newTotalXP >= 500) {
        shouldUnlock = true;
      } else if (ach.id === 'ach_roadmap_completed' && newGoalProgress >= 100) {
        shouldUnlock = true;
      }

      if (shouldUnlock) {
        const unlocked = { ...ach, earned: true, earnedAt: new Date().toISOString() };
        newlyUnlockedAchievements.push(unlocked);
        return unlocked;
      }
      return ach;
    });

    if (newlyUnlockedAchievements.length > 0) {
      setAchievements(updatedAchievements);
      sound.playBadgeUnlock();
    } else {
      sound.playQuestComplete();
    }

    triggerConfetti();

    // Update leaderboard if user is listed
    setLeaderboard(prev =>
      prev.map(item =>
        item.isCurrentUser
          ? {
              ...item,
              xpEarned: newTotalXP,
              streak: user.currentStreak,
              completedQuests: item.completedQuests + 1,
              badge: newLevelInfo.title,
            }
          : item
      ).sort((a, b) => b.xpEarned - a.xpEarned)
      .map((entry, idx) => ({ ...entry, rank: idx + 1 }))
    );

    const result: CompletionResult = {
      questTitle: targetQuest.title,
      xpAwarded: xpToAward,
      newLevel: hasLeveledUp ? newLevelInfo.level : undefined,
      unlockedAchievements: newlyUnlockedAchievements,
      milestoneCompleted: completedMilestoneObj,
    };

    setLastCompletionResult(result);
    return result;
  };

  /**
   * Add an additional topic into the learner's active roadmap
   */
  const addTopicToRoadmap = (topicId: string) => {
    const topic = topics.find(t => t.id === topicId);
    if (!topic || topic.isAddedToRoadmap) return;

    // Mark topic as added
    setTopics(prev => prev.map(t => t.id === topicId ? { ...t, isAddedToRoadmap: true } : t));

    // Create a new Milestone for this topic
    const newMilestoneSequence = milestones.length + 1;
    const newMilestone: Milestone = {
      id: `ms_topic_${goal.id}_${crypto.randomUUID()}`,
      goalId: goal.id,
      sequence: newMilestoneSequence,
      title: topic.name,
      description: topic.description,
      status: 'in-progress',
      criteria: [topic.practicalExercise],
      estimatedWeeks: 1,
    };

    // Create a practical quest for this topic
    const newQuest: Quest = {
      id: `qst_topic_${goal.id}_${crypto.randomUUID()}`,
      milestoneId: newMilestone.id,
      title: topic.practicalQuestTemplate?.title || `Practical Exercise: ${topic.name}`,
      description: topic.practicalQuestTemplate?.description || topic.practicalExercise,
      durationMinutes: topic.practicalQuestTemplate?.durationMinutes || 25,
      difficulty: topic.difficulty,
      xpReward: getQuestXP(topic.difficulty),
      status: 'todo',
      isToday: false,
      instructions: [
        `Review the recommended resource: ${topic.recommendedResources[0]?.title || 'Topic documentation'}`,
        `Execute the practical exercise: ${topic.practicalExercise}`,
        `Submit your implementation evidence for AI evaluation.`
      ],
      submissionType: topic.practicalQuestTemplate?.submissionType || 'code',
      submissionRequirements: topic.practicalQuestTemplate?.submissionRequirements || 'Submit your code or output evidence proving completion.',
      rubric: topic.practicalQuestTemplate?.rubric || [
        { id: 'r1', criterion: 'Core Implementation', description: 'Implements the concepts covered in the topic.' }
      ],
      submissions: [],
    };

    setMilestones(prev => [...prev, newMilestone]);
    setQuests(prev => [...prev, newQuest]);
    sound.playBadgeUnlock();
    triggerConfetti();
  };

  /**
   * Record Quiz completion and award XP
   */
  const recordQuizScore = (score: number, total: number): number => {
    const xpPerCorrect = 15;
    const bonusAllCorrect = score === total ? 25 : 0;
    const xpEarned = (score * xpPerCorrect) + bonusAllCorrect;

    if (xpEarned > 0) {
      const newTotalXP = user.currentXP + xpEarned;
      const newLevelInfo = getLevelInfo(newTotalXP);
      setUser(prev => ({
        ...prev,
        currentXP: newTotalXP,
        currentLevel: newLevelInfo.level,
      }));

      sound.playBadgeUnlock();
      triggerConfetti();
    }

    return xpEarned;
  };

  const resetQuest = (questId: string) => {
    setQuests(prev =>
      prev.map(q =>
        q.id === questId && q.status !== 'completed'
          ? {
              ...q,
              status: 'todo' as const,
              completedAt: undefined,
            }
          : q
      )
    );
  };

  const updateUser = (updatedUser: Partial<User>) => {
    setUser(prev => ({ ...prev, ...updatedUser }));
  };

  const updateGoal = (updatedGoal: Partial<LearningGoal>) => {
    setGoal(prev => ({ ...prev, ...updatedGoal }));
  };

  const switchGoal = (goalId: string) => {
    if (!workspaces.some(w => w.goal.id === goalId && w.goal.userId === user.id)) return;
    setActiveGoalId(goalId);
    setLastCompletionResult(null);
  };

  const renameGoal = (goalId: string, name: string) => {
    const displayName = name.trim().slice(0, 100);
    if (!displayName) return;
    setWorkspaces(prev => prev.map(w => w.goal.id === goalId && w.goal.userId === user.id ? { ...w, goal: { ...w.goal, displayName, updatedAt: new Date().toISOString() } } : w));
  };

  const setGoalStatus = (goalId: string, status: 'active' | 'completed' | 'archived') => {
    const target = workspaces.find(w => w.goal.id === goalId && w.goal.userId === user.id);
    if (!target) return;
    setWorkspaces(prev => prev.map(w => w.goal.id === goalId ? { ...w, goal: { ...w.goal, status, updatedAt: new Date().toISOString() } } : w));
    if (goalId === activeGoalId && status === 'archived') {
      const next = workspaces.find(w => w.goal.id !== goalId && w.goal.status !== 'archived');
      if (next) setActiveGoalId(next.goal.id);
    }
  };

  const setNewLearningRoadmap = (
    newGoal: LearningGoal,
    newMilestones: Milestone[],
    newQuests: Quest[],
    newResources: LearningResource[],
    newTopics?: Topic[],
    midwayTemplate?: Partial<Quest>
  ) => {
    const core = newQuests.map(q => ({ ...q, xpReward: getQuestXP(q.difficulty) }));
    const midway = createMidwayProject(newGoal, newMilestones, core, midwayTemplate);
    const nextWorkspace: GoalWorkspace = { goal: { ...newGoal, status: newGoal.status || 'active' }, milestones: newMilestones,
      quests: [...core, ...createAssignments(newGoal, core, localDate(user.settings.timeZone)), ...(midway ? [midway] : [])],
      resources: newResources, topics: newTopics?.length ? newTopics : generateTopicsForSkill(newGoal.skill), comebackPlan: null };
    setWorkspaces(prev => upsertGoalWorkspace(prev, nextWorkspace));
    setActiveGoalId(newGoal.id);
    awardedQuests.current.clear();
    awardedBonusQuestions.current.clear();
  };

  const toggleSaveResource = (id: string) => {
    setResources(prev => prev.map(r => (r.id === id ? { ...r, saved: !r.saved } : r)));
  };

  const toggleCompleteResource = (id: string) => {
    setResources(prev => prev.map(r => (r.id === id ? { ...r, completed: !r.completed } : r)));
  };

  const joinCohort = (id: string) => {
    setCohorts(prev => prev.map(c => (c.id === id ? { ...c, isJoined: true, membersCount: c.membersCount + 1 } : c)));
  };

  const leaveCohort = (id: string) => {
    setCohorts(prev => prev.map(c => (c.id === id ? { ...c, isJoined: false, membersCount: Math.max(0, c.membersCount - 1) } : c)));
  };

  const setOptInLeaderboard = (optIn: boolean) => {
    setUser(prev => ({
      ...prev,
      settings: { ...prev.settings, optInLeaderboard: optIn },
    }));
  };

  const triggerComebackPlan = async (missedDays = 3) => {
    const currentMilestone = milestones.find(m => m.status === 'in-progress') || milestones[0];
    const plan = await generateComebackPlan({
      skill: goal.skill,
      missedDays,
      currentMilestoneTitle: currentMilestone ? currentMilestone.title : goal.skill,
      apiKey: user.settings.geminiApiKey,
    });
    const normalized = { ...plan, dailyQuests: plan.dailyQuests.map(q => ({ ...q, xpReward: getQuestXP(q.difficulty) })) };
    setComebackPlan(normalized);
    setQuests(prev => [...normalized.dailyQuests, ...prev]);
  };

  const dismissComebackPlan = () => {
    setComebackPlan(null);
  };

  const updateSettings = (settings: Partial<User['settings']>) => {
    setUser(prev => ({
      ...prev,
      settings: { ...prev.settings, ...settings },
    }));
  };

  const resetAllData = () => {
    localStorage.clear();
    setUser(INITIAL_USER);
    const resetCore = INITIAL_QUESTS.map(q => ({ ...q, xpReward: getQuestXP(q.difficulty) }));
    const resetMidway = createMidwayProject(INITIAL_GOAL, INITIAL_MILESTONES, resetCore);
    setWorkspaces([{ goal: INITIAL_GOAL, milestones: INITIAL_MILESTONES,
      quests: [...resetCore, ...createAssignments(INITIAL_GOAL, resetCore), ...(resetMidway ? [resetMidway] : [])],
      resources: INITIAL_RESOURCES, topics: INITIAL_TOPICS, comebackPlan: null }]);
    setActiveGoalId(INITIAL_GOAL.id);
    setAchievements(INITIAL_ACHIEVEMENTS);
    setCohorts(INITIAL_COHORTS);
    setLeaderboard(INITIAL_LEADERBOARD);
    setActivityHistory(generateInitialActivityHistory());
    setDailyQuizzes([]);
    setDailyCredits([]);
    setNotes([]);
    setPortfolio([]);
    dailyCreditLock.current.clear();
    dailyQuizSubmissionLock.current.clear();
    createdDailyQuizzes.current.clear();
    pendingDailyQuizzes.current.clear();
    setLastCompletionResult(null);
  };

  return (
    <SkillQuestContext.Provider
      value={{
        user,
        goal,
        goals,
        switchGoal,
        renameGoal,
        setGoalStatus,
        milestones,
        quests,
        achievements,
        resources,
        cohorts,
        leaderboard,
        activityHistory,
        comebackPlan,
        topics,
        quizQuestions,
        dailyQuizzes,
        dailyCredits,
        notes,
        portfolio,
        lastCompletionResult,
        clearLastCompletionResult,
        completeQuest,
        submitQuestForEvaluation,
        answerBonusQuestion,
        addTopicToRoadmap,
        recordQuizScore,
        ensureDailyQuiz,
        saveDailyQuizAnswers,
        submitDailyQuiz,
        saveNote,
        reviewNote,
        decideNoteIssue,
        addPdfNoteVersion,
        setPdfNoteReview,
        savePortfolioEntry,
        resetQuest,
        updateUser,
        updateGoal,
        setNewLearningRoadmap,
        toggleSaveResource,
        toggleCompleteResource,
        joinCohort,
        leaveCohort,
        setOptInLeaderboard,
        triggerComebackPlan,
        dismissComebackPlan,
        updateSettings,
        resetAllData,
        triggerConfetti,
      }}
    >
      {children}
    </SkillQuestContext.Provider>
  );
};

export const useSkillQuest = () => {
  const context = useContext(SkillQuestContext);
  if (!context) {
    throw new Error('useSkillQuest must be used within a SkillQuestProvider');
  }
  return context;
};
