import {
  User,
  LearningGoal,
  Milestone,
  Quest,
  Achievement,
  LearningResource,
  Cohort,
  LeaderboardUser,
  DailyActivity,
  Topic,
  QuizQuestion
} from '../types';

export const INITIAL_USER: User = {
  id: 'usr_alex_rivera',
  name: 'Alex Rivera',
  email: 'alex.rivera@example.com',
  avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=250&q=80',
  role: 'Aspiring Full-Stack Developer',
  currentXP: 380,
  currentLevel: 3, // Apprentice
  currentStreak: 4,
  longestStreak: 9,
  lastActiveDate: new Date().toISOString(),
  streakFrozen: false,
  learningPreferences: {
    dailyMinutes: 30,
    preferredTime: 'evening',
    notificationReminder: true,
  },
  settings: {
    soundEffects: true,
    demoMode: true,
    geminiApiKey: '',
    optInLeaderboard: true,
  },
};

export const INITIAL_GOAL: LearningGoal = {
  id: 'goal_webdev_01',
  userId: 'usr_alex_rivera',
  skill: 'Modern Web Development',
  currentLevel: 'Beginner',
  targetLevel: 'Intermediate',
  availableTime: '30 minutes per day',
  deadline: '3 months',
  targetDate: '2026-12-15',
  schedulePreference: 'Consistent daily evening sessions',
  motivation: 'I want to build my own SaaS web applications independently and transition into a junior software engineering role.',
  overallProgress: 44,
  isAiGenerated: true,
  createdAt: '2026-10-01T10:00:00Z',
  updatedAt: new Date().toISOString(),
};

export const INITIAL_MILESTONES: Milestone[] = [
  {
    id: 'ms_1',
    goalId: 'goal_webdev_01',
    sequence: 1,
    title: 'HTML5 Semantic Foundations & Accessibility',
    description: 'Master structure, semantic tags, forms, accessibility (a11y) standards, and SEO hygiene.',
    status: 'completed',
    criteria: [
      'Build a fully semantic multi-page article layout without div soups',
      'Validate form inputs with native HTML5 attributes and regex patterns',
      'Implement ARIA labels, semantic landmark regions, and keyboard tab indices'
    ],
    estimatedWeeks: 2,
    completedAt: '2026-10-12T18:00:00Z',
  },
  {
    id: 'ms_2',
    goalId: 'goal_webdev_01',
    sequence: 2,
    title: 'Modern CSS, Flexbox & Responsive Layouts',
    description: 'Grasp the CSS box model, mobile-first design, Flexbox alignment, CSS Grid, and responsive viewports.',
    status: 'in-progress',
    criteria: [
      'Master the box model (margin, border, padding, content-box vs border-box)',
      'Construct a 100% responsive navigation bar with a mobile hamburger overlay',
      'Deploy a responsive card grid using CSS Grid auto-fit and minmax'
    ],
    estimatedWeeks: 3,
  },
  {
    id: 'ms_3',
    goalId: 'goal_webdev_01',
    sequence: 3,
    title: 'JavaScript Essentials, DOM Manipulation & Events',
    description: 'Understand variables, functions, ES6 array methods, event listeners, and dynamic DOM manipulation.',
    status: 'in-progress',
    criteria: [
      'Write pure functions utilizing map, filter, and reduce on mock dataset arrays',
      'Attach event listeners and implement event delegation on dynamic list items',
      'Build an interactive task tracker that persists items into browser localStorage'
    ],
    estimatedWeeks: 3,
  },
  {
    id: 'ms_4',
    goalId: 'goal_webdev_01',
    sequence: 4,
    title: 'React Fundamentals, Components & State Hooks',
    description: 'Break UI into composable components, manage state with useState and useEffect, and handle props cleanly.',
    status: 'locked',
    criteria: [
      'Compose parent-child components with strict typed props in TypeScript',
      'Manage synchronous and asynchronous state changes without unnecessary re-renders',
      'Fetch external REST API data with proper loading and error states'
    ],
    estimatedWeeks: 3,
  },
  {
    id: 'ms_5',
    goalId: 'goal_webdev_01',
    sequence: 5,
    title: 'Fullstack Capstone Project & Deployment',
    description: 'Connect frontend to RESTful endpoints, handle authentication tokens, and deploy on modern cloud platforms.',
    status: 'locked',
    criteria: [
      'Build a full-featured CRUD application with live state and local persistence',
      'Deploy the production build to Vercel/Netlify with automated CI/CD checks',
      'Document the codebase with a comprehensive README and live demo links'
    ],
    estimatedWeeks: 2,
  },
];

export const INITIAL_QUESTS: Quest[] = [
  // Milestone 1 (Completed)
  {
    id: 'qst_1_1',
    milestoneId: 'ms_1',
    title: 'Audit & Replace Non-Semantic Tags',
    description: 'Take a plain HTML snippet and replace non-semantic <div> tags with semantic HTML5 elements (<header>, <main>, <nav>, <article>, <footer>).',
    durationMinutes: 15,
    difficulty: 'Beginner',
    xpReward: 20,
    status: 'completed',
    isToday: false,
    completedAt: '2026-10-05T19:30:00Z',
    reflection: 'Realized that using semantic tags drastically improves screen reader readability and clean styling hooks.',
    resourceTitle: 'MDN: HTML5 Semantic Elements',
    resourceUrl: 'https://developer.mozilla.org/en-US/docs/Glossary/Semantics#semantics_in_html',
    instructions: [
      'Inspect the sample page layout provided.',
      'Replace all top-level wrapper divs with appropriate semantic tags.',
      'Verify keyboard navigation flow using the Tab key.'
    ],
    submissionType: 'code',
    submissionRequirements: 'Paste your refactored semantic HTML code snippet showing semantic elements replacing legacy div wrappers.',
    rubric: [
      { id: 'r1', criterion: 'Semantic Tags Present', description: 'Uses <header>, <nav>, <main>, and <footer> appropriately.' },
      { id: 'r2', criterion: 'Valid Nesting', description: 'Proper HTML document structure without misplaced parent elements.' },
    ],
    submissions: [
      {
        id: 'sub_1_1',
        questId: 'qst_1_1',
        userId: 'usr_alex_rivera',
        attemptNumber: 1,
        submissionType: 'code',
        content: '<header><nav><ul><li>Home</li></ul></nav></header><main><article><h1>Audit</h1></article></main><footer>&copy; 2026</footer>',
        submittedAt: '2026-10-05T19:30:00Z',
        evaluation: {
          status: 'cleared',
          score: 100,
          criteriaMet: ['Semantic Tags Present', 'Valid Nesting'],
          criteriaNotMet: [],
          feedback: 'Clean refactor using semantic landmarks properly.',
          suggestions: ['Consider adding aria-label on <nav> when multiple navs exist.'],
          recommendedNextAction: 'Proceed to Form Accessibility quest.',
          evaluatedAt: '2026-10-05T19:30:00Z'
        }
      }
    ],
    bonusQuestions: [
      {
        id: 'bq_1_1',
        questId: 'qst_1_1',
        questionText: 'Which HTML5 element represents self-contained content that could be independently distributed or reused?',
        options: ['<section>', '<article>', '<aside>', '<figure>'],
        correctAnswer: 1,
        explanation: '<article> is explicitly designed for self-contained syndicatable content such as forum posts, news articles, or blog entries.',
        xpReward: 10,
        userAnswer: 1,
        isCorrect: true,
      }
    ],
    bonusCompleted: true,
    bonusXpEarned: 10
  },
  {
    id: 'qst_1_2',
    milestoneId: 'ms_1',
    title: 'Construct an Accessible Registration Form',
    description: 'Create an accessible form with associated <label for="...">, aria-describedby for errors, and correct input types (email, password, tel).',
    durationMinutes: 20,
    difficulty: 'Beginner',
    xpReward: 20,
    status: 'completed',
    isToday: false,
    completedAt: '2026-10-10T20:15:00Z',
    reflection: 'Learned why label for and input id must match for screen readers and touch targets.',
    resourceTitle: 'WebAIM: Creating Accessible Forms',
    resourceUrl: 'https://webaim.org/techniques/forms/',
    instructions: [
      'Create form elements with matching labels.',
      'Add required attributes and input constraints.',
      'Test tabbing through each input element.'
    ],
    submissionType: 'code',
    submissionRequirements: 'Paste your form HTML markup showing explicit labels connected to inputs via matching "for" and "id" attributes.',
    rubric: [
      { id: 'r1', criterion: 'Label Associations', description: 'Every input has a paired label with for/id pairing.' },
      { id: 'r2', criterion: 'Accessible Inputs', description: 'Uses proper input types (email, password) and required attributes.' },
    ],
    submissions: [],
    bonusQuestions: [
      {
        id: 'bq_1_2',
        questId: 'qst_1_2',
        questionText: 'Why should placeholder text NOT be used as a replacement for the <label> element?',
        options: [
          'Placeholders disappear once user starts typing, causing cognitive disorientation and failing screen readers.',
          'Placeholders increase CSS bundle sizes.',
          'Browsers prevent form submissions if a placeholder is present.',
          'Placeholders only work in mobile browsers.'
        ],
        correctAnswer: 0,
        explanation: 'Placeholders disappear when typing starts, offer low contrast by default, and are not reliably announced as labels by screen readers.',
        xpReward: 10,
        userAnswer: 0,
        isCorrect: true,
      }
    ],
    bonusCompleted: true,
    bonusXpEarned: 10
  },

  // Milestone 2 (Current Active)
  {
    id: 'qst_2_1',
    milestoneId: 'ms_2',
    title: 'Master Box-Sizing & Margin Collapse',
    description: 'Demystify box-sizing: border-box vs content-box, and experiment with margin collapse phenomena between adjacent blocks.',
    durationMinutes: 20,
    difficulty: 'Beginner',
    xpReward: 20,
    status: 'completed',
    isToday: false,
    completedAt: '2026-10-25T18:40:00Z',
    reflection: 'Always reset with box-sizing: border-box globally! Saves so many layout headaches.',
    resourceTitle: 'CSS-Tricks: Box-Sizing Explained',
    resourceUrl: 'https://css-tricks.com/box-sizing/',
    instructions: [
      'Set up two colored boxes with padding and borders.',
      'Observe total computed width with content-box vs border-box.',
      'Implement the universal box-sizing CSS reset.'
    ],
    submissionType: 'code',
    submissionRequirements: 'Submit the CSS code demonstrating universal border-box reset and a calculation explanation.',
    rubric: [
      { id: 'r1', criterion: 'Universal Reset', description: '*, *::before, *::after have box-sizing: border-box defined.' },
      { id: 'r2', criterion: 'Box Dimension Control', description: 'Demonstrates understanding of padding inclusion in total width.' }
    ],
    submissions: []
  },
  {
    id: 'qst_2_2',
    milestoneId: 'ms_2',
    title: 'Build a Responsive Navbar with Flexbox',
    description: 'Create a clean, mobile-first responsive navigation bar with space-between alignment, logo branding, and responsive toggle links.',
    durationMinutes: 25,
    difficulty: 'Intermediate',
    xpReward: 35,
    status: 'todo',
    isToday: true, // Featured Today's Quest!
    resourceTitle: 'Flexbox Froggy & MDN Flexbox Guide',
    resourceUrl: 'https://developer.mozilla.org/en-US/docs/Learn/CSS/CSS_layout/Flexbox',
    instructions: [
      'Create a <nav> container with display: flex and justify-content: space-between.',
      'Align the brand logo on the left and the nav items list on the right.',
      'Apply align-items: center for vertical centering.',
      'Add a CSS media query at 768px or mobile view to collapse links into a clean column or toggle menu.',
      'Test your navbar responsiveness by resizing your viewport or testing on a mobile device.'
    ],
    submissionType: 'code',
    submissionRequirements: 'Submit your HTML & CSS code (or upload a screenshot of your responsive navbar at both desktop and mobile widths) fulfilling all task requirements.',
    rubric: [
      { id: 'r1', criterion: 'Flexbox Implementation', description: 'Container correctly utilizes display: flex with space-between alignment and vertical centering.' },
      { id: 'r2', criterion: 'Responsive Adaptation', description: 'Layout gracefully adapts to viewports under 768px using media queries or mobile-first patterns.' },
      { id: 'r3', criterion: 'Visual Structure & Semantics', description: 'Uses <nav> element with properly structured link items without broken layout overflows.' }
    ],
    submissions: [],
    bonusQuestions: [
      {
        id: 'bq_2_2_1',
        questId: 'qst_2_2',
        questionText: 'What is the fundamental difference between justify-content and align-items in a Flex container?',
        options: [
          'justify-content aligns along the main axis; align-items aligns along the cross axis.',
          'justify-content only works on text; align-items works on block elements.',
          'align-items controls wrapping; justify-content controls spacing.',
          'There is no difference; they are aliases for browser compatibility.'
        ],
        correctAnswer: 0,
        explanation: 'In Flexbox, justify-content manages item distribution along the main axis (row by default), whereas align-items controls placement across the cross axis (vertical in row mode).',
        xpReward: 10
      },
      {
        id: 'bq_2_2_2',
        questId: 'qst_2_2',
        questionText: 'When would you use flex-wrap: wrap instead of leaving the default nowrap?',
        options: [
          'When child elements should wrap onto new lines rather than shrinking or overflowing their container.',
          'To force all elements into a single vertical column regardless of width.',
          'To animate element position changes.',
          'To center elements inside a fixed modal.'
        ],
        correctAnswer: 0,
        explanation: 'By default, flex-wrap is nowrap, which causes items to shrink or overflow. Setting wrap allows elements to break into multi-line rows gracefully as viewport shrinks.',
        xpReward: 10
      },
      {
        id: 'bq_2_2_3',
        questId: 'qst_2_2',
        questionText: 'Why is CSS Flexbox primarily classified as a one-dimensional layout system compared to CSS Grid?',
        options: [
          'Flexbox calculates layout along one axis at a time (row OR column), whereas CSS Grid calculates two axes (rows AND columns) simultaneously.',
          'Flexbox cannot handle more than 5 elements.',
          'Flexbox does not support media queries.',
          'CSS Grid was created earlier than Flexbox.'
        ],
        correctAnswer: 0,
        explanation: 'Flexbox deals with content distribution primarily in single rows or single columns at a time, making it 1-dimensional. CSS Grid handles coordinate 2-dimensional rows and columns together.',
        xpReward: 10
      }
    ],
    bonusCompleted: false,
    bonusXpEarned: 0
  },
  {
    id: 'qst_2_3',
    milestoneId: 'ms_2',
    title: 'Implement an Auto-Fit Responsive Card Grid',
    description: 'Use CSS Grid repeat(auto-fit, minmax(280px, 1fr)) to build an adaptive product/dashboard card grid without hardcoded media queries.',
    durationMinutes: 20,
    difficulty: 'Intermediate',
    xpReward: 35,
    status: 'todo',
    isToday: false,
    resourceTitle: 'MDN: Auto-sizing columns in CSS Grid',
    resourceUrl: 'https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_grid_layout/Auto-placement_in_grid_layout',
    instructions: [
      'Define a grid container with gap: 1.5rem.',
      'Use grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)).',
      'Test resizing the browser viewport to confirm columns wrap smoothly.'
    ],
    submissionType: 'code',
    submissionRequirements: 'Submit the CSS Grid rules and HTML card markup demonstrating auto-fit column placement.',
    rubric: [
      { id: 'r1', criterion: 'Grid Rule Accuracy', description: 'Employs repeat(auto-fit, minmax(...)) properly.' },
      { id: 'r2', criterion: 'Adaptive Behavior', description: 'Cards resize and wrap fluidly without requiring manual media query breakpoints.' }
    ],
    submissions: []
  },

  // Milestone 3 (Next Up)
  {
    id: 'qst_3_1',
    milestoneId: 'ms_3',
    title: 'ES6 Array Transformations: Map, Filter, Reduce',
    description: 'Transform an array of mock e-commerce items: filter by category, map to discounted prices, and calculate total cart value using reduce.',
    durationMinutes: 20,
    difficulty: 'Intermediate',
    xpReward: 25,
    status: 'todo',
    isToday: false,
    resourceTitle: 'JavaScript.info: Array Methods',
    resourceUrl: 'https://javascript.info/array-methods',
    instructions: [
      'Write a filter function to extract in-stock items.',
      'Map through the items to apply a 15% discount.',
      'Use reduce to compute the grand total in one clean statement.'
    ],
    submissionType: 'code',
    submissionRequirements: 'Submit your JavaScript code snippet executing all three transformations (filter, map, reduce) on a sample items array.',
    rubric: [
      { id: 'r1', criterion: 'Immutability & Pure Functions', description: 'Original array is not mutated; returns transformed copies.' },
      { id: 'r2', criterion: 'Reduce Accumulator Usage', description: 'Reduce accumulator is initialized and sums values correctly.' }
    ],
    submissions: []
  },
  {
    id: 'qst_3_2',
    milestoneId: 'ms_3',
    title: 'Dynamic DOM Manipulation & Event Delegation',
    description: 'Build an interactive list where clicking an item toggles its active state, utilizing a single delegated event listener on the parent element.',
    durationMinutes: 25,
    difficulty: 'Intermediate',
    xpReward: 35,
    status: 'todo',
    isToday: false,
    resourceTitle: 'MDN: Event Delegation in JavaScript',
    resourceUrl: 'https://developer.mozilla.org/en-US/docs/Learn/JavaScript/Building_blocks/Events#event_delegation',
    instructions: [
      'Create a parent <ul> and attach one click event listener.',
      'Use event.target.closest("li") to identify the clicked list item.',
      'Toggle a CSS class without attaching separate listeners to each item.'
    ],
    submissionType: 'code',
    submissionRequirements: 'Submit the JavaScript code with event delegation and closest() element targeting.',
    rubric: [
      { id: 'r1', criterion: 'Single Listener', description: 'Attaches listener only to parent container, not individual items.' },
      { id: 'r2', criterion: 'Safe Delegation', description: 'Checks event.target or closest() to guard against null targets.' }
    ],
    submissions: []
  },
];

export const INITIAL_ACHIEVEMENTS: Achievement[] = [
  {
    id: 'ach_first_quest',
    name: 'First Quest Complete',
    description: 'Completed your very first practical learning quest on SkillQuest.',
    category: 'quest',
    icon: '🎯',
    earned: true,
    earnedAt: '2026-10-05T19:30:00Z',
    xpReward: 20,
    criteria: 'Complete 1 Quest with Evaluation',
  },
  {
    id: 'ach_streak_3',
    name: '3-Day Fire',
    description: 'Maintained a consistent daily learning streak for 3 days.',
    category: 'streak',
    icon: '🔥',
    earned: true,
    earnedAt: '2026-10-08T18:00:00Z',
    xpReward: 30,
    criteria: 'Reach a 3-Day Streak',
  },
  {
    id: 'ach_streak_7',
    name: 'Weekly Ironclad',
    description: 'Locked in a continuous 7-day daily quest streak.',
    category: 'streak',
    icon: '⚡',
    earned: true,
    earnedAt: '2026-10-12T19:00:00Z',
    xpReward: 70,
    criteria: 'Reach a 7-Day Streak',
  },
  {
    id: 'ach_first_milestone',
    name: 'Milestone Conqueror',
    description: 'Completed every quest and requirement in your first roadmap milestone.',
    category: 'milestone',
    icon: '🏁',
    earned: true,
    earnedAt: '2026-10-12T18:00:00Z',
    xpReward: 100,
    criteria: 'Complete 1 Milestone',
  },
  {
    id: 'ach_consistency_14',
    name: 'Consistency Champion',
    description: 'Achieve 14 consecutive active learning days without missing a beat.',
    category: 'consistency',
    icon: '🏆',
    earned: false,
    xpReward: 150,
    criteria: 'Reach a 14-Day Streak (Currently 4/14)',
  },
  {
    id: 'ach_comeback_hero',
    name: 'Comeback Hero',
    description: 'Returned to learning after a break and completed a gentle comeback plan.',
    category: 'comeback',
    icon: '🌱',
    earned: true,
    earnedAt: '2026-10-22T17:15:00Z',
    xpReward: 50,
    criteria: 'Complete a Comeback Plan Quest',
  },
  {
    id: 'ach_bonus_master',
    name: 'Deep Thinker',
    description: 'Answered all bonus conceptual questions correctly on a daily quest.',
    category: 'quest',
    icon: '🧠',
    earned: true,
    earnedAt: '2026-10-10T20:20:00Z',
    xpReward: 40,
    criteria: 'Score 100% on a Quest Bonus Assessment',
  },
  {
    id: 'ach_xp_500',
    name: 'XP Practitioner',
    description: 'Accumulate over 500 total earned Experience Points (XP).',
    category: 'xp',
    icon: '💎',
    earned: false,
    xpReward: 100,
    criteria: 'Reach 500 XP (Currently 380/500)',
  },
  {
    id: 'ach_roadmap_completed',
    name: 'Skill Ascendant',
    description: 'Conquer all milestones in your personalized learning roadmap.',
    category: 'milestone',
    icon: '👑',
    earned: false,
    xpReward: 300,
    criteria: 'Complete 100% of Learning Roadmap',
  },
];

export const INITIAL_RESOURCES: LearningResource[] = [
  {
    id: 'res_1',
    title: 'MDN Web Docs: CSS Flexbox Guide & Interactive Playground',
    description: 'The definitive web standard documentation explaining flex direction, alignment, flex-grow, and practical layout patterns.',
    provider: 'Mozilla Developer Network (MDN)',
    url: 'https://developer.mozilla.org/en-US/docs/Learn/CSS/CSS_layout/Flexbox',
    resourceType: 'documentation',
    difficulty: 'Beginner',
    duration: '25 min read',
    skill: 'Modern Web Development',
    saved: true,
    completed: true,
    associatedMilestoneSequence: 2,
  },
  {
    id: 'res_2',
    title: 'A Complete Guide to CSS Flexbox',
    description: 'Deep dive visual reference into all parent (flex container) and child (flex items) properties with real-world examples.',
    provider: 'CSS-Tricks',
    url: 'https://css-tricks.com/snippets/css/a-guide-to-flexbox/',
    resourceType: 'article',
    difficulty: 'Intermediate',
    duration: '18 min read',
    skill: 'Modern Web Development',
    saved: true,
    completed: false,
    associatedMilestoneSequence: 2,
  },
  {
    id: 'res_3',
    title: 'JavaScript.info: The Modern JavaScript Tutorial',
    description: 'Comprehensive, clear walkthrough from variables and execution context to promises, async/await, and prototypes.',
    provider: 'JavaScript.info',
    url: 'https://javascript.info/',
    resourceType: 'course',
    difficulty: 'Intermediate',
    duration: 'Self-paced',
    skill: 'Modern Web Development',
    saved: true,
    completed: false,
    associatedMilestoneSequence: 3,
  },
  {
    id: 'res_4',
    title: 'CS50 Web Programming with Python and JavaScript',
    description: 'Harvard University lecture series diving into scalable web application architecture, database models, and client-server flows.',
    provider: 'Harvard University / edX',
    url: 'https://cs50.harvard.edu/web/',
    resourceType: 'course',
    difficulty: 'Advanced',
    duration: '12 weeks',
    skill: 'Modern Web Development',
    saved: false,
    completed: false,
    associatedMilestoneSequence: 4,
  },
  {
    id: 'res_5',
    title: 'React Official Documentation & Interactive Sandbox',
    description: 'Learn React using modern best practices, function components, hooks, and declarative state rendering.',
    provider: 'React Core Team (react.dev)',
    url: 'https://react.dev/learn',
    resourceType: 'documentation',
    difficulty: 'Intermediate',
    duration: 'Self-paced',
    skill: 'Modern Web Development',
    saved: false,
    completed: false,
    associatedMilestoneSequence: 4,
  },
  {
    id: 'res_6',
    title: 'Frontend Mentor: Real-World UI Challenges',
    description: 'Sharpen your HTML, CSS, and JavaScript skills by building realistic UI components with Figma design files.',
    provider: 'Frontend Mentor',
    url: 'https://www.frontendmentor.io/challenges',
    resourceType: 'project',
    difficulty: 'Intermediate',
    duration: '2-4 hours',
    skill: 'Modern Web Development',
    saved: true,
    completed: false,
    associatedMilestoneSequence: 2,
  },
  {
    id: 'res_7',
    title: 'freeCodeCamp: Responsive Web Design Certification',
    description: 'Interactive browser-based coding curriculum covering HTML, CSS, accessibility, and responsive typography.',
    provider: 'freeCodeCamp',
    url: 'https://www.freecodecamp.org/learn/2022/responsive-web-design/',
    resourceType: 'course',
    difficulty: 'Beginner',
    duration: '300 hours',
    skill: 'Modern Web Development',
    saved: false,
    completed: true,
    associatedMilestoneSequence: 1,
  },
];

export const INITIAL_COHORTS: Cohort[] = [
  {
    id: 'cohort_webdev',
    name: 'Web Development Pathfinders',
    skill: 'Modern Web Development',
    membersCount: 842,
    description: 'Daily accountability cohort for learners transitioning from HTML/CSS into modern JavaScript and full-stack engineering.',
    isJoined: true,
    weeklyChallenge: {
      title: 'Conquer 4 Layout & Responsive Quests',
      targetQuests: 4,
      currentCompleted: 3,
      rewardXP: 75,
      daysLeft: 3,
    },
    cohortProgress: 76,
    topMembers: [
      { name: 'Elena Rostova', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=120&q=80', xp: 580 },
      { name: 'Alex Rivera (You)', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=120&q=80', xp: 380 },
      { name: 'Marcus Chen', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=120&q=80', xp: 340 },
    ],
  },
  {
    id: 'cohort_python_data',
    name: 'Data Science & Python Analysts',
    skill: 'Data Analytics & Python',
    membersCount: 1120,
    description: 'Focused on Pandas dataframes, exploratory data analysis, statistical modeling, and actionable business insights.',
    isJoined: false,
    weeklyChallenge: {
      title: 'Analyze 2 Real-World Datasets with Pandas',
      targetQuests: 3,
      currentCompleted: 1,
      rewardXP: 75,
      daysLeft: 4,
    },
    cohortProgress: 64,
    topMembers: [
      { name: 'Priya Sharma', avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=120&q=80', xp: 720 },
      { name: 'David Kim', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=120&q=80', xp: 610 },
      { name: 'Sofia Alvarez', avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=120&q=80', xp: 490 },
    ],
  },
  {
    id: 'cohort_uiux',
    name: 'UI/UX Design & Product Thinking',
    skill: 'UI/UX Design',
    membersCount: 630,
    description: 'Mastering user research, wireframing, Figma design systems, visual hierarchy, and interaction design.',
    isJoined: false,
    weeklyChallenge: {
      title: 'Complete a Figma Component Library Redesign',
      targetQuests: 3,
      currentCompleted: 2,
      rewardXP: 75,
      daysLeft: 2,
    },
    cohortProgress: 82,
    topMembers: [
      { name: 'Chloe Dubois', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=120&q=80', xp: 690 },
      { name: 'Jordan Bell', avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=120&q=80', xp: 540 },
    ],
  },
  {
    id: 'cohort_dsa',
    name: 'Algorithms & Problem Solving',
    skill: 'Data Structures & Algorithms',
    membersCount: 950,
    description: 'Daily LeetCode and competitive programming muscle training with pattern recognition and time complexity analysis.',
    isJoined: false,
    weeklyChallenge: {
      title: 'Solve 5 Sliding Window & Two Pointers Problems',
      targetQuests: 5,
      currentCompleted: 3,
      rewardXP: 90,
      daysLeft: 5,
    },
    cohortProgress: 59,
    topMembers: [
      { name: 'Arjun Mehta', avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=120&q=80', xp: 880 },
      { name: 'Lucas Meyer', avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?auto=format&fit=crop&w=120&q=80', xp: 760 },
    ],
  },
];

export const INITIAL_LEADERBOARD: LeaderboardUser[] = [
  { id: 'lb_1', rank: 1, name: 'Elena Rostova', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=120&q=80', skill: 'Modern Web Development', xpEarned: 580, streak: 12, completedQuests: 19, isCurrentUser: false, badge: 'Achiever' },
  { id: 'lb_2', rank: 2, name: 'Priya Sharma', avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=120&q=80', skill: 'Data Analytics', xpEarned: 510, streak: 9, completedQuests: 16, isCurrentUser: false, badge: 'Builder' },
  { id: 'lb_3', rank: 3, name: 'Alex Rivera (You)', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=120&q=80', skill: 'Modern Web Development', xpEarned: 380, streak: 4, completedQuests: 12, isCurrentUser: true, badge: 'Apprentice' },
  { id: 'lb_4', rank: 4, name: 'Marcus Chen', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=120&q=80', skill: 'Modern Web Development', xpEarned: 340, streak: 6, completedQuests: 11, isCurrentUser: false, badge: 'Apprentice' },
  { id: 'lb_5', rank: 5, name: 'Chloe Dubois', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=120&q=80', skill: 'UI/UX Design', xpEarned: 310, streak: 3, completedQuests: 9, isCurrentUser: false, badge: 'Explorer' },
  { id: 'lb_6', rank: 6, name: 'David Kim', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=120&q=80', skill: 'Data Analytics', xpEarned: 290, streak: 5, completedQuests: 8, isCurrentUser: false, badge: 'Explorer' },
  { id: 'lb_7', rank: 7, name: 'Jordan Bell', avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=120&q=80', skill: 'UI/UX Design', xpEarned: 270, streak: 4, completedQuests: 8, isCurrentUser: false, badge: 'Explorer' },
  { id: 'lb_8', rank: 8, name: 'Lucas Meyer', avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?auto=format&fit=crop&w=120&q=80', skill: 'Algorithms', xpEarned: 240, streak: 2, completedQuests: 7, isCurrentUser: false, badge: 'Explorer' },
];

export const INITIAL_TOPICS: Topic[] = [
  // Core Topics
  {
    id: 'top_html5',
    skill: 'Modern Web Development',
    name: 'HTML5 Semantic Architecture & a11y',
    category: 'core',
    description: 'Structure clean pages using landmarks (<main>, <article>, <header>) and ensure full screen-reader compliance.',
    difficulty: 'Beginner',
    estimatedDuration: '1.5 weeks',
    recommendedResources: [
      { title: 'MDN Web Docs HTML Guide', url: 'https://developer.mozilla.org/en-US/docs/Learn/HTML', provider: 'MDN' }
    ],
    practicalExercise: 'Build an accessible multi-section documentation layout with proper ARIA attributes.',
    isAddedToRoadmap: true,
  },
  {
    id: 'top_css_layout',
    skill: 'Modern Web Development',
    name: 'Responsive CSS Grid & Flexbox Mastery',
    category: 'core',
    description: 'One-dimensional and two-dimensional layout models, box-sizing resets, and fluid typography.',
    difficulty: 'Intermediate',
    estimatedDuration: '2 weeks',
    recommendedResources: [
      { title: 'CSS-Tricks Flexbox & Grid Guides', url: 'https://css-tricks.com/', provider: 'CSS-Tricks' }
    ],
    practicalExercise: 'Construct an adaptive e-commerce storefront dashboard that automatically reflows across mobile, tablet, and ultra-wide viewports.',
    isAddedToRoadmap: true,
  },

  // Additional Topics
  {
    id: 'top_git_github',
    skill: 'Modern Web Development',
    name: 'Git Version Control & Collaborative Workflows',
    category: 'additional',
    description: 'Feature branching, meaningful commits, merge conflict resolution, and GitHub pull request hygiene.',
    difficulty: 'Beginner',
    estimatedDuration: '4 days',
    recommendedResources: [
      { title: 'Pro Git Book (Free)', url: 'https://git-scm.com/book/en/v2', provider: 'Git-SCM' }
    ],
    practicalExercise: 'Initialize a local git repo, create a feature branch, create a pull request with conventional commits, and resolve a simulated merge conflict.',
    isAddedToRoadmap: false,
    practicalQuestTemplate: {
      title: 'Git Branching & Merge Conflict Resolution Drill',
      description: 'Create a local repository with two divergent branches, induce a merge conflict in a shared markdown file, and resolve it cleanly.',
      durationMinutes: 20,
      difficulty: 'Beginner',
      xpReward: 30,
      submissionType: 'text',
      submissionRequirements: 'Paste your git log --graph --oneline output proving clean resolution.',
      rubric: [
        { id: 'r1', criterion: 'Branch History', description: 'Shows clean merge commit with both parent branches.' }
      ]
    }
  },
  {
    id: 'top_web_a11y',
    skill: 'Modern Web Development',
    name: 'Deep Web Accessibility (WCAG 2.2 AA Standards)',
    category: 'additional',
    description: 'Color contrast ratios, keyboard trap prevention, ARIA live regions, and screen-reader testing.',
    difficulty: 'Intermediate',
    estimatedDuration: '1 week',
    recommendedResources: [
      { title: 'W3C Web Accessibility Initiative', url: 'https://www.w3.org/WAI/', provider: 'W3C' }
    ],
    practicalExercise: 'Audit an existing complex web form using axe DevTools, rectify all AA contrast and label violations, and verify full keyboard tab navigation.',
    isAddedToRoadmap: false,
    practicalQuestTemplate: {
      title: 'Axe Accessibility Audit & WCAG Remediation',
      description: 'Run an automated axe accessibility audit on a sample page, fix color contrast and focus rings, and submit the 0-violation audit report.',
      durationMinutes: 25,
      difficulty: 'Intermediate',
      xpReward: 35,
      submissionType: 'document',
      submissionRequirements: 'Submit the before/after accessibility audit score and code diff.',
      rubric: [
        { id: 'r1', criterion: 'WCAG Compliance', description: 'Remediates contrast and missing labels.' }
      ]
    }
  },
  {
    id: 'top_browser_devtools',
    skill: 'Modern Web Development',
    name: 'Chrome DevTools: Performance Profiling & Memory Leaks',
    category: 'additional',
    description: 'Master the Elements, Network, Performance, and Memory panels to debug DOM layout shifts and heavy bundle bloat.',
    difficulty: 'Intermediate',
    estimatedDuration: '5 days',
    recommendedResources: [
      { title: 'Chrome DevTools Documentation', url: 'https://developer.chrome.com/docs/devtools', provider: 'Google' }
    ],
    practicalExercise: 'Record a performance trace of a heavy rendering loop and eliminate forced synchronous layouts.',
    isAddedToRoadmap: false,
  },

  // Advanced Topics
  {
    id: 'top_react_arch',
    skill: 'Modern Web Development',
    name: 'Advanced React: Custom Hooks & State Performance',
    category: 'advanced',
    description: 'Decouple business logic with custom hooks, avoid redundant re-renders with useMemo/useCallback, and master Context selectors.',
    difficulty: 'Advanced',
    estimatedDuration: '2.5 weeks',
    recommendedResources: [
      { title: 'React.dev Official Documentation', url: 'https://react.dev/', provider: 'React Team' }
    ],
    practicalExercise: 'Refactor a tangled component into 2 custom hooks (useLocalStorage & useDebounce) with full TypeScript type inference.',
    isAddedToRoadmap: false,
    practicalQuestTemplate: {
      title: 'Build a Generic useDebounce Hook with TypeScript',
      description: 'Implement a type-safe useDebounce<T> custom hook that delays input state updates and cancel cleanup timers.',
      durationMinutes: 25,
      difficulty: 'Advanced',
      xpReward: 45,
      submissionType: 'code',
      submissionRequirements: 'Submit the TypeScript code for the custom hook and an example component using it.',
      rubric: [
        { id: 'r1', criterion: 'Generic Type Safety', description: 'Hook accepts generic T parameter and returns debounced T.' },
        { id: 'r2', criterion: 'Effect Cleanup', description: 'Clears timeout on component unmount.' }
      ]
    }
  },
  {
    id: 'top_backend_rest',
    skill: 'Modern Web Development',
    name: 'RESTful API Architecture & Authentication (JWT / Sessions)',
    category: 'advanced',
    description: 'Build robust Node.js/Express endpoints, handle CORS, validate payload schemas, and sign secure HTTP-only cookie JWTs.',
    difficulty: 'Advanced',
    estimatedDuration: '2 weeks',
    recommendedResources: [
      { title: 'Express.js Documentation', url: 'https://expressjs.com/', provider: 'OpenJS Foundation' }
    ],
    practicalExercise: 'Implement a protected auth route with bcrypt password hashing and token expiration guards.',
    isAddedToRoadmap: false,
  },

  // Practical Projects
  {
    id: 'top_proj_portfolio',
    skill: 'Modern Web Development',
    name: 'Capstone 1: High-Performance Developer Portfolio',
    category: 'project',
    description: 'Build a production-ready developer portfolio with dark mode, project showcases, responsive contact form, and SEO meta tags.',
    difficulty: 'Intermediate',
    estimatedDuration: '1.5 weeks',
    recommendedResources: [
      { title: 'Web.dev Portfolio Best Practices', url: 'https://web.dev/', provider: 'Google' }
    ],
    practicalExercise: 'Deploy live to Vercel/Netlify with a 95+ Google Lighthouse score across Performance and Accessibility.',
    isAddedToRoadmap: false,
  },
  {
    id: 'top_proj_dashboard',
    skill: 'Modern Web Development',
    name: 'Capstone 2: Interactive SaaS Analytics Dashboard',
    category: 'project',
    description: 'Design and build a multi-view analytical dashboard with real-time SVG charting, date range filters, and local persistence.',
    difficulty: 'Advanced',
    estimatedDuration: '2 weeks',
    recommendedResources: [
      { title: 'Recharts Documentation', url: 'https://recharts.org/', provider: 'Recharts' }
    ],
    practicalExercise: 'Implement interactive KPI widgets and synchronized time-series charts with filter state preserved across page refreshes.',
    isAddedToRoadmap: false,
  }
];

export const INITIAL_QUIZ_QUESTIONS: QuizQuestion[] = [
  {
    id: 'quiz_1',
    skill: 'Modern Web Development',
    milestoneSequence: 1,
    questionText: 'Which HTML5 element represents self-contained content that could be independently distributed or reused outside the context of the page?',
    options: [
      '<section>',
      '<article>',
      '<aside>',
      '<figure>'
    ],
    correctAnswer: 1,
    explanation: '<article> is explicitly intended for independent, self-contained syndicated content (e.g., blog posts, newspaper stories, user comments).',
    difficulty: 'Beginner',
    xpReward: 15
  },
  {
    id: 'quiz_2',
    skill: 'Modern Web Development',
    milestoneSequence: 2,
    questionText: 'Given the following CSS snippet, what is the total computed width of the element in the browser viewport?',
    codeSnippet: `.card {\n  width: 300px;\n  padding: 20px;\n  border: 5px solid black;\n  box-sizing: content-box;\n}`,
    options: [
      '300px',
      '325px',
      '350px',
      '340px'
    ],
    correctAnswer: 2,
    explanation: 'With box-sizing: content-box (the default), padding and borders are added to the specified width: 300px + 20px(left) + 20px(right) + 5px(left border) + 5px(right border) = 350px.',
    difficulty: 'Intermediate',
    xpReward: 20
  },
  {
    id: 'quiz_3',
    skill: 'Modern Web Development',
    milestoneSequence: 2,
    questionText: 'In CSS Flexbox, what property should be applied to the flex container to distribute remaining space evenly BETWEEN items with none at the outer edges?',
    options: [
      'justify-content: space-around',
      'justify-content: space-between',
      'justify-content: space-evenly',
      'align-content: stretch'
    ],
    correctAnswer: 1,
    explanation: 'justify-content: space-between places the first child at the start edge, the last child at the end edge, and distributes remaining space equally between adjacent items.',
    difficulty: 'Beginner',
    xpReward: 15
  },
  {
    id: 'quiz_4',
    skill: 'Modern Web Development',
    milestoneSequence: 3,
    questionText: 'What will be logged to the console by the following JavaScript ES6 array expression?',
    codeSnippet: `const numbers = [1, 2, 3, 4, 5];\nconst result = numbers\n  .filter(n => n % 2 === 0)\n  .map(n => n * 3)\n  .reduce((acc, curr) => acc + curr, 0);\n\nconsole.log(result);`,
    options: [
      '18',
      '12',
      '30',
      '24'
    ],
    correctAnswer: 0,
    explanation: 'Filter keeps even numbers: [2, 4]. Map multiplies by 3: [6, 12]. Reduce sums them up: 6 + 12 = 18.',
    difficulty: 'Intermediate',
    xpReward: 20
  },
  {
    id: 'quiz_5',
    skill: 'Modern Web Development',
    milestoneSequence: 3,
    questionText: 'Why is event delegation considered a high-performance pattern for dynamic lists in vanilla JavaScript?',
    options: [
      'It allows attaching a single event listener to a common ancestor rather than dozens of separate listeners to each child element.',
      'It prevents events from ever bubbling up the DOM tree.',
      'It converts synchronous events into asynchronous web workers.',
      'It automatically sanitizes all user input against cross-site scripting.'
    ],
    correctAnswer: 0,
    explanation: 'Event delegation harnesses event bubbling: one listener on the parent container handles events for all current and future dynamic child elements, saving substantial memory.',
    difficulty: 'Intermediate',
    xpReward: 20
  }
];

export const generateInitialActivityHistory = (): DailyActivity[] => {
  const activities: DailyActivity[] = [];
  const today = new Date();
  
  for (let i = 27; i >= 0; i--) {
    const d = new Date(today);
    d.setDate(d.getDate() - i);
    const dateStr = d.toISOString().split('T')[0];
    
    let count = 0;
    let xp = 0;
    let level = 0;

    if (i === 0) {
      count = 0;
      xp = 0;
      level = 0;
    } else if (i <= 4) {
      count = Math.floor(Math.random() * 2) + 1;
      xp = count * 20 + (i === 1 ? 15 : 0);
      level = Math.min(3, count);
    } else if (i === 5 || i === 6) {
      count = 0;
      xp = 0;
      level = 0;
    } else if (i <= 15) {
      count = (i % 3 === 0) ? 0 : Math.floor(Math.random() * 2) + 1;
      xp = count * 20;
      level = count > 0 ? 2 : 0;
    } else {
      count = (i % 2 === 0) ? 1 : 0;
      xp = count * 20;
      level = count > 0 ? 1 : 0;
    }

    activities.push({
      date: dateStr,
      count,
      xp,
      level,
    });
  }
  return activities;
};
