import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useSkillQuest } from '../context/SkillQuestContext';
import { DailyQuizRecord } from '../types';
import {
  HelpCircle,
  CheckCircle2,
  XCircle,
  ArrowRight,
  ArrowLeft,
  Zap,
  Sparkles,
  Code2,
  ChevronRight,
  Check
} from 'lucide-react';

export const QuizPage: React.FC = () => {
  const { goal, ensureDailyQuiz, saveDailyQuizAnswers, submitDailyQuiz } = useSkillQuest();
  const [dailyQuiz, setDailyQuiz] = useState<DailyQuizRecord | null>(null);
  const [submitError, setSubmitError] = useState('');

  const [currentIdx, setCurrentIdx] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<string, number>>({});
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [earnedXP, setEarnedXP] = useState(0);

  useEffect(() => {
    let active = true;
    void ensureDailyQuiz().then(record => { if (!active) return; setDailyQuiz(record); setSelectedAnswers(record.answers); setIsSubmitted(Boolean(record.completedAt)); setEarnedXP(record.xpEarned || 0); });
    return () => { active = false; };
  }, [goal.id]);

  const quizQuestions = dailyQuiz?.questions || [];
  const currentQ = quizQuestions[currentIdx];
  const totalQuestions = quizQuestions.length;

  const handleSelectOption = (optIdx: number) => {
    if (isSubmitted) return;
    setSelectedAnswers(prev => { const next = { ...prev, [currentQ.id]: optIdx }; saveDailyQuizAnswers(next); return next; });
  };

  const calculateScore = () => {
    let score = 0;
    quizQuestions.forEach(q => {
      if (selectedAnswers[q.id] === q.correctAnswer) {
        score++;
      }
    });
    return score;
  };

  const handleSubmit = () => {
    try {
      const result = submitDailyQuiz(selectedAnswers);
      setEarnedXP(result.xpEarned); setIsSubmitted(true); setSubmitError('');
    } catch (error) { setSubmitError(error instanceof Error ? error.message : 'Answer all 10 questions.'); }
  };

  const score = calculateScore();
  const percentScore = totalQuestions ? Math.round((score / totalQuestions) * 100) : 0;

  if (!dailyQuiz || !currentQ) return <div className="p-8 text-slate-600">Preparing your 10-question daily review…</div>;

  return (
    <div className="max-w-3xl mx-auto space-y-6 animate-fadeIn text-left">
      {dailyQuiz.source === 'learning-plan-review' && <p className="rounded-xl bg-amber-50 border border-amber-200 p-3 text-sm text-amber-900">AI question generation is unavailable. This 10-question review uses your saved learning plan and covered lessons.</p>}
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 pb-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-bold uppercase tracking-wider text-brand-600 bg-brand-50 px-2.5 py-0.5 rounded-full border border-brand-200 flex items-center gap-1">
              <HelpCircle className="w-3.5 h-3.5" />
              Daily Skill Knowledge Check
            </span>
            <span className="text-xs text-slate-500 font-medium">{goal.skill}</span>
          </div>
          <h1 className="text-2xl font-black text-navy-950">
            Daily 10-Question Review
          </h1>
        </div>

        <Link
          to="/dashboard"
          className="text-xs font-bold text-slate-500 hover:text-slate-800 flex items-center gap-1 self-start sm:self-auto"
        >
          <span>Exit to Dashboard</span>
          <ChevronRight className="w-4 h-4" />
        </Link>
      </div>

      {!isSubmitted ? (
        <div className="space-y-6">
          {/* Question Navigator Bar */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white rounded-2xl p-4 border border-slate-200 shadow-sm">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs font-bold text-slate-700">Question Progress:</span>
              <div className="flex flex-wrap items-center gap-1.5">
                {quizQuestions.map((q, idx) => {
                  const isAnswered = selectedAnswers[q.id] !== undefined;
                  const isCurrent = idx === currentIdx;

                  return (
                    <button
                      key={q.id}
                      onClick={() => setCurrentIdx(idx)}
                      className={`w-7 h-7 rounded-lg text-xs font-bold transition-all ${
                        isCurrent
                          ? 'bg-brand-600 text-white ring-2 ring-brand-500/30'
                          : isAnswered
                          ? 'bg-brand-100 text-brand-800'
                          : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      {idx + 1}
                    </button>
                  );
                })}
              </div>
            </div>

            <span className="text-xs font-semibold text-slate-500">
              {Object.keys(selectedAnswers).length} of {totalQuestions} answered
            </span>
          </div>

          {submitError && <p role="alert" className="text-sm text-rose-600">{submitError}</p>}
          {/* Active Question Card */}
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6">
            <div className="flex items-center justify-between gap-2">
              <span className="text-xs font-extrabold text-brand-600 uppercase tracking-wider">
                Question {currentIdx + 1} of {totalQuestions}
              </span>
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                currentQ.difficulty === 'Beginner' ? 'bg-emerald-50 text-emerald-700' : 'bg-blue-50 text-blue-700'
              }`}>
                {currentQ.difficulty} • +{currentQ.xpReward} XP
              </span>
            </div>

            <h3 className="text-lg font-bold text-slate-900 leading-snug">
              {currentQ.questionText}
            </h3>

            {currentQ.codeSnippet && (
              <div className="p-4 rounded-2xl bg-slate-900 text-slate-100 font-mono text-xs overflow-x-auto shadow-inner border border-slate-800">
                <div className="flex items-center justify-between text-slate-400 text-[10px] border-b border-slate-800 pb-1 mb-2">
                  <span className="flex items-center gap-1">
                    <Code2 className="w-3 h-3 text-brand-400" />
                    Code Reference
                  </span>
                </div>
                <pre>{currentQ.codeSnippet}</pre>
              </div>
            )}

            {/* Answer Options */}
            <div className="space-y-3 pt-2">
              {currentQ.options.map((option, optIdx) => {
                const isSelected = selectedAnswers[currentQ.id] === optIdx;

                return (
                  <button type="button"
                    key={optIdx}
                    onClick={() => handleSelectOption(optIdx)}
                    aria-pressed={isSelected}
                    className={`w-full text-left p-4 rounded-2xl border transition-all cursor-pointer flex items-center justify-between ${
                      isSelected
                        ? 'bg-brand-50/80 border-brand-500 ring-2 ring-brand-500/20 shadow-sm'
                        : 'bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50/60'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <span className={`w-6 h-6 rounded-lg text-xs font-bold flex items-center justify-center border ${
                        isSelected
                          ? 'bg-brand-600 text-white border-brand-600'
                          : 'bg-slate-100 text-slate-600 border-slate-200'
                      }`}>
                        {String.fromCharCode(65 + optIdx)}
                      </span>
                      <span className="text-xs sm:text-sm font-medium text-slate-800">
                        {option}
                      </span>
                    </div>

                    <div className={`w-4 h-4 rounded-full border flex items-center justify-center ${
                      isSelected ? 'border-brand-600 bg-brand-600 text-white' : 'border-slate-300'
                    }`}>
                      {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Navigation Controls */}
            <div className="flex items-center justify-between pt-6 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setCurrentIdx(prev => Math.max(0, prev - 1))}
                disabled={currentIdx === 0}
                className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100 transition-colors disabled:opacity-30 disabled:pointer-events-none"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Previous</span>
              </button>

              {currentIdx < totalQuestions - 1 ? (
                <button
                  type="button"
                  onClick={() => setCurrentIdx(prev => Math.min(totalQuestions - 1, prev + 1))}
                  className="flex items-center gap-1.5 px-5 py-2.5 bg-brand-600 hover:bg-brand-700 text-white rounded-xl text-xs font-bold transition-all shadow-sm"
                >
                  <span>Next Question</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              ) : (
                <button
                  type="button"
                  onClick={handleSubmit}
                  disabled={Object.keys(selectedAnswers).length !== 10}
                  className="flex items-center gap-2 px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-all shadow-md shadow-emerald-500/20 disabled:opacity-50"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>Submit Quiz</span>
                </button>
              )}
            </div>
          </div>
        </div>
      ) : (
        /* RESULT VIEW */
        <div className="space-y-6 animate-scaleUp">
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm text-center space-y-4">
            <div className="w-16 h-16 rounded-3xl bg-amber-50 text-amber-500 border border-amber-200 flex items-center justify-center text-3xl mx-auto shadow-sm">
              {percentScore >= 80 ? '🏆' : percentScore >= 60 ? '✨' : '📚'}
            </div>

            <div>
              <h2 className="text-2xl font-black text-navy-950">
                {percentScore >= 80 ? 'Mastery Demonstrated!' : 'Quiz Complete!'}
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                You scored <strong className="text-slate-900">{score} out of {totalQuestions}</strong> ({percentScore}%)
              </p>
            </div>

            <div className="inline-flex items-center gap-1.5 px-4 py-1.5 bg-brand-50 border border-brand-200 rounded-full text-brand-700 text-xs font-bold">
              <Zap className="w-4 h-4 fill-brand-600" />
              <span>{earnedXP > 0 ? `+${earnedXP} daily quiz XP added` : 'Daily quiz recorded · no additional XP'}</span>
            </div>

            <div className="pt-4 flex justify-center gap-3">
              <Link
                to="/dashboard"
                className="flex items-center gap-1.5 px-5 py-2 bg-brand-600 hover:bg-brand-700 text-white rounded-xl text-xs font-bold shadow-sm transition-all"
              >
                <span>Continue to Dashboard</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </Link>
            </div>
          </div>

          {/* Detailed Question Review List */}
          <div className="space-y-4 text-left">
            <h3 className="text-base font-bold text-slate-900">
              Detailed Question Review & Explanations
            </h3>

            <div className="space-y-3">
              {quizQuestions.map((q, idx) => {
                const userAns = selectedAnswers[q.id];
                const isCorrect = userAns === q.correctAnswer;

                return (
                  <div
                    key={q.id}
                    className={`p-5 rounded-2xl border bg-white ${
                      isCorrect ? 'border-emerald-200' : 'border-rose-200'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-3 mb-2">
                      <span className="text-xs font-bold text-slate-900">
                        {idx + 1}. {q.questionText}
                      </span>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1 flex-shrink-0 ${
                        isCorrect ? 'bg-emerald-50 text-emerald-700' : 'bg-rose-50 text-rose-700'
                      }`}>
                        {isCorrect ? <CheckCircle2 className="w-3 h-3" /> : <XCircle className="w-3 h-3" />}
                        <span>{isCorrect ? 'Correct' : 'Incorrect'}</span>
                      </span>
                    </div>

                    <div className="space-y-1.5 text-xs pt-1">
                      <div className="text-slate-600">
                        <strong>Your Answer:</strong>{' '}
                        {userAns !== undefined ? q.options[userAns] : 'Not answered'}
                      </div>
                      {!isCorrect && (
                        <div className="text-emerald-700 font-semibold">
                          <strong>Correct Answer:</strong> {q.options[q.correctAnswer]}
                        </div>
                      )}
                      <div className="p-2.5 bg-slate-50 rounded-xl text-slate-600 mt-2 text-[11px] leading-relaxed">
                        <strong>Explanation:</strong> {q.explanation}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
