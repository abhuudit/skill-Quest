import React from 'react';
import { useSkillQuest } from '../context/SkillQuestContext';
import { ProgressBar } from '../components/common/ProgressBar';
import { getLevelInfo } from '../utils/levels';
import {
  BarChart3,
  TrendingUp,
  Target,
  CheckCircle2,
  Calendar,
  Flame,
  Zap,
  Award,
  Sparkles,
  Info
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  AreaChart,
  Area,
  CartesianGrid
} from 'recharts';

export const AnalyticsPage: React.FC = () => {
  const { user, goal, milestones, quests: allQuests, activityHistory } = useSkillQuest();
  const quests = allQuests.filter(q => !q.kind);

  const levelInfo = getLevelInfo(user.currentXP);
  const completedQuestsCount = quests.filter(q => q.status === 'completed').length;
  const completedMilestonesCount = milestones.filter(m => m.status === 'completed').length;

  // Active milestone
  const activeMilestone = milestones.find(m => m.status === 'in-progress') || milestones[0];
  const activeMilestoneQuests = activeMilestone ? quests.filter(q => q.milestoneId === activeMilestone.id) : [];
  const activeMilestoneCompleted = activeMilestoneQuests.filter(q => q.status === 'completed').length;
  const activeMilestonePercent = activeMilestoneQuests.length > 0
    ? Math.round((activeMilestoneCompleted / activeMilestoneQuests.length) * 100)
    : 0;

  // Prepare XP accumulation chart data
  let accumulatedXP = 0;
  const xpOverTimeData = activityHistory.slice(-14).map((item) => {
    accumulatedXP += item.xp;
    const d = new Date(item.date);
    return {
      date: `${d.getMonth() + 1}/${d.getDate()}`,
      dailyXP: item.xp,
      cumulativeXP: accumulatedXP + Math.max(0, user.currentXP - 280),
    };
  });

  // Prepare weekly consistency bar data (last 7 days)
  const last7DaysData = activityHistory.slice(-7).map((item) => {
    const d = new Date(item.date);
    return {
      day: d.toLocaleDateString('en-US', { weekday: 'short' }),
      quests: item.count,
      xp: item.xp,
    };
  });

  // Dynamic actionable insights based on user's actual data
  const insights = [
    {
      title: 'Active Consistency',
      message: `You've maintained a ${user.currentStreak}-day active streak! Your regular practice cadence directly correlates with retention.`,
      icon: Flame,
      color: 'text-amber-600 bg-amber-50 border-amber-200',
    },
    {
      title: activeMilestone ? activeMilestone.title : 'Milestone Velocity',
      message: activeMilestonePercent >= 50
        ? `You're ${activeMilestonePercent}% through your current milestone. Your next milestone is within immediate reach!`
        : `You have completed ${activeMilestoneCompleted} of ${activeMilestoneQuests.length} quests in your active milestone.`,
      icon: Target,
      color: 'text-brand-600 bg-brand-50 border-brand-200',
    },
    {
      title: 'Level Trajectory',
      message: `At ${user.currentXP} XP, you need only ${levelInfo.xpRemaining} XP to unlock Level ${levelInfo.level + 1} (${levelInfo.nextTier.title}).`,
      icon: Zap,
      color: 'text-purple-600 bg-purple-50 border-purple-200',
    },
  ];

  return (
    <div className="space-y-8 animate-fadeIn text-left">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-bold uppercase tracking-wider text-brand-600 bg-brand-50 px-3 py-1 rounded-full border border-brand-200 flex items-center gap-1.5">
              <BarChart3 className="w-3.5 h-3.5 text-brand-600" />
              Learning Velocity
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-navy-950">
            Progress Analytics & Insights
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 font-medium">
            Verified analytics powered by your actual daily quest submissions and deliberate practice sessions.
          </p>
        </div>

        {/* Overall Completion Card */}
        <div className="px-5 py-2.5 bg-white rounded-2xl border border-slate-200 shadow-sm flex items-center gap-3">
          <div className="text-right">
            <div className="text-[10px] text-slate-400 uppercase font-bold">Goal Completion</div>
            <div className="text-sm font-black text-brand-600">{goal.overallProgress}% Complete</div>
          </div>
          <div className="w-10 h-10 rounded-xl bg-brand-50 flex items-center justify-center font-bold text-xs text-brand-700 border border-brand-200">
            {completedMilestonesCount}/{milestones.length}
          </div>
        </div>
      </div>

      {/* KPI Cards Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="p-5 rounded-3xl bg-white border border-slate-200 shadow-sm">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Total XP Earned</span>
          <div className="text-2xl font-black text-brand-600 mt-1">{user.currentXP} XP</div>
          <span className="text-[11px] text-slate-500 font-medium">Rank: {levelInfo.title}</span>
        </div>

        <div className="p-5 rounded-3xl bg-white border border-slate-200 shadow-sm">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Quests Completed</span>
          <div className="text-2xl font-black text-slate-900 mt-1">{completedQuestsCount} / {quests.length}</div>
          <span className="text-[11px] text-emerald-600 font-semibold">{Math.round((completedQuestsCount / quests.length) * 100)}% of Curriculum</span>
        </div>

        <div className="p-5 rounded-3xl bg-white border border-slate-200 shadow-sm">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Milestones Finished</span>
          <div className="text-2xl font-black text-slate-900 mt-1">{completedMilestonesCount} / {milestones.length}</div>
          <span className="text-[11px] text-brand-600 font-semibold">Active: Milestone {activeMilestone?.sequence}</span>
        </div>

        <div className="p-5 rounded-3xl bg-white border border-slate-200 shadow-sm">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Current Streak</span>
          <div className="text-2xl font-black text-amber-600 mt-1">{user.currentStreak} Days</div>
          <span className="text-[11px] text-slate-500 font-medium">Longest: {user.longestStreak} Days</span>
        </div>
      </div>

      {/* Actionable Feedback & Insights */}
      <div className="space-y-3">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
          Personalized Learning Insights
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {insights.map((ins, idx) => {
            const Icon = ins.icon;
            return (
              <div key={idx} className="p-4 bg-white rounded-2xl border border-slate-200 shadow-sm flex items-start gap-3">
                <div className={`p-2.5 rounded-xl border flex-shrink-0 mt-0.5 ${ins.color}`}>
                  <Icon className="w-4 h-4" />
                </div>
                <div className="space-y-1">
                  <h4 className="text-xs font-bold text-slate-900">{ins.title}</h4>
                  <p className="text-xs text-slate-600 leading-relaxed">{ins.message}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Visual Analytics Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* XP Accumulation Over Time Area Chart */}
        <div className="lg:col-span-7 bg-white rounded-3xl p-6 sm:p-7 border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-base font-bold text-slate-900">XP Trajectory Over Time</h3>
              <p className="text-xs text-slate-500">Cumulative Experience Points earned in the last 14 days</p>
            </div>
            <span className="text-xs font-extrabold text-brand-600 bg-brand-50 px-3 py-1 rounded-full border border-brand-200">
              +{user.currentXP} XP
            </span>
          </div>

          <div className="h-64 w-full pt-4">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={xpOverTimeData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="xpGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#6366f1" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#6366f1" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="date" stroke="#94a3b8" fontSize={11} tickLine={false} />
                <YAxis stroke="#94a3b8" fontSize={11} tickLine={false} />
                <Tooltip
                  formatter={(val: any) => [`${val} XP`, 'Cumulative XP']}
                  contentStyle={{ backgroundColor: '#0f172a', borderRadius: '12px', border: 'none', color: '#fff', fontSize: '12px' }}
                />
                <Area type="monotone" dataKey="cumulativeXP" stroke="#6366f1" strokeWidth={2.5} fillOpacity={1} fill="url(#xpGradient)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Weekly Consistency Bar Chart */}
        <div className="lg:col-span-5 bg-white rounded-3xl p-6 sm:p-7 border border-slate-200 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-base font-bold text-slate-900">Weekly Consistency</h3>
                <p className="text-xs text-slate-500">Completed daily quests over the past 7 days</p>
              </div>
              <span className="text-xs font-bold text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-full">
                7 Days
              </span>
            </div>

            <div className="h-64 w-full pt-4">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={last7DaysData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <XAxis dataKey="day" stroke="#94a3b8" fontSize={11} tickLine={false} />
                  <YAxis allowDecimals={false} stroke="#94a3b8" fontSize={11} tickLine={false} />
                  <Tooltip
                    formatter={(val: any, name: string) => [val, name === 'quests' ? 'Completed Quests' : 'XP']}
                    contentStyle={{ backgroundColor: '#0f172a', borderRadius: '12px', border: 'none', color: '#fff', fontSize: '12px' }}
                  />
                  <Bar dataKey="quests" fill="#8b5cf6" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      </div>

      {/* Curriculum Milestone Velocity Progress */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-4">
        <h3 className="text-base font-bold text-slate-900">Milestone Progression Velocity</h3>
        <div className="space-y-4">
          {milestones.map((ms) => {
            const msQuests = quests.filter(q => q.milestoneId === ms.id);
            const done = msQuests.filter(q => q.status === 'completed').length;
            const pct = msQuests.length > 0 ? Math.round((done / msQuests.length) * 100) : ms.status === 'completed' ? 100 : 0;

            return (
              <div key={ms.id} className="space-y-1.5">
                <div className="flex justify-between items-center text-xs">
                  <span className="font-bold text-slate-800">
                    Milestone {ms.sequence}: {ms.title}
                  </span>
                  <span className={`font-semibold ${ms.status === 'completed' ? 'text-emerald-600' : 'text-slate-600'}`}>
                    {done} / {msQuests.length} Quests ({pct}%)
                  </span>
                </div>
                <ProgressBar
                  progress={pct}
                  colorClass={ms.status === 'completed' ? 'bg-emerald-500' : 'bg-brand-600'}
                  heightClass="h-2.5"
                />
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
