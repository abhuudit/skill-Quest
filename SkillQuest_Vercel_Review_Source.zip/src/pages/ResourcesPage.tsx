import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useSkillQuest } from '../context/SkillQuestContext';
import { ResourceType, QuestDifficulty } from '../types';
import {
  BookOpen,
  Bookmark,
  BookmarkCheck,
  CheckCircle2,
  ExternalLink,
  Search,
  Filter,
  Video,
  FileText,
  GraduationCap,
  Code2,
  Sparkles
} from 'lucide-react';

export const ResourcesPage: React.FC = () => {
  const { resources, toggleSaveResource, toggleCompleteResource } = useSkillQuest();

  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [difficultyFilter, setDifficultyFilter] = useState<string>('all');
  const [savedOnly, setSavedOnly] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const typeIcons: Record<ResourceType, React.ElementType> = {
    video: Video,
    article: FileText,
    course: GraduationCap,
    documentation: BookOpen,
    project: Code2,
  };

  const filteredResources = resources.filter((res) => {
    if (savedOnly && !res.saved) return false;
    if (typeFilter !== 'all' && res.resourceType !== typeFilter) return false;
    if (difficultyFilter !== 'all' && res.difficulty !== difficultyFilter) return false;

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        res.title.toLowerCase().includes(q) ||
        res.description.toLowerCase().includes(q) ||
        res.provider.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const savedCount = resources.filter(r => r.saved).length;
  const completedCount = resources.filter(r => r.completed).length;

  return (
    <div className="space-y-8 animate-fadeIn text-left">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-bold uppercase tracking-wider text-brand-600 bg-brand-50 px-3 py-1 rounded-full border border-brand-200 flex items-center gap-1.5">
              <BookOpen className="w-3.5 h-3.5 text-brand-600" />
              Resource Library
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-navy-950">
            Curated High-Signal Resources
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 font-medium">
            Hand-picked official documentation, interactive courses, and hands-on exercises linked directly to your roadmap.
          </p>
        </div>

        {/* Counter Pills */}
        <div className="flex items-center gap-3">
          <div className="px-4 py-2 bg-white rounded-2xl border border-slate-200 shadow-sm flex items-center gap-2 text-xs">
            <BookmarkCheck className="w-4 h-4 text-brand-600" />
            <span className="font-bold text-slate-800">{savedCount} Saved</span>
          </div>
          <div className="px-4 py-2 bg-white rounded-2xl border border-slate-200 shadow-sm flex items-center gap-2 text-xs">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span className="font-bold text-slate-800">{completedCount} Completed</span>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          {/* Resource Type Filter Tabs */}
          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-2xl overflow-x-auto min-w-0 max-w-full">
            {['all', 'documentation', 'course', 'article', 'project'].map((type) => (
              <button
                key={type}
                onClick={() => setTypeFilter(type)}
                className={`px-3.5 py-1.5 text-xs font-bold rounded-xl transition-all capitalize whitespace-nowrap ${
                  typeFilter === type
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {type}
              </button>
            ))}
          </div>

          {/* Search Box */}
          <div className="relative w-full sm:w-60 sm:flex-shrink-0 min-w-0">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-2.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search providers or topics..."
              className="w-full pl-9 pr-3.5 py-2 text-xs rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-brand-500 text-slate-800"
            />
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-100 text-xs">
          {/* Difficulty Filter */}
          <div className="flex flex-wrap items-center gap-2">
            <span className="font-bold text-slate-600 flex items-center gap-1">
              <Filter className="w-3.5 h-3.5" />
              Difficulty:
            </span>
            {['all', 'Beginner', 'Intermediate', 'Advanced'].map((diff) => (
              <button
                key={diff}
                onClick={() => setDifficultyFilter(diff)}
                className={`px-3 py-1 rounded-lg font-semibold transition-colors ${
                  difficultyFilter === diff
                    ? 'bg-brand-600 text-white'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {diff === 'all' ? 'All' : diff}
              </button>
            ))}
          </div>

          {/* Saved Only Filter Toggle */}
          <button
            onClick={() => setSavedOnly(!savedOnly)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-bold transition-colors ${
              savedOnly
                ? 'bg-brand-600 text-white'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <Bookmark className="w-3.5 h-3.5" />
            <span>Saved Only</span>
          </button>
        </div>
      </div>

      {/* Resources Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredResources.map((res) => {
          const IconComponent = typeIcons[res.resourceType] || BookOpen;

          return (
            <div
              key={res.id}
              className={`bg-white rounded-3xl p-5 border transition-all flex flex-col justify-between quest-card-hover ${
                res.completed
                  ? 'border-emerald-200 bg-emerald-50/20'
                  : 'border-slate-200 shadow-sm hover:border-brand-300'
              }`}
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div className="flex items-center gap-2">
                    <div className="w-9 h-9 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center border border-indigo-100">
                      <IconComponent className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-[10px] font-bold uppercase tracking-wider text-slate-600">{res.provider}</div>
                      <span className={`text-[10px] font-bold px-2 py-0.2 rounded-full ${
                        res.difficulty === 'Beginner' ? 'bg-emerald-50 text-emerald-700' :
                        res.difficulty === 'Intermediate' ? 'bg-blue-50 text-blue-700' :
                        'bg-purple-50 text-purple-700'
                      }`}>
                        {res.difficulty}
                      </span>
                    </div>
                  </div>

                  <button
                    onClick={() => toggleSaveResource(res.id)}
                    title={res.saved ? 'Remove from bookmarks' : 'Bookmark resource'}
                    className={`p-2 rounded-xl transition-colors ${
                      res.saved
                        ? 'bg-brand-50 text-brand-600 border border-brand-200'
                        : 'text-slate-400 hover:text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    <Bookmark className={`w-4 h-4 ${res.saved ? 'fill-brand-600' : ''}`} />
                  </button>
                </div>

                <h3 className="text-sm font-bold text-slate-900 mb-1.5 leading-snug">
                  {res.title}
                </h3>

                <p className="text-xs text-slate-600 line-clamp-3 mb-4 leading-relaxed">
                  {res.description}
                </p>
              </div>

              {/* Card Footer */}
              <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                <span className="text-slate-600 font-medium">{res.duration}</span>

                <div className="flex items-center gap-2">
                  <Link to={`/notes?resourceId=${encodeURIComponent(res.id)}`} className="text-brand-700 font-bold">Take Notes</Link>
                  <button
                    onClick={() => toggleCompleteResource(res.id)}
                    title={res.completed ? 'Mark uncompleted' : 'Mark completed'}
                    className={`p-1.5 rounded-lg transition-colors ${
                      res.completed ? 'text-emerald-600 bg-emerald-50' : 'text-slate-400 hover:text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    <CheckCircle2 className={`w-4 h-4 ${res.completed ? 'fill-emerald-100' : ''}`} />
                  </button>

                  <a
                    href={res.url}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-brand-50 hover:bg-brand-100 text-brand-700 rounded-xl font-bold transition-colors border border-brand-200"
                  >
                    <span>Visit Resource</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {filteredResources.length === 0 && (
        <div className="text-center py-16 bg-white rounded-3xl border border-slate-200 p-8 space-y-2">
          <BookOpen className="w-8 h-8 text-slate-300 mx-auto" />
          <h3 className="text-sm font-bold text-slate-800">No resources match your filters</h3>
          <p className="text-xs text-slate-500">Try resetting the difficulty or type filters.</p>
        </div>
      )}
    </div>
  );
};
