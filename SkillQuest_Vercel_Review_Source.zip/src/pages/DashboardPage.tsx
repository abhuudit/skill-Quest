import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useSkillQuest } from '../context/SkillQuestContext';
import { getLevelInfo } from '../utils/levels';
import { ProgressBar } from '../components/common/ProgressBar';
import { QuestModal } from '../components/common/QuestModal';
import { Quest } from '../types';
import { localDate, midwayUnlocked } from '../utils/dailyLearning';
import { GoalSwitcher } from '../components/common/GoalSwitcher';
import {
  Flame,
  Zap,
  Target,
  Play,
  HelpCircle,
  Clock,
  Sparkles,
  ArrowRight,
  Compass,
  CheckCircle2
} from 'lucide-react';

export const DashboardPage: React.FC = () => {
  const { user, goal, milestones, quests, comebackPlan, dailyQuizzes, dailyCredits } = useSkillQuest();
  const [selectedQuest, setSelectedQuest] = useState<Quest | null>(null);

  const levelInfo = getLevelInfo(user.currentXP);

  // Today's featured quest: look for today's quest that is not yet completed, or the first todo quest
  const coreQuests = quests.filter(q => !q.kind);
  const todayQuest = coreQuests.find(q => q.isToday && q.status !== 'completed') ||
    coreQuests.find(q => q.status === 'todo') ||
    coreQuests[0];
  const today = localDate(user.settings.timeZone);
  const assignment = quests.find(q => q.kind === 'assignment' && q.goalId === goal.id && q.scheduledDate === today);
  const dailyQuiz = dailyQuizzes.find(q => q.userId === user.id && q.goalId === goal.id && q.localDate === today);
  const quizAnswers = dailyQuiz ? Object.keys(dailyQuiz.answers).length : 0;
  const dailyGoalComplete = dailyCredits.includes(`${goal.id}:${today}`);
  const project = quests.find(q => q.kind === 'midway' && q.goalId === goal.id);
  const projectReady = project && midwayUnlocked(project, milestones) && project.status !== 'completed';

  const currentMilestone = milestones.find(m => m.id === todayQuest?.milestoneId) ||
    milestones.find(m => m.status === 'in-progress') ||
    milestones[0];

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-fadeIn text-left">
      <GoalSwitcher />
      {/* Supportive Comeback Banner (if active) */}
      {comebackPlan && comebackPlan.active && (
        <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 shadow-sm flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-amber-500 text-white font-bold text-xs">
              🌱
            </div>
            <p className="text-xs text-amber-900 leading-relaxed">
              <strong>Welcome back!</strong> {comebackPlan.message}
            </p>
          </div>
          <Link
            to="/streaks"
            className="flex-shrink-0 px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold transition-colors"
          >
            Comeback Plan
          </Link>
        </div>
      )}

      {/* 1. Simple Welcome & Learner State Strip */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white rounded-3xl p-6 sm:p-7 border border-slate-200 shadow-sm">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <h1 className="text-2xl font-black text-navy-950">
              Welcome back, {user.name}!
            </h1>
            <span className="text-2xl">{levelInfo.badge}</span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 font-medium">
            What should you do next? Complete today's practical quest or test your retention with a quiz.
          </p>
        </div>

        {/* Current XP, Level, and Streak */}
        <div className="flex items-center gap-3 flex-shrink-0">
          <div className="px-3.5 py-1.5 bg-brand-50 border border-brand-200 rounded-2xl flex items-center gap-2">
            <Zap className="w-4 h-4 text-brand-600 fill-brand-600" />
            <div className="text-left">
              <div className="text-[10px] text-slate-500 font-bold uppercase">Rank</div>
              <div className="text-xs font-extrabold text-brand-700">
                Lv.{levelInfo.level} ({user.currentXP} XP)
              </div>
            </div>
          </div>

          <div className="px-3.5 py-1.5 bg-amber-50 border border-amber-200 rounded-2xl flex items-center gap-2">
            <Flame className="w-4 h-4 text-amber-500 fill-amber-500" />
            <div className="text-left">
              <div className="text-[10px] text-slate-500 font-bold uppercase">Streak</div>
              <div className="text-xs font-extrabold text-amber-700">
                {user.currentStreak} Days Active
              </div>
            </div>
          </div>
        </div>
      </div>

      <section className="bg-white rounded-3xl p-5 border border-slate-200 shadow-sm text-sm space-y-3" aria-label="Daily learning checklist">
        <div className="flex items-center justify-between"><h2 className="font-bold text-slate-900">Today's learning checklist</h2><span className="text-xs text-slate-500">{today}</span></div>
        <div className="flex flex-col sm:flex-row sm:items-center gap-3 sm:gap-6 text-slate-700">
          <Link to="/homework" className="hover:text-brand-600">{assignment ? assignment.status === 'completed' ? '☑' : '☐' : '—'} {assignment ? 'Daily assignment completed' : 'No assignment scheduled today'}</Link>
          <Link to="/quiz" className="hover:text-brand-600">{dailyQuiz?.completedAt ? '☑' : '☐'} Daily quiz: {dailyQuiz?.completedAt ? '10' : quizAnswers}/10 answered</Link>
        </div>
        <p className={`text-xs font-semibold ${dailyGoalComplete ? 'text-emerald-700' : 'text-amber-700'}`}>{dailyGoalComplete ? 'Daily goal completed! Your streak is safe.' : `Streak pending: ${assignment && assignment.status !== 'completed' ? 'clear your assignment and ' : ''}submit all 10 quiz answers.`}</p>
        <div className="flex flex-wrap gap-4 text-xs font-bold"><Link to="/homework" className="text-brand-600">Daily Homework</Link><Link to="/quiz" className="text-brand-600">Start Daily Quiz</Link><Link to="/notes" className="text-brand-600">Take Notes</Link><Link to="/projects" className="text-brand-600">My Projects</Link>{projectReady && <Link to="/projects" className="text-amber-700">Midway Project is ready</Link>}</div>
      </section>

      {/* 2. Current Learning Goal & Progress Indicator */}
      <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-extrabold uppercase tracking-wider text-brand-600 bg-brand-50 px-2.5 py-0.5 rounded-full border border-brand-200">
              Active Skill Goal
            </span>
            <span className="text-xs text-slate-500 font-medium">
              Target: {goal.currentLevel} → {goal.targetLevel}
            </span>
          </div>
          <span className="text-xs font-extrabold text-brand-600">
            {goal.overallProgress}% Complete
          </span>
        </div>

        <div>
          <h2 className="text-xl font-black text-slate-900 mb-1">
            {goal.skill}
          </h2>
          <div className="text-xs text-slate-500 font-medium">
            Current Stage: <strong className="text-slate-800">{currentMilestone?.title || 'Active Milestone'}</strong> ({goal.availableTime})
          </div>
        </div>

        <ProgressBar progress={goal.overallProgress} colorClass="bg-brand-600" heightClass="h-2.5" />
      </div>

      {/* 3. Primary Next Action: Start Your Quest (Hero Spotlight) */}
      <div className="bg-gradient-to-br from-navy-900 via-indigo-950 to-slate-900 rounded-3xl p-6 sm:p-8 text-white border border-brand-800/60 shadow-xl relative overflow-hidden space-y-6">
        <div className="flex items-center justify-between">
          <span className="px-3 py-1 rounded-full text-xs font-extrabold bg-brand-500/20 text-brand-300 border border-brand-400/30 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-brand-400" />
            TODAY'S PRACTICAL QUEST
          </span>
          <span className="flex items-center gap-1 text-xs font-extrabold text-amber-300 bg-amber-500/10 px-3 py-1 rounded-full border border-amber-500/20">
            <Zap className="w-3.5 h-3.5 fill-amber-300" />
            +{todayQuest ? todayQuest.xpReward : 20} XP
          </span>
        </div>

        {todayQuest ? (
          <div className="space-y-3">
            <h3 className="text-xl sm:text-2xl font-black text-white leading-snug">
              {todayQuest.title}
            </h3>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed max-w-2xl">
              {todayQuest.description}
            </p>

            <div className="flex flex-wrap items-center gap-3 pt-1 text-xs">
              <span className="flex items-center gap-1 text-slate-300">
                <Clock className="w-3.5 h-3.5 text-brand-400" />
                {todayQuest.durationMinutes} mins
              </span>
              <span className="text-slate-500">•</span>
              <span className="px-2 py-0.5 rounded bg-white/10 text-slate-200 text-[11px] font-semibold">
                {todayQuest.difficulty}
              </span>
              <span className="text-slate-500">•</span>
              <span className="text-brand-300 text-[11px] font-medium">
                Submission: {todayQuest.submissionType || 'Code / Evidence'}
              </span>
            </div>
          </div>
        ) : (
          <div className="py-4 text-sm text-slate-300">
            🎉 All quests for today are cleared! Great work maintaining discipline.
          </div>
        )}

        {/* 4. Action Buttons: Primary "Start Your Quest" & Secondary "Start Quiz" */}
        <div className="pt-4 border-t border-white/10 flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          {todayQuest && (
            <button
              onClick={() => setSelectedQuest(todayQuest)}
              className="flex-1 flex items-center justify-center gap-2 py-3.5 px-6 rounded-2xl bg-brand-500 hover:bg-brand-400 text-white font-extrabold text-sm shadow-lg shadow-brand-500/30 transition-all hover:scale-[1.02] active:scale-[0.98]"
            >
              <Play className="w-4 h-4 fill-white" />
              <span>{todayQuest.status === 'completed' ? 'Review Practical Submission' : 'Start Your Quest'}</span>
            </button>
          )}

          <Link
            to="/quiz"
            className="flex items-center justify-center gap-2 py-3.5 px-6 rounded-2xl bg-white/10 hover:bg-white/20 text-white font-bold text-sm border border-white/20 transition-all"
          >
            <HelpCircle className="w-4 h-4 text-brand-300" />
            <span>Start Quiz</span>
          </Link>
        </div>
      </div>

      {/* 5. Clean Bottom Nav Shortcuts */}
      <div className="flex items-center justify-between text-xs text-slate-500 pt-2 px-2">
        <Link
          to="/roadmap"
          className="flex items-center gap-1 font-bold text-brand-600 hover:text-brand-700 transition-colors"
        >
          <Compass className="w-4 h-4" />
          <span>View Roadmap</span>
          <ArrowRight className="w-3 h-3" />
        </Link>

        <Link
          to="/quests"
          className="text-slate-500 hover:text-slate-800 font-semibold"
        >
          Browse All Quests ({coreQuests.length})
        </Link>
      </div>

      {/* Quest Practical Modal */}
      <QuestModal
        quest={selectedQuest}
        isOpen={Boolean(selectedQuest)}
        onClose={() => setSelectedQuest(null)}
      />
    </div>
  );
};
