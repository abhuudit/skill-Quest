import React, { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useSkillQuest } from '../context/SkillQuestContext';
import { PdfNotesPanel } from '../components/common/PdfNotesPanel';
import { PUBLIC_REVIEW_MODE } from '../utils/reviewMode';

export const NotesPage: React.FC = () => {
  const { user, goal, goals, quests, milestones, resources, notes, saveNote, reviewNote, decideNoteIssue } = useSkillQuest();
  const [params] = useSearchParams();
  const quest = quests.find(q => q.id === params.get('questId'));
  const resource = resources.find(r => r.id === params.get('resourceId'));
  const draftKey = `skillquest_note_draft_${user.id}_${goal.id}`;
  const readDraft = () => { try { return JSON.parse(localStorage.getItem(draftKey) || (goal.id === goals[0]?.id ? localStorage.getItem(`skillquest_note_draft_${user.id}`) : null) || '{}'); } catch { return {}; } };
  const stored = readDraft();
  const [activeId, setActiveId] = useState<string | undefined>(stored.id);
  const [tab, setTab] = useState<'text' | 'pdf'>('text');
  const [title, setTitle] = useState<string>(quest ? `Notes: ${quest.title}` : resource ? `Notes: ${resource.title}` : stored.title || '');
  const [topic, setTopic] = useState<string>(quest ? milestones.find(m => m.id === quest.milestoneId)?.title || quest.title : resource?.title || stored.topic || '');
  const [content, setContent] = useState<string>(stored.content || '');
  const [contextText, setContextText] = useState<string>(quest ? `${quest.description}\n${quest.instructions.join('\n')}\n${quest.rubric.map(r => r.description).join('\n')}` : resource ? `${resource.title}: ${resource.description}` : stored.context || '');
  const [working, setWorking] = useState(false);
  const [message, setMessage] = useState('');
  const [filter, setFilter] = useState('');
  const active = notes.find(n => n.id === activeId && n.userId === user.id && n.goalId === goal.id);
  useEffect(() => { localStorage.setItem(draftKey, JSON.stringify({ id: activeId, title, topic, content, context: contextText })); }, [draftKey, activeId, title, topic, content, contextText]);

  const save = () => {
    const note = saveNote({ id: activeId, title, topic, content, context: contextText, questId: quest?.id || active?.questId, resourceId: resource?.id || active?.resourceId });
    setActiveId(note.id); setMessage('Draft saved.'); return note;
  };
  const review = async () => {
    if (!content.trim()) { setMessage('Write a note before requesting review.'); return; }
    const note = save(); setWorking(true); setMessage('Reviewing your notes…');
    const result = await reviewNote(note.id, note);
    setWorking(false); setMessage(result ? 'Your notes have been reviewed. Here are a few points worth checking before you continue.' : 'AI review is unavailable. Your draft is saved; no feedback was invented.');
  };
  const choose = (id: string) => {
    const note = notes.find(n => n.id === id && n.userId === user.id && n.goalId === goal.id); if (!note) return;
    setActiveId(note.id); setTitle(note.title); setTopic(note.topic); setContent(note.content); setContextText(note.context); setTab(note.pdfVersions?.length && !note.content ? 'pdf' : 'text'); setMessage('');
  };
  const decide = (index: number, decision: 'accepted' | 'rejected') => {
    if (!active) return;
    const issue = active.review?.issues[index];
    if (decision === 'accepted' && issue?.passage && content.includes(issue.passage)) setContent(content.replace(issue.passage, issue.suggestedCorrection));
    decideNoteIssue(active.id, index, decision);
  };

  return <div className="max-w-6xl w-full min-w-0 mx-auto space-y-6 animate-fadeIn text-left">
    <div><p className="text-xs font-bold uppercase text-brand-600">Learning library</p><h1 className="text-2xl sm:text-3xl font-black text-navy-950">My Notes</h1><p className="text-sm text-slate-600">Capture your understanding. AI review offers suggestions without grades or XP penalties.</p></div>
    <div className="grid lg:grid-cols-[minmax(0,1fr)_17rem] gap-5 min-w-0">
      <div className="bg-white border border-slate-200 rounded-3xl p-4 sm:p-5 space-y-4 min-w-0">
        <div className="grid sm:grid-cols-2 gap-3 min-w-0"><label className="text-xs font-bold text-slate-700 min-w-0">Note title<input value={title} onChange={e => setTitle(e.target.value)} className="mt-1 w-full p-2 border border-slate-300 rounded-xl" /></label><label className="text-xs font-bold text-slate-700 min-w-0">Topic<input value={topic} onChange={e => setTopic(e.target.value)} className="mt-1 w-full p-2 border border-slate-300 rounded-xl" /></label></div>
        <p className="text-xs text-slate-500 break-words">Skill: {goal.skill}{quest ? ` · Quest: ${quest.title}` : resource ? ` · Resource: ${resource.title}` : active?.questId ? ` · Quest: ${quests.find(q => q.id === active.questId)?.title || active.questId}` : ''}</p>
        <div className="flex flex-wrap gap-2 border-b border-slate-200 pb-3" role="tablist" aria-label="Note type"><button role="tab" aria-selected={tab === 'text'} onClick={() => setTab('text')} className={`px-3 py-2 rounded-xl text-sm font-bold ${tab === 'text' ? 'bg-brand-600 text-white' : 'bg-slate-100 text-slate-700'}`}>Write Notes</button><button role="tab" aria-selected={tab === 'pdf'} onClick={() => setTab('pdf')} className={`px-3 py-2 rounded-xl text-sm font-bold ${tab === 'pdf' ? 'bg-brand-600 text-white' : 'bg-slate-100 text-slate-700'}`}>Upload Handwritten Notes (PDF)</button></div>
        {tab === 'pdf' ? <PdfNotesPanel active={active} ensureNote={save} userId={user.id} skill={goal.skill} context={contextText} /> : <div className="space-y-4">
          <textarea aria-label="Learning notes" value={content} onChange={e => setContent(e.target.value)} rows={12} placeholder="Write what you learned, your examples, and any questions you still have…" className="w-full p-3 border border-slate-300 rounded-xl text-sm" />
          <div className="flex flex-wrap gap-2"><button onClick={save} className="px-4 py-2 border border-brand-300 text-brand-700 rounded-xl text-sm font-bold">Save Draft</button><button onClick={review} disabled={PUBLIC_REVIEW_MODE || working || !content.trim()} className="px-4 py-2 bg-brand-600 text-white rounded-xl text-sm font-bold disabled:opacity-50">{working ? 'Reviewing…' : 'Submit Notes for AI Review'}</button></div>
          {message && <p role="status" className="text-sm text-slate-600">{message}</p>}{active?.reviewError && <p role="alert" className="text-sm text-rose-600">{active.reviewError}</p>}
          {active?.review && <div className="border-t border-slate-200 pt-4 space-y-3"><h2 className="font-bold text-slate-900">AI review · {new Date(active.review.reviewedAt).toLocaleString()}</h2><p className="text-sm text-slate-600">{active.review.summary}</p>{active.review.issues.map((issue,i) => <div key={i} className="p-3 rounded-xl border border-slate-200 bg-slate-50 text-sm"><span className="text-xs font-bold uppercase text-brand-600">{issue.category}</span><p className="font-semibold text-slate-800">“{issue.passage}”</p><p className="text-slate-600">{issue.explanation}</p>{issue.suggestedCorrection && <p className="text-slate-700">Suggestion: {issue.suggestedCorrection}</p>}<p className="text-xs text-slate-500">{issue.whyItMatters}</p>{issue.decision ? <span className="text-xs text-slate-500">{issue.decision}</span> : <div className="flex gap-2 mt-2"><button onClick={() => decide(i,'accepted')} className="text-xs font-bold text-emerald-700">Accept suggestion</button><button onClick={() => decide(i,'rejected')} className="text-xs font-bold text-slate-600">Keep my wording</button></div>}</div>)}</div>}
        </div>}
      </div>
      <aside className="bg-white border border-slate-200 rounded-3xl p-4 space-y-3 min-w-0 self-start"><div className="flex items-center justify-between gap-2"><h2 className="font-bold text-slate-900">Saved notes</h2><button onClick={() => { setActiveId(undefined); setTitle(''); setTopic(''); setContent(''); setContextText(''); setTab('text'); }} className="text-xs text-brand-600 font-bold">New note</button></div><input aria-label="Filter notes" value={filter} onChange={e => setFilter(e.target.value)} placeholder="Filter by skill, topic, quest, date…" className="w-full p-2 border border-slate-300 rounded-xl text-xs" />{notes.filter(n => n.userId === user.id && n.goalId === goal.id && `${n.skill} ${n.topic} ${n.title} ${n.questId || ''} ${n.updatedAt}`.toLowerCase().includes(filter.toLowerCase())).map(note => <button key={note.id} onClick={() => choose(note.id)} className="w-full text-left p-3 border border-slate-200 rounded-xl hover:bg-slate-50 min-w-0"><span className="block text-sm font-bold text-slate-900 break-words">{note.title}</span><span className="text-xs text-slate-500 break-words">{note.topic} · {new Date(note.updatedAt).toLocaleDateString()}{note.pdfVersions?.length ? ` · ${note.pdfVersions.length} PDF version${note.pdfVersions.length === 1 ? '' : 's'}` : ''}</span></button>)}</aside>
    </div>
  </div>;
};
