import React, { useState } from 'react';
import { useSkillQuest } from '../context/SkillQuestContext';
import { ProgressBar } from '../components/common/ProgressBar';
import { CohortChat } from '../components/common/CohortChat';
import { PUBLIC_REVIEW_MODE } from '../utils/reviewMode';
import {
  Users,
  Trophy,
  Flame,
  Zap,
  Target,
  ShieldCheck,
  CheckCircle2,
  Calendar,
  Lock,
  Eye,
  EyeOff,
  Sparkles,
  ArrowRight
} from 'lucide-react';

export const CohortsPage: React.FC = () => {
  const { user, cohorts, leaderboard, joinCohort, leaveCohort, setOptInLeaderboard } = useSkillQuest();

  const [period, setPeriod] = useState<'weekly' | 'monthly'>('weekly');
  const [activeTab, setActiveTab] = useState<'cohorts' | 'leaderboard'>('cohorts');
  const [chatCohortId, setChatCohortId] = useState<string | null>(null);

  const isOptedIn = user.settings.optInLeaderboard;

  return (
    <div className="space-y-8 animate-fadeIn text-left">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-bold uppercase tracking-wider text-blue-600 bg-blue-50 px-3 py-1 rounded-full border border-blue-200 flex items-center gap-1.5">
              <Users className="w-3.5 h-3.5 text-blue-600" />
              Community & Accountability
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-navy-950">
            Peer Cohorts & Leaderboard
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 font-medium">
            Learn alongside peers in domain cohorts. Compare progress supportively or opt out for a zero-pressure private journey.
          </p>
        </div>

        {/* Tab Toggle */}
        <div className="flex items-center gap-1 bg-white border border-slate-200 p-1.5 rounded-2xl shadow-sm">
          <button
            onClick={() => setActiveTab('cohorts')}
            className={`px-4 py-2 text-xs font-bold rounded-xl transition-all ${
              activeTab === 'cohorts' ? 'bg-brand-600 text-white shadow-sm' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Skill Cohorts
          </button>
          <button
            onClick={() => setActiveTab('leaderboard')}
            className={`px-4 py-2 text-xs font-bold rounded-xl transition-all ${
              activeTab === 'leaderboard' ? 'bg-brand-600 text-white shadow-sm' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Peer Leaderboard
          </button>
        </div>
      </div>

      {/* COHORTS TAB */}
      {activeTab === 'cohorts' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {cohorts.map((cohort) => {
              return (
                <div
                  key={cohort.id}
                  className={`bg-white rounded-3xl p-6 border transition-all flex flex-col justify-between space-y-6 ${
                    cohort.isJoined
                      ? 'border-brand-300 ring-2 ring-brand-500/10 shadow-md'
                      : 'border-slate-200 shadow-sm'
                  }`}
                >
                  <div className="space-y-4">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-[10px] font-extrabold uppercase tracking-wider text-brand-600 bg-brand-50 px-2 py-0.5 rounded-full border border-brand-200">
                            {cohort.skill}
                          </span>
                          {cohort.isJoined && (
                            <span className="text-[10px] font-extrabold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200 flex items-center gap-1">
                              <CheckCircle2 className="w-3 h-3" />
                              <span>Joined</span>
                            </span>
                          )}
                        </div>
                        <h3 className="text-lg font-bold text-slate-900">
                          {cohort.name}
                        </h3>
                      </div>

                      <span className="text-xs font-bold text-slate-500 bg-slate-100 px-3 py-1 rounded-full">
                        {cohort.membersCount.toLocaleString()} Members
                      </span>
                    </div>

                    <p className="text-xs text-slate-600 leading-relaxed">
                      {cohort.description}
                    </p>

                    {/* Weekly Challenge Card */}
                    <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/90 space-y-2.5">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-bold text-slate-800 flex items-center gap-1.5">
                          <Target className="w-3.5 h-3.5 text-brand-600" />
                          Weekly Challenge: {cohort.weeklyChallenge.title}
                        </span>
                        <span className="text-purple-700 font-extrabold bg-purple-50 px-2 py-0.5 rounded-full border border-purple-200">
                          +{cohort.weeklyChallenge.rewardXP} XP
                        </span>
                      </div>

                      <div>
                        <div className="flex justify-between items-center text-[11px] text-slate-500 font-medium mb-1">
                          <span>Team Progress: {cohort.weeklyChallenge.currentCompleted} of {cohort.weeklyChallenge.targetQuests} completed</span>
                          <span>{cohort.weeklyChallenge.daysLeft} days left</span>
                        </div>
                        <ProgressBar
                          progress={(cohort.weeklyChallenge.currentCompleted / cohort.weeklyChallenge.targetQuests) * 100}
                          colorClass="bg-purple-600"
                          heightClass="h-2"
                        />
                      </div>
                    </div>

                    {/* Top Active Members Preview */}
                    <div>
                      <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-2">
                        Top Active Learners This Week
                      </div>
                      <div className="flex items-center gap-2">
                        {cohort.topMembers.map((member, idx) => (
                          <div
                            key={idx}
                            title={`${member.name} (${member.xp} XP)`}
                            className="flex items-center gap-1.5 p-1.5 bg-slate-50 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700 pr-3"
                          >
                            <img src={member.avatar} alt={member.name} className="w-6 h-6 rounded-full object-cover" />
                            <span className="line-clamp-1 text-[11px]">{member.name}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Join / Leave Button */}
                  <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
                    <span className="text-xs text-slate-400">
                      Weekly accountability resets every Sunday
                    </span>
                    {cohort.isJoined ? (
                      <div className="flex gap-2">{!PUBLIC_REVIEW_MODE && <button onClick={() => setChatCohortId(cohort.id)} className="px-4 py-2 text-xs font-bold text-white bg-brand-600 rounded-xl">Open Chat</button>}<button
                        onClick={() => { if (!PUBLIC_REVIEW_MODE) void fetch(`/api/chat/${cohort.id}/leave`, { method: 'POST', credentials: 'same-origin' }); leaveCohort(cohort.id); setChatCohortId(null); }}
                        className="px-4 py-2 text-xs font-bold text-slate-600 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-colors border border-slate-200"
                      >
                        Leave Cohort
                      </button></div>
                    ) : (
                      <button
                        onClick={() => joinCohort(cohort.id)}
                        className="px-5 py-2 bg-brand-600 hover:bg-brand-700 text-white rounded-xl text-xs font-bold shadow-md shadow-brand-500/20 transition-all"
                      >
                        Join Cohort
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
          {PUBLIC_REVIEW_MODE && <p className="text-xs text-slate-600">Cohort membership is a local demo in this review preview. Shared chat is unavailable.</p>}
          {!PUBLIC_REVIEW_MODE && chatCohortId && cohorts.find(c => c.id === chatCohortId && c.isJoined) && <CohortChat cohort={cohorts.find(c => c.id === chatCohortId)!} user={user} onClose={() => setChatCohortId(null)} />}
        </div>
      )}

      {/* LEADERBOARD TAB */}
      {activeTab === 'leaderboard' && (
        <div className="space-y-6">
          {/* Privacy Opt-In Toggle Card */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-start gap-3">
              <div className="p-2.5 rounded-2xl bg-brand-50 text-brand-600 border border-brand-200 mt-0.5">
                {isOptedIn ? <Eye className="w-5 h-5" /> : <EyeOff className="w-5 h-5" />}
              </div>
              <div className="space-y-0.5">
                <h3 className="text-sm font-bold text-slate-900">
                  {isOptedIn ? 'Public Ranking Participation: Enabled' : 'Private Mode: Ranking Hidden'}
                </h3>
                <p className="text-xs text-slate-500 max-w-xl">
                  {isOptedIn
                    ? 'Your XP and streak are visible on the peer leaderboard. You can opt out at any time for zero-pressure learning.'
                    : 'Your progress is completely private. You are invisible on the public leaderboard.'}
                </p>
              </div>
            </div>

            <button
              onClick={() => setOptInLeaderboard(!isOptedIn)}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors ${
                isOptedIn
                  ? 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                  : 'bg-brand-600 hover:bg-brand-700 text-white shadow-sm'
              }`}
            >
              {isOptedIn ? 'Switch to Private' : 'Opt In to Leaderboard'}
            </button>
          </div>

          {/* Leaderboard Table Card */}
          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
            {/* Table Header Controls */}
            <div className="p-5 sm:p-6 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-slate-900">Demonstration Peer Leaderboard</h3>
                <p className="text-xs text-slate-500">Ranked by verified XP earned through completed daily quests</p>
              </div>

              <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl text-xs font-bold">
                <button
                  onClick={() => setPeriod('weekly')}
                  className={`px-3 py-1.5 rounded-lg transition-all ${
                    period === 'weekly' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500'
                  }`}
                >
                  This Week
                </button>
                <button
                  onClick={() => setPeriod('monthly')}
                  className={`px-3 py-1.5 rounded-lg transition-all ${
                    period === 'monthly' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500'
                  }`}
                >
                  This Month
                </button>
              </div>
            </div>

            {/* Leaderboard Rows */}
            <div className="divide-y divide-slate-100">
              {leaderboard.map((entry) => {
                const isUser = entry.isCurrentUser;

                return (
                  <div
                    key={entry.id}
                    className={`p-4 sm:px-6 flex items-center justify-between gap-4 transition-colors ${
                      isUser ? 'bg-brand-50/60 font-semibold' : 'hover:bg-slate-50/60'
                    }`}
                  >
                    <div className="flex items-center gap-4">
                      {/* Rank Number */}
                      <span
                        className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-black ${
                          entry.rank === 1
                            ? 'bg-amber-400 text-amber-950 shadow-sm'
                            : entry.rank === 2
                            ? 'bg-slate-300 text-slate-900'
                            : entry.rank === 3
                            ? 'bg-amber-700/80 text-white'
                            : 'bg-slate-100 text-slate-600'
                        }`}
                      >
                        {entry.rank}
                      </span>

                      {/* User Info */}
                      <div className="flex items-center gap-3">
                        <img
                          src={entry.avatar}
                          alt={entry.name}
                          className="w-10 h-10 rounded-full object-cover ring-2 ring-white shadow-sm"
                        />
                        <div>
                          <div className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                            <span>{entry.name}</span>
                            {isUser && (
                              <span className="text-[10px] font-extrabold text-brand-700 bg-brand-100 px-2 py-0.2 rounded-full">
                                You
                              </span>
                            )}
                          </div>
                          <div className="text-xs text-slate-500 font-medium">
                            {entry.skill} • {entry.badge}
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Stats */}
                    <div className="flex items-center gap-4 sm:gap-8 text-right">
                      <div className="hidden sm:block">
                        <span className="text-[10px] text-slate-400 uppercase font-bold block">Quests</span>
                        <span className="text-xs font-bold text-slate-700">{entry.completedQuests} Done</span>
                      </div>

                      <div className="hidden sm:block">
                        <span className="text-[10px] text-slate-400 uppercase font-bold block">Streak</span>
                        <span className="text-xs font-extrabold text-amber-600 flex items-center gap-1">
                          <Flame className="w-3.5 h-3.5 fill-amber-500" />
                          {entry.streak}d
                        </span>
                      </div>

                      <div className="min-w-[90px]">
                        <span className="text-[10px] text-slate-400 uppercase font-bold block">Earned XP</span>
                        <span className="text-sm font-black text-brand-600 flex items-center justify-end gap-1">
                          <Zap className="w-3.5 h-3.5 fill-brand-600" />
                          {entry.xpEarned}
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
