import React, { useState } from 'react';
import { useSkillQuest } from '../context/SkillQuestContext';
import { generateLearningRoadmap } from '../services/geminiService';
import { localDate } from '../utils/dailyLearning';
import { ProgressBar } from '../components/common/ProgressBar';
import { QuestModal } from '../components/common/QuestModal';
import { Milestone, Quest, TopicCategory } from '../types';
import {
  Compass,
  CheckCircle2,
  Lock,
  Clock,
  Sparkles,
  ChevronDown,
  ChevronUp,
  ExternalLink,
  BookOpen,
  Edit3,
  RotateCw,
  Zap,
  Target,
  Check,
  Play,
  Layers,
  ArrowRight,
  Loader2,
  PlusCircle,
  FolderKanban,
  GraduationCap
} from 'lucide-react';

export const RoadmapPage: React.FC = () => {
  const { goal, milestones, quests, resources, user, topics, addTopicToRoadmap, updateGoal, setNewLearningRoadmap } = useSkillQuest();

  const [expandedMilestones, setExpandedMilestones] = useState<Record<string, boolean>>({
    [milestones[0]?.id || '']: true,
    [milestones[1]?.id || '']: true,
  });

  const [selectedTopicCategory, setSelectedTopicCategory] = useState<TopicCategory | 'all'>('all');
  const [selectedQuest, setSelectedQuest] = useState<Quest | null>(null);
  const [isEditingGoal, setIsEditingGoal] = useState(false);
  const [isRegenerating, setIsRegenerating] = useState(false);

  // Edit goal form
  const [editSkill, setEditSkill] = useState(goal.skill);
  const [editAvailableTime, setEditAvailableTime] = useState(goal.availableTime);
  const [editDeadline, setEditDeadline] = useState(goal.deadline);
  const [editDays, setEditDays] = useState(goal.daysPerWeek || 7);
  const [editAvailableDays, setEditAvailableDays] = useState(goal.availableDays || ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday']);

  const toggleExpand = (id: string) => {
    setExpandedMilestones(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const handleSaveGoal = () => {
    if (!editSkill.trim() || !editAvailableTime.trim() || !editDeadline.trim() || editDays < 1) return;
    updateGoal({
      skill: editSkill,
      availableTime: editAvailableTime,
      deadline: editDeadline,
      daysPerWeek: editDays,
      availableDays: editAvailableDays,
      schedulePreference: editAvailableDays.join(', '),
      targetDate: /^\d{4}-\d{2}-\d{2}$/.test(editDeadline) ? editDeadline : goal.targetDate,
    });
    setIsEditingGoal(false);
  };

  const handleRegenerate = async () => {
    setIsRegenerating(true);
    try {
      const generated = await generateLearningRoadmap({
        skill: goal.skill,
        currentLevel: goal.currentLevel,
        targetLevel: goal.targetLevel,
        availableTime: goal.availableTime,
        daysPerWeek: goal.daysPerWeek,
        availableDays: goal.availableDays,
        targetDate: goal.targetDate,
        deadline: goal.deadline,
        schedulePreference: goal.schedulePreference,
        motivation: goal.motivation,
        apiKey: user.settings.geminiApiKey,
      });

      const goalId = goal.id;
      const newMilestones: Milestone[] = generated.milestones.map((m, idx) => ({
        ...m,
        id: `ms_${goalId}_${idx + 1}`,
        goalId,
      }));
      const days = goal.availableDays?.length ? goal.availableDays : ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'];
      const dates: string[] = [];
      const cursor = new Date();
      while (dates.length < generated.quests.length) {
        if (days.includes(['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'][cursor.getDay()])) dates.push(localDate(undefined, cursor));
        cursor.setDate(cursor.getDate() + 1);
      }

      const newQuests: Quest[] = generated.quests.map((q, idx) => {
        const milestoneSeq = (q as any).associatedMilestoneSequence || (idx === 0 ? 1 : Math.min(newMilestones.length, Math.floor(idx / 2) + 1));
        const matchedMs = newMilestones.find(m => m.sequence === milestoneSeq) || newMilestones[0];

        return {
          ...q,
          id: `qst_${goalId}_${idx + 1}`,
          bonusQuestions: q.bonusQuestions?.map(b => ({ ...b, questId: `qst_${goalId}_${idx + 1}` })),
          milestoneId: matchedMs.id,
          status: 'todo' as const,
          isToday: dates[idx] === localDate(),
          scheduledDate: dates[idx],
        };
      });

      const newResources = generated.resources.map((r, idx) => ({
        ...r,
        id: `res_${goalId}_${idx + 1}`,
        skill: goal.skill,
      }));

      setNewLearningRoadmap(
        { ...goal, overallProgress: 0 },
        newMilestones,
        newQuests,
        newResources,
        generated.topics,
        generated.midwayProject
      );
    } catch (err) {
      console.error('Failed to regenerate roadmap:', err);
    } finally {
      setIsRegenerating(false);
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn text-left min-w-0 max-w-6xl mx-auto">
      {/* Top Banner / Roadmap Summary */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="min-w-0">
            <div className="flex items-center gap-2 mb-2">
              <span className="text-xs font-bold uppercase tracking-wider text-brand-600 bg-brand-50 px-3 py-1 rounded-full border border-brand-200 flex items-center gap-1.5">
                <Compass className="w-3.5 h-3.5 text-brand-600" />
                Skill Learning Path
              </span>
              <span className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full ${
                user.settings.geminiApiKey ? 'bg-purple-100 text-purple-700' : 'bg-slate-100 text-slate-700'
              }`}>
                {user.settings.geminiApiKey ? '✨ Live Gemini 1.5 Flash' : '⚡ Smart Curriculum Engine'}
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-navy-950">
              {goal.skill}
            </h1>
            <p className="text-xs sm:text-sm text-slate-500 mt-1 max-w-2xl leading-relaxed">
              Target: <strong className="text-slate-800">{goal.targetLevel}</strong> • Commitment: <strong className="text-slate-800">{goal.availableTime}</strong> • Estimated Completion: <strong className="text-slate-800">{goal.deadline}</strong>
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => setIsEditingGoal(true)}
              className="flex items-center gap-1.5 px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition-colors"
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>Edit Goal</span>
            </button>
            <button
              onClick={handleRegenerate}
              disabled={isRegenerating}
              className="flex items-center gap-1.5 px-4 py-2 bg-brand-600 hover:bg-brand-700 text-white rounded-xl text-xs font-bold shadow-md shadow-brand-500/20 transition-all disabled:opacity-50"
            >
              {isRegenerating ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <RotateCw className="w-3.5 h-3.5" />}
              <span>{isRegenerating ? 'Regenerating...' : 'Regenerate Roadmap'}</span>
            </button>
          </div>
        </div>

        {/* Overall Progress Bar */}
        <div className="pt-2 border-t border-slate-100">
          <div className="flex justify-between items-center text-xs font-bold text-slate-700 mb-2">
            <span>Overall Roadmap Completion</span>
            <span className="text-brand-600">{goal.overallProgress}% Complete</span>
          </div>
          <ProgressBar progress={goal.overallProgress} colorClass="bg-brand-600" heightClass="h-3" />
        </div>
      </div>

      {/* Timeline / Expandable Milestone Tree */}
      <div className="space-y-6">
        <h2 className="text-lg font-black text-navy-950 flex items-center gap-2">
          <Layers className="w-5 h-5 text-brand-600" />
          <span>Curriculum Milestones ({milestones.length})</span>
        </h2>

        <div className="space-y-4">
          {milestones.map((ms, index) => {
            const isExpanded = expandedMilestones[ms.id] ?? false;
            const msQuests = quests.filter(q => q.milestoneId === ms.id && !q.kind);
            const completedCount = msQuests.filter(q => q.status === 'completed').length;
            const progress = msQuests.length > 0 ? Math.round((completedCount / msQuests.length) * 100) : ms.status === 'completed' ? 100 : 0;
            const msResources = resources.filter(r => r.associatedMilestoneSequence === ms.sequence);

            return (
              <div
                key={ms.id}
                className={`bg-white rounded-3xl border transition-all overflow-hidden ${
                  ms.status === 'completed'
                    ? 'border-emerald-200 shadow-sm'
                    : ms.status === 'in-progress'
                    ? 'border-brand-300 shadow-md ring-1 ring-brand-500/20'
                    : 'border-slate-200 opacity-90'
                }`}
              >
                {/* Milestone Accordion Header */}
                <div
                  onClick={() => toggleExpand(ms.id)}
                  className="p-4 sm:p-6 cursor-pointer flex items-start sm:items-center justify-between gap-3 min-w-0 hover:bg-slate-50/70 transition-colors select-none"
                >
                  <div className="flex items-start gap-3 sm:gap-4 min-w-0">
                    {/* Status Badge Icon */}
                    <div
                      className={`w-10 h-10 rounded-2xl flex items-center justify-center flex-shrink-0 text-sm font-bold shadow-sm ${
                        ms.status === 'completed'
                          ? 'bg-emerald-500 text-white'
                          : ms.status === 'in-progress'
                          ? 'bg-brand-600 text-white'
                          : 'bg-slate-100 text-slate-400'
                      }`}
                    >
                      {ms.status === 'completed' ? (
                        <Check className="w-5 h-5 stroke-[3]" />
                      ) : ms.status === 'in-progress' ? (
                        <span>{ms.sequence}</span>
                      ) : (
                        <Lock className="w-4 h-4" />
                      )}
                    </div>

                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-2 mb-1">
                        <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-600">
                          Milestone {ms.sequence} • ~{ms.estimatedWeeks} Weeks
                        </span>
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            ms.status === 'completed'
                              ? 'bg-emerald-100 text-emerald-800'
                              : ms.status === 'in-progress'
                              ? 'bg-brand-100 text-brand-800'
                              : 'bg-slate-100 text-slate-600'
                          }`}
                        >
                          {ms.status === 'completed' ? 'Completed' : ms.status === 'in-progress' ? 'Active' : 'Locked'}
                        </span>
                      </div>
                      <h3 className="text-base sm:text-lg font-bold text-slate-900 break-words">
                        {ms.title}
                      </h3>
                      <p className="text-xs text-slate-500 mt-0.5 line-clamp-1 sm:line-clamp-none">
                        {ms.description}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 sm:gap-4 flex-shrink-0">
                    <div className="hidden sm:flex flex-col items-end text-xs">
                      <span className="font-bold text-slate-800">{completedCount} / {msQuests.length} Quests</span>
                      <span className="text-slate-600">{progress}% Done</span>
                    </div>
                    <div className="p-1.5 text-slate-400 hover:text-slate-600">
                      {isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                    </div>
                  </div>
                </div>

                {/* Expanded Milestone Details */}
                {isExpanded && (
                  <div className="px-5 sm:px-6 pb-6 pt-2 border-t border-slate-100 space-y-6 bg-slate-50/40">
                    {/* Completion Criteria */}
                    {ms.criteria && ms.criteria.length > 0 && (
                      <div className="p-4 rounded-2xl bg-white border border-slate-200">
                        <h4 className="text-xs font-bold uppercase tracking-wider text-slate-600 mb-2.5">
                          Milestone Completion Criteria
                        </h4>
                        <ul className="space-y-1.5 text-xs text-slate-700">
                          {ms.criteria.map((crit, idx) => (
                            <li key={idx} className="flex items-start gap-2">
                              <CheckCircle2 className={`w-4 h-4 flex-shrink-0 mt-0.5 ${
                                ms.status === 'completed' ? 'text-emerald-500' : 'text-slate-400'
                              }`} />
                              <span>{crit}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {/* Associated Quests */}
                    <div>
                      <div className="flex items-center justify-between mb-3">
                        <h4 className="text-xs font-bold uppercase tracking-wider text-slate-600">
                          Daily Quests in this Milestone ({msQuests.length})
                        </h4>
                        <span className="text-[11px] font-semibold text-slate-600">
                          Click any quest to inspect & execute
                        </span>
                      </div>

                      {msQuests.length === 0 ? (
                        <div className="p-4 rounded-xl bg-white border border-slate-200 text-xs text-slate-500 text-center">
                          Quests will unlock when prior milestone is completed.
                        </div>
                      ) : (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                          {msQuests.map((quest) => (
                            <div
                              key={quest.id}
                              onClick={() => setSelectedQuest(quest)}
                              className={`p-4 rounded-2xl border transition-all cursor-pointer quest-card-hover ${
                                quest.status === 'completed'
                                  ? 'bg-emerald-50/30 border-emerald-200'
                                  : 'bg-white border-slate-200 hover:border-brand-400'
                              }`}
                            >
                              <div className="flex items-start justify-between gap-2 mb-1.5">
                                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                                  quest.difficulty === 'Beginner' ? 'bg-emerald-100 text-emerald-800' :
                                  quest.difficulty === 'Intermediate' ? 'bg-blue-100 text-blue-800' :
                                  'bg-purple-100 text-purple-800'
                                }`}>
                                  {quest.difficulty}
                                </span>
                                <span className="flex items-center gap-1 text-xs font-bold text-brand-600">
                                  <Zap className="w-3.5 h-3.5 fill-brand-600" />
                                  +{quest.xpReward} XP
                                </span>
                              </div>

                              <h5 className="text-xs font-bold text-slate-900 mb-1 line-clamp-1">
                                {quest.title}
                              </h5>
                              <p className="text-[11px] text-slate-500 line-clamp-2 mb-2">
                                {quest.description}
                              </p>

                              <div className="flex items-center justify-between text-[11px] text-slate-500 pt-2 border-t border-slate-100">
                                <span className="flex items-center gap-1">
                                  <Clock className="w-3 h-3" />
                                  {quest.durationMinutes} mins
                                </span>
                                {quest.status === 'completed' ? (
                                  <span className="flex items-center gap-1 text-emerald-600 font-bold">
                                    <Check className="w-3.5 h-3.5 stroke-[3]" />
                                    <span>Completed</span>
                                  </span>
                                ) : (
                                  <span className="text-brand-600 font-bold flex items-center gap-1 hover:underline">
                                    <span>Start Quest</span>
                                    <ArrowRight className="w-3 h-3" />
                                  </span>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>

                    {/* Curated Resources for this Milestone */}
                    {msResources.length > 0 && (
                      <div>
                        <h4 className="text-xs font-bold uppercase tracking-wider text-slate-600 mb-2.5">
                          Curated Learning Resources ({msResources.length})
                        </h4>
                        <div className="space-y-2">
                          {msResources.map((res) => (
                            <div
                              key={res.id}
                              className="p-3 bg-white rounded-xl border border-slate-200 flex items-center justify-between"
                            >
                              <div className="flex items-center gap-3">
                                <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center flex-shrink-0">
                                  <BookOpen className="w-4 h-4" />
                                </div>
                                <div>
                                  <div className="text-xs font-bold text-slate-900">{res.title}</div>
                                  <div className="text-[11px] text-slate-500">{res.provider} • {res.duration}</div>
                                </div>
                              </div>
                              <a
                                href={res.url}
                                target="_blank"
                                rel="noreferrer"
                                className="flex items-center gap-1 text-xs font-semibold text-brand-600 hover:text-brand-700 px-3 py-1.5 rounded-lg hover:bg-brand-50 transition-colors"
                              >
                                <span>Open</span>
                                <ExternalLink className="w-3.5 h-3.5" />
                              </a>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Explore More Topics Section */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-bold uppercase tracking-wider text-purple-600 bg-purple-50 px-3 py-1 rounded-full border border-purple-200 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-purple-600" />
                Optional Learning Paths
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-navy-950">
              Explore More Topics
            </h2>
            <p className="text-xs text-slate-500 mt-1 max-w-2xl leading-relaxed">
              Broaden your knowledge with supplementary topics and hands-on capstone projects. Add any topic to automatically generate relevant quests on your roadmap.
            </p>
          </div>

          {/* Category Filter Pills */}
          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-2xl overflow-x-auto text-xs font-bold">
            {[
              { id: 'all', label: 'All Topics' },
              { id: 'core', label: 'Core' },
              { id: 'additional', label: 'Additional' },
              { id: 'advanced', label: 'Advanced' },
              { id: 'project', label: 'Projects' },
            ].map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedTopicCategory(cat.id as any)}
                className={`px-3 py-1.5 rounded-xl transition-all whitespace-nowrap ${
                  selectedTopicCategory === cat.id
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Topics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
          {topics
            .filter(t => selectedTopicCategory === 'all' || t.category === selectedTopicCategory)
            .map((topic) => {
              const inRoadmap = topic.isAddedToRoadmap;

              return (
                <div
                  key={topic.id}
                  className={`p-5 rounded-2xl border transition-all flex flex-col justify-between space-y-4 ${
                    inRoadmap
                      ? 'bg-brand-50/20 border-brand-200 ring-1 ring-brand-500/10'
                      : 'bg-white border-slate-200 hover:border-slate-300 shadow-sm'
                  }`}
                >
                  <div className="space-y-2">
                    <div className="flex items-center justify-between gap-2">
                      <span className={`text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full ${
                        topic.category === 'core' ? 'bg-slate-100 text-slate-700' :
                        topic.category === 'additional' ? 'bg-blue-50 text-blue-700 border border-blue-200' :
                        topic.category === 'advanced' ? 'bg-purple-50 text-purple-700 border border-purple-200' :
                        'bg-amber-50 text-amber-800 border border-amber-200'
                      }`}>
                        {topic.category.toUpperCase()} • {topic.difficulty}
                      </span>

                      <span className="text-[11px] font-medium text-slate-500 flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {topic.estimatedDuration}
                      </span>
                    </div>

                    <h4 className="text-sm font-bold text-slate-900 leading-snug">
                      {topic.name}
                    </h4>

                    <p className="text-xs text-slate-600 leading-relaxed">
                      {topic.description}
                    </p>

                    <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 text-xs text-slate-700 space-y-1">
                      <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                        Optional Practical Exercise
                      </div>
                      <p className="text-[11px] text-slate-700 leading-relaxed">
                        {topic.practicalExercise}
                      </p>
                    </div>

                    {topic.recommendedResources && topic.recommendedResources.length > 0 && (
                      <div className="text-[11px] text-slate-500 flex items-center gap-1 pt-1">
                        <BookOpen className="w-3 h-3 text-brand-600" />
                        <span>Recommended:</span>
                        <a
                          href={topic.recommendedResources[0].url}
                          target="_blank"
                          rel="noreferrer"
                          className="font-bold text-brand-600 hover:underline inline-flex items-center gap-0.5"
                        >
                          {topic.recommendedResources[0].title}
                          <ExternalLink className="w-2.5 h-2.5" />
                        </a>
                      </div>
                    )}
                  </div>

                  {/* Add to Roadmap Action */}
                  <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                    <span className="text-[11px] text-slate-400">
                      {inRoadmap ? 'Active in your curriculum' : 'Optional elective path'}
                    </span>

                    {inRoadmap ? (
                      <span className="flex items-center gap-1 text-xs font-bold text-emerald-700 bg-emerald-50 px-3 py-1 rounded-xl border border-emerald-200">
                        <Check className="w-3.5 h-3.5 stroke-[3]" />
                        <span>In Roadmap</span>
                      </span>
                    ) : (
                      <button
                        onClick={() => addTopicToRoadmap(topic.id)}
                        className="flex items-center gap-1.5 px-3.5 py-1.5 bg-brand-600 hover:bg-brand-700 text-white rounded-xl text-xs font-bold transition-all shadow-sm"
                      >
                        <PlusCircle className="w-3.5 h-3.5" />
                        <span>Add to My Roadmap</span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
        </div>
      </div>

      {/* Edit Goal Modal */}
      {isEditingGoal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white rounded-2xl p-4 sm:p-6 max-w-md w-full min-w-0 max-h-[calc(100dvh-2rem)] overflow-y-auto border border-slate-200 shadow-2xl space-y-4">
            <h3 className="text-lg font-bold text-slate-900">Edit Learning Goal</h3>
            <div className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Target Skill</label>
                <input
                  type="text"
                  value={editSkill}
                  onChange={(e) => setEditSkill(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl"
                />
              </div>
              <div>
                <label className="block font-bold text-slate-700 mb-1">Daily Commitment</label>
                <input
                  type="text"
                  value={editAvailableTime}
                  onChange={(e) => setEditAvailableTime(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl"
                />
              </div>
              <div>
                <label className="block font-bold text-slate-700 mb-1">Timeline Deadline</label>
                <input
                  type="text"
                  value={editDeadline}
                  onChange={(e) => setEditDeadline(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl"
                />
              </div>
              <div><label className="block font-bold text-slate-700 mb-1">Learning days per week</label><select value={editDays} onChange={e => { const n = Number(e.target.value); setEditDays(n); setEditAvailableDays(['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'].slice(0,n)); }} className="w-full px-3 py-2 border border-slate-200 rounded-xl">{[1,2,3,4,5,6,7].map(n => <option key={n} value={n}>{n} {n === 1 ? 'day' : 'days'}</option>)}</select></div>
              <div className="flex flex-wrap gap-2">{['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'].map(day => <label key={day} className="px-2 py-1 border rounded-lg"><input type="checkbox" checked={editAvailableDays.includes(day)} onChange={() => setEditAvailableDays(prev => { const next = prev.includes(day) ? prev.filter(d => d !== day) : [...prev,day]; setEditDays(next.length); return next; })} /> {day}</label>)}</div>
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
              <button
                onClick={() => setIsEditingGoal(false)}
                className="px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-xl"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveGoal}
                className="px-4 py-2 text-xs font-bold bg-brand-600 text-white rounded-xl shadow-sm hover:bg-brand-700"
              >
                Save Changes
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Quest Modal */}
      <QuestModal
        quest={selectedQuest}
        isOpen={Boolean(selectedQuest)}
        onClose={() => setSelectedQuest(null)}
      />
    </div>
  );
};
