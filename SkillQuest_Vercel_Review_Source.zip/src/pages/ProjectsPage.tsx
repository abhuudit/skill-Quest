import React, { useState } from 'react';
import { useSkillQuest } from '../context/SkillQuestContext';
import { QuestModal } from '../components/common/QuestModal';
import { midwayUnlocked } from '../utils/dailyLearning';

export const ProjectsPage: React.FC = () => {
  const { goal, user, quests, milestones, portfolio, savePortfolioEntry } = useSkillQuest();
  const project = quests.find(q => q.kind === 'midway' && q.goalId === goal.id);
  const unlocked = project ? midwayUnlocked(project, milestones) : false;
  const entry = portfolio.find(p => p.questId === project?.id && p.userId === user.id);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(false);
  const [error, setError] = useState('');
  const [title, setTitle] = useState(entry?.title || project?.title || '');
  const [description, setDescription] = useState(entry?.description || project?.description || '');
  const [skills, setSkills] = useState(entry?.skills.join(', ') || project?.skillsAssessed?.join(', ') || '');
  const [tools, setTools] = useState(entry?.tools || '');
  const [outcome, setOutcome] = useState(entry?.outcome || '');
  const [evidenceLink, setEvidenceLink] = useState(entry?.evidenceLink || '');
  const save = () => {
    if (!project) return;
    try { savePortfolioEntry({ questId: project.id, title, description, skills: skills.split(','), tools, outcome, evidenceLink }); setError(''); setEditing(false); }
    catch (e) { setError(e instanceof Error ? e.message : 'Could not save project.'); }
  };
  const copy = async () => {
    if (!entry) return;
    const summary = `${entry.title}\n${entry.description}\nSkills demonstrated: ${entry.skills.join(', ')}${entry.tools ? `\nTools: ${entry.tools}` : ''}${entry.outcome ? `\nOutcome: ${entry.outcome}` : ''}\nCompleted: ${new Date(entry.completedAt).toLocaleDateString()}${entry.evidenceLink ? `\nEvidence: ${entry.evidenceLink}` : ''}`;
    try { await navigator.clipboard.writeText(summary); setError('CV summary copied.'); } catch { setError('Copy failed. Please select the text manually.'); }
  };
  return <div className="max-w-4xl mx-auto space-y-6 animate-fadeIn text-left">
    <div><p className="text-xs font-bold uppercase text-brand-600">Verified work</p><h1 className="text-3xl font-black text-navy-950">My Projects & Portfolio</h1><p className="text-sm text-slate-600">Showcase practical work only after a cleared project evaluation.</p></div>
    {project && <section className="bg-white border border-slate-200 rounded-3xl p-6 space-y-4"><div className="flex items-start justify-between gap-3"><div><span className="text-xs font-bold text-brand-600">Midway Project — Put Your Skills Into Practice</span><h2 className="text-xl font-black text-slate-900">{project.title}</h2></div><span className="text-xs text-slate-600">+{project.xpReward} project XP</span></div><p className="text-sm text-slate-700">{project.description}</p><div className="grid sm:grid-cols-2 gap-4 text-sm"><div><h3 className="font-bold text-slate-900">Objectives & deliverables</h3><ul className="list-disc pl-5 text-slate-600">{project.projectObjectives?.map((o,i) => <li key={i}>{o}</li>)}</ul></div><div><h3 className="font-bold text-slate-900">Skills assessed</h3><ul className="list-disc pl-5 text-slate-600">{project.skillsAssessed?.map((s,i) => <li key={i}>{s}</li>)}</ul></div></div><p className="text-xs text-slate-500">{project.durationMinutes} minutes estimated · {project.submissionRequirements}</p>{project.optionalEnhancements?.length ? <p className="text-xs text-slate-600">Optional: {project.optionalEnhancements.join(' ')}</p> : null}{!unlocked && project.status !== 'completed' ? <p className="p-3 rounded-xl bg-amber-50 text-amber-900 text-sm">Complete the first {project.prerequisiteMilestoneIds?.length} roadmap milestones to unlock this project. Calendar time alone does not unlock it.</p> : <button onClick={() => setOpen(true)} className="px-5 py-2 bg-brand-600 text-white rounded-xl text-sm font-bold">{project.status === 'completed' ? 'Review verified project' : 'Open project quest'}</button>}{project.latestEvaluation && <p className="text-sm text-slate-600">Evaluation: {project.latestEvaluation.status.replace('_',' ')} · {project.latestEvaluation.feedback}</p>}</section>}
    {project?.status === 'completed' && project.latestEvaluation?.status === 'cleared' && <section className="bg-white border border-slate-200 rounded-3xl p-6 space-y-3"><h2 className="text-lg font-bold text-slate-900">Add to My Portfolio / CV</h2><p className="text-xs text-slate-500">Edit this summary before saving. Include only details supported by your work.</p>{!editing ? <button onClick={() => setEditing(true)} className="px-4 py-2 bg-brand-600 text-white rounded-xl text-sm">{entry ? 'Edit project entry' : 'Create project entry'}</button> : <div className="space-y-2"><input aria-label="Project title" value={title} onChange={e => setTitle(e.target.value)} className="w-full p-2 border border-slate-300 rounded-xl" /><textarea aria-label="Project description" value={description} onChange={e => setDescription(e.target.value)} className="w-full p-2 border border-slate-300 rounded-xl" /><input aria-label="Skills demonstrated" value={skills} onChange={e => setSkills(e.target.value)} placeholder="Skills, comma separated" className="w-full p-2 border border-slate-300 rounded-xl" /><input aria-label="Tools used" value={tools} onChange={e => setTools(e.target.value)} placeholder="Tools used, if relevant" className="w-full p-2 border border-slate-300 rounded-xl" /><textarea aria-label="Project outcome" value={outcome} onChange={e => setOutcome(e.target.value)} placeholder="What did the finished work demonstrate?" className="w-full p-2 border border-slate-300 rounded-xl" /><input aria-label="Evidence link" value={evidenceLink} onChange={e => setEvidenceLink(e.target.value)} placeholder="Optional https:// evidence link" className="w-full p-2 border border-slate-300 rounded-xl" /><button onClick={save} className="px-4 py-2 bg-brand-600 text-white rounded-xl text-sm">Save project entry</button></div>}</section>}
    <section className="space-y-3"><h2 className="text-lg font-bold text-slate-900">Saved portfolio entries</h2>{!portfolio.filter(p => p.userId === user.id && p.goalId === goal.id).length && <p className="text-sm text-slate-500">No verified projects saved yet.</p>}{portfolio.filter(p => p.userId === user.id && p.goalId === goal.id).map(p => <article key={p.id} className="bg-white border border-slate-200 rounded-2xl p-4"><h3 className="font-bold text-slate-900">{p.title}</h3><p className="text-sm text-slate-600">{p.description}</p><p className="text-xs text-slate-500">{p.skills.join(', ')} · Completed {new Date(p.completedAt).toLocaleDateString()}</p>{p.id === entry?.id && <button onClick={copy} className="mt-2 text-xs text-brand-600 font-bold">Copy CV summary</button>}</article>)}</section>
    {error && <p role="status" className="text-sm text-brand-600">{error}</p>}
    <QuestModal quest={project || null} isOpen={open} onClose={() => setOpen(false)} />
  </div>;
};
