import React, { useState } from 'react';
import { useSkillQuest } from '../context/SkillQuestContext';
import { QuestModal } from '../components/common/QuestModal';
import { Quest } from '../types';
import { localDate } from '../utils/dailyLearning';
import {
  Flame,
  Shield,
  RotateCcw,
  Sparkles,
  Calendar,
  HeartHandshake,
  CheckCircle2,
  Clock,
  ArrowRight,
  TrendingUp,
  Award,
  Zap,
  Info
} from 'lucide-react';

export const StreaksPage: React.FC = () => {
  const { user, goal, activityHistory, comebackPlan, triggerComebackPlan, dismissComebackPlan, quests, dailyCredits, updateGoal } = useSkillQuest();
  const [isGeneratingPlan, setIsGeneratingPlan] = useState(false);
  const [selectedQuest, setSelectedQuest] = useState<Quest | null>(null);
  const [showAdjustSchedule, setShowAdjustSchedule] = useState(false);

  const handleGenerateComeback = async () => {
    setIsGeneratingPlan(true);
    try {
      await triggerComebackPlan(3);
    } finally {
      setIsGeneratingPlan(false);
    }
  };

  // Find comeback quests in active quests list
  const activeComebackQuests = quests.filter(q => q.isComebackQuest);

  // Compute active days in past 28 days
  const activeDaysCount = activityHistory.filter(a => a.count > 0).length;

  return (
    <div className="space-y-8 animate-fadeIn text-left">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-bold uppercase tracking-wider text-amber-700 bg-amber-50 px-3 py-1 rounded-full border border-amber-200 flex items-center gap-1.5">
              <Flame className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
              Sustained Consistency
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-navy-950">
            Streaks & Empathetic Comeback System
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 font-medium">
            Building a skill takes patience. We celebrate your daily practice without ever punishing life's inevitable breaks.
          </p>
        </div>

        {/* Streak Overview Card */}
        <div className="flex items-center gap-3">
          <div className="px-5 py-3 bg-white rounded-3xl border border-slate-200 shadow-sm flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center border border-amber-200">
              <Flame className="w-6 h-6 fill-amber-500 text-amber-500 animate-pulse" />
            </div>
            <div>
              <div className="text-[10px] text-slate-600 uppercase font-bold">Active Streak</div>
              <div className="text-base font-black text-amber-600">{user.currentStreak} Days Consecutive</div>
            </div>
          </div>
        </div>
      </div>

      {/* Philosophy Callout: Zero-Guilt Philosophy */}
      <div className="bg-gradient-to-r from-emerald-50 via-teal-50 to-blue-50 dark:from-emerald-950 dark:via-teal-950 dark:to-slate-900 border border-emerald-200 dark:border-emerald-800 rounded-3xl p-6 sm:p-7 shadow-sm">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-2xl bg-white border border-emerald-200 flex items-center justify-center text-emerald-600 shadow-sm flex-shrink-0">
            <HeartHandshake className="w-6 h-6" />
          </div>
          <div className="space-y-1.5">
            <h3 className="text-base font-bold text-slate-900 dark:text-emerald-100">
              Our Non-Punishing Streak Philosophy
            </h3>
            <p className="text-xs sm:text-sm text-slate-700 dark:text-slate-200 leading-relaxed max-w-3xl">
              Traditional apps punish learners by stripping their hard-earned progress if they miss a single day. At SkillQuest, we know real life happens. If you take a break, your total XP and milestones remain permanently yours. Our AI offers gentle comeback plans to help you rebuild momentum with zero guilt.
            </p>
          </div>
        </div>
      </div>

      {/* Main Streaks & Activity Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Streak Stats Cards */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-600">Streak Statistics</h3>

            <div className="grid grid-cols-2 gap-3">
              <div className="p-4 rounded-2xl bg-amber-50/50 border border-amber-100">
                <span className="text-xs text-amber-900 font-semibold block">Current Streak</span>
                <span className="text-2xl font-black text-amber-700">{user.currentStreak} Days</span>
                <span className="text-[11px] text-amber-700 block mt-1">{dailyCredits.includes(`${goal.id}:${localDate(user.settings.timeZone)}`) ? 'Daily goal completed today' : 'Today’s requirements pending'}</span>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
                <span className="text-xs text-slate-600 font-semibold block">Longest Streak</span>
                <span className="text-2xl font-black text-slate-900">{user.longestStreak} Days</span>
                <span className="text-[11px] text-emerald-600 font-bold block mt-1">Personal Best</span>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2 text-xs">
              <div className="flex justify-between items-center">
                <span className="text-slate-600 font-medium">Monthly Active Days:</span>
                <strong className="text-slate-900">{activeDaysCount} of 28 Days ({Math.round((activeDaysCount / 28) * 100)}%)</strong>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-600 font-medium">Streak Protection:</span>
                <span className="text-emerald-600 font-bold">Earned XP stays safe</span>
              </div>
            </div>
          </div>

          {/* Comeback Action Card */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-3">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-brand-600" />
              <span>Feeling Overwhelmed or Taking a Break?</span>
            </h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              If your schedule changed or you missed several days, let the AI rebuild a low-friction comeback ramp with 10-minute micro-wins.
            </p>
            <div className="pt-2 flex flex-wrap gap-2">
              <button
                onClick={handleGenerateComeback}
                disabled={isGeneratingPlan}
                className="flex items-center gap-2 px-4 py-2.5 bg-brand-600 hover:bg-brand-700 text-white rounded-xl text-xs font-bold shadow-md shadow-brand-500/20 transition-all disabled:opacity-50"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>{isGeneratingPlan ? 'Building Plan...' : 'Generate AI Comeback Plan'}</span>
              </button>
              <button
                onClick={() => setShowAdjustSchedule(!showAdjustSchedule)}
                className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition-colors"
              >
                Adjust Schedule
              </button>
            </div>

            {showAdjustSchedule && (
              <div className="p-3.5 mt-3 bg-slate-50 border border-slate-200 rounded-xl text-xs space-y-2 animate-fadeIn">
                <span className="font-bold text-slate-800">Quick Pace Calibration:</span>
                <p className="text-slate-600 text-[11px]">
                  Switch daily commitment to 15 minutes to reduce cognitive friction while maintaining momentum.
                </p>
                <button
                  onClick={() => {
                    updateGoal({ availableTime: '15 minutes per day' });
                    setShowAdjustSchedule(false);
                  }}
                  className="px-3 py-1 bg-brand-600 text-white rounded-lg text-xs font-bold"
                >
                  Set to 15m Gentle Pace
                </button>
              </div>
            )}
          </div>
        </div>

        {/* 28-Day Activity Heatmap Grid */}
        <div className="lg:col-span-7 bg-white rounded-3xl p-6 sm:p-7 border border-slate-200 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-base font-bold text-slate-900">28-Day Deliberate Practice Heatmap</h3>
                <p className="text-xs text-slate-500">Historical activity and completed daily goals</p>
              </div>
              <span className="text-xs font-bold text-slate-600 bg-slate-100 px-3 py-1 rounded-full">
                Past 4 Weeks
              </span>
            </div>

            {/* Heatmap Grid */}
            <div className="pt-4 pb-2">
              <div className="grid grid-cols-7 gap-2.5">
                {activityHistory.slice(-28).map((day, idx) => {
                  const d = new Date(day.date);
                  const isToday = idx === 27;

                  return (
                    <div
                      key={day.date}
                      title={`${day.date}: ${day.count} recorded learning activities (${day.xp} XP)`}
                      className={`h-10 rounded-xl flex flex-col items-center justify-center text-[10px] font-bold transition-transform hover:scale-110 cursor-pointer border ${
                        day.count === 0
                          ? 'bg-slate-100 border-slate-200 text-slate-400'
                          : day.level === 1
                          ? 'bg-brand-100 border-brand-200 text-brand-700'
                          : day.level === 2
                          ? 'bg-brand-300 border-brand-400 text-brand-900'
                          : 'bg-brand-600 border-brand-700 text-white shadow-sm'
                      } ${isToday ? 'ring-2 ring-amber-500 ring-offset-2' : ''}`}
                    >
                      <span>{d.getDate()}</span>
                      {day.count > 0 && <span className="text-[8px] font-normal opacity-90">{day.count}</span>}
                    </div>
                  );
                })}
              </div>

              {/* Heatmap Legend */}
              <div className="flex items-center justify-between text-xs text-slate-500 pt-6">
                <span>Less active</span>
                <div className="flex items-center gap-1.5">
                  <div className="w-3.5 h-3.5 rounded bg-slate-100 border border-slate-200" />
                  <div className="w-3.5 h-3.5 rounded bg-brand-100 border border-brand-200" />
                  <div className="w-3.5 h-3.5 rounded bg-brand-300 border border-brand-400" />
                  <div className="w-3.5 h-3.5 rounded bg-brand-600 border border-brand-700" />
                </div>
                <span>More active</span>
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <span className="flex items-center gap-1.5">
              <Calendar className="w-4 h-4 text-brand-600" />
              <span>Today highlighted with gold ring</span>
            </span>
            <span className="text-brand-600 font-bold">
              Consistent practice compounds exponentially
            </span>
          </div>
        </div>
      </div>

      {/* Active Comeback Quests Section */}
      {activeComebackQuests.length > 0 && (
        <div className="bg-amber-50/50 dark:bg-amber-950/40 rounded-3xl p-6 sm:p-7 border border-amber-200 dark:border-amber-800 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-amber-500 text-white flex items-center justify-center font-bold text-xs">
                🌱
              </div>
              <div>
                <h3 className="text-base font-bold text-amber-950 dark:text-amber-100">Active Comeback Micro-Win Quests</h3>
                <p className="text-xs text-amber-800">Complete these 10-15m tasks to earn the "Comeback Hero" badge</p>
              </div>
            </div>
            {comebackPlan && (
              <button
                onClick={dismissComebackPlan}
                className="text-xs font-semibold text-amber-800 hover:text-amber-950 underline"
              >
                Dismiss Banner
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
            {activeComebackQuests.map((quest) => (
              <div
                key={quest.id}
                onClick={() => setSelectedQuest(quest)}
                className="bg-white p-5 rounded-2xl border border-amber-200 shadow-sm hover:border-amber-400 transition-all cursor-pointer flex flex-col justify-between space-y-3"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full bg-amber-100 text-amber-800">
                      Gentle Recovery
                    </span>
                    <span className="text-xs font-bold text-amber-700 flex items-center gap-1">
                      <Zap className="w-3.5 h-3.5 fill-amber-500" />
                      +{quest.xpReward} XP
                    </span>
                  </div>
                  <h4 className="text-sm font-bold text-slate-900 mb-1">{quest.title}</h4>
                  <p className="text-xs text-slate-600 line-clamp-2">{quest.description}</p>
                </div>

                <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                  <span className="flex items-center gap-1 text-slate-500">
                    <Clock className="w-3.5 h-3.5" />
                    {quest.durationMinutes} mins
                  </span>
                  <span className="text-amber-700 font-bold flex items-center gap-1">
                    <span>{quest.status === 'completed' ? 'Completed' : 'Start Micro-Win'}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Quest Modal */}
      <QuestModal
        quest={selectedQuest}
        isOpen={Boolean(selectedQuest)}
        onClose={() => setSelectedQuest(null)}
      />
    </div>
  );
};
