import React, { useState } from 'react';
import { useSkillQuest } from '../context/SkillQuestContext';
import { LEVEL_TIERS, getLevelInfo, XP_RULES } from '../utils/levels';
import { ProgressBar } from '../components/common/ProgressBar';
import {
  Trophy,
  Zap,
  Lock,
  CheckCircle2,
  Sparkles,
  Flame,
  Award,
  Shield,
  Layers,
  ChevronRight,
  Info
} from 'lucide-react';

export const AchievementsPage: React.FC = () => {
  const { user, achievements } = useSkillQuest();
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const levelInfo = getLevelInfo(user.currentXP);

  const categories = [
    { id: 'all', label: 'All Badges' },
    { id: 'quest', label: 'Quests' },
    { id: 'streak', label: 'Streaks' },
    { id: 'milestone', label: 'Milestones' },
    { id: 'consistency', label: 'Consistency' },
    { id: 'comeback', label: 'Comebacks' },
  ];

  const filteredAchievements = achievements.filter((ach) => {
    if (selectedCategory === 'all') return true;
    return ach.category === selectedCategory;
  });

  const earnedCount = achievements.filter(a => a.earned).length;

  return (
    <div className="space-y-8 animate-fadeIn text-left">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-bold uppercase tracking-wider text-purple-600 bg-purple-50 px-3 py-1 rounded-full border border-purple-200 flex items-center gap-1.5">
              <Trophy className="w-3.5 h-3.5 text-purple-600" />
              Gamification System
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-navy-950">
            Achievements & Progression
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 font-medium">
            SkillQuest rewards deliberate work and relentless consistency with deterministic XP and 10 progressive tiers.
          </p>
        </div>

        {/* Total Badge Counter */}
        <div className="px-4 py-2 bg-white rounded-2xl border border-slate-200 shadow-sm flex items-center gap-3">
          <Award className="w-5 h-5 text-amber-500" />
          <div>
            <div className="text-[10px] text-slate-600 uppercase font-bold">Badges Earned</div>
            <div className="text-xs font-extrabold text-slate-800">
              {earnedCount} of {achievements.length} Unlocked
            </div>
          </div>
        </div>
      </div>

      {/* Level Progression Banner Card */}
      <div className="bg-gradient-to-br from-navy-900 via-indigo-950 to-slate-900 rounded-3xl p-6 sm:p-8 text-white border border-slate-800 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-brand-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center relative z-10">
          <div className="md:col-span-4 flex items-center gap-4">
            <div className="w-20 h-20 rounded-3xl bg-gradient-to-tr from-brand-600 to-indigo-600 flex items-center justify-center text-4xl shadow-lg shadow-brand-500/30 flex-shrink-0">
              {levelInfo.badge}
            </div>
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-brand-300">
                Rank Level {levelInfo.level}
              </span>
              <h2 className="text-2xl font-black text-white">{levelInfo.title}</h2>
              <p className="text-xs text-slate-300 mt-0.5">{levelInfo.currentTier.description}</p>
            </div>
          </div>

          <div className="md:col-span-8 space-y-3 bg-white/5 p-5 rounded-2xl border border-white/10 backdrop-blur-sm">
            <div className="flex justify-between items-center text-xs">
              <span className="font-semibold text-slate-300">
                Tier Progress: <strong className="text-white">{levelInfo.xpInCurrentTier}</strong> / {levelInfo.xpNeededForTier} XP
              </span>
              <span className="font-bold text-amber-300">
                {levelInfo.isMaxLevel ? 'Apex Level Reached' : `${levelInfo.xpRemaining} XP to ${levelInfo.nextTier.title}`}
              </span>
            </div>

            <ProgressBar
              progress={levelInfo.progressPercent}
              colorClass="bg-gradient-to-r from-brand-500 to-indigo-400"
              heightClass="h-3"
            />

            <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1">
              <span>Total Lifetime XP: <strong className="text-brand-300">{user.currentXP} XP</strong></span>
              <span>Next Rank Unlock: {levelInfo.nextTier.badge} {levelInfo.nextTier.title} (Level {levelInfo.nextTier.level})</span>
            </div>
          </div>
        </div>
      </div>

      {/* 10-Tier Progression Roadmap Preview */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-slate-900">10-Tier Mastery Hierarchy</h3>
            <p className="text-xs text-slate-500">Every tier demands greater consistency and deeper domain fluency</p>
          </div>
          <span className="text-xs font-semibold text-slate-600 bg-slate-100 px-3 py-1 rounded-full">
            Tier {levelInfo.level} of 10
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 pt-2">
          {LEVEL_TIERS.map((tier) => {
            const isCurrent = tier.level === levelInfo.level;
            const isUnlocked = user.currentXP >= tier.minXP;

            return (
              <div
                key={tier.level}
                className={`p-3.5 rounded-2xl border transition-all text-center ${
                  isCurrent
                    ? 'border-brand-500 bg-brand-50/60 ring-2 ring-brand-500/20 shadow-sm'
                    : isUnlocked
                    ? 'border-emerald-200 bg-emerald-50/20'
                    : 'border-slate-100 bg-slate-50/60 opacity-60'
                }`}
              >
                <div className="text-2xl mb-1">{tier.badge}</div>
                <div className="text-[10px] font-bold text-slate-600 uppercase">Lv.{tier.level}</div>
                <div className="text-xs font-bold text-slate-900">{tier.title}</div>
                <div className="text-[10px] font-semibold text-slate-600 mt-1">
                  {tier.minXP} XP
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Achievement Badges Showcase */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-lg font-black text-navy-950">Badge Showcase</h3>
            <p className="text-xs text-slate-500">Earn badges by completing quests, sustaining streaks, and conquering milestones.</p>
          </div>

          {/* Category Filter */}
          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-2xl overflow-x-auto">
            {categories.map((c) => (
              <button
                key={c.id}
                onClick={() => setSelectedCategory(c.id)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
                  selectedCategory === c.id
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {c.label}
              </button>
            ))}
          </div>
        </div>

        {/* Badges Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {filteredAchievements.map((ach) => {
            return (
              <div
                key={ach.id}
                className={`p-5 rounded-3xl border transition-all relative flex flex-col justify-between ${
                  ach.earned
                    ? 'bg-white border-amber-200/90 shadow-sm shadow-amber-500/5 hover:border-amber-300'
                    : 'bg-slate-50/70 border-slate-200/80'
                }`}
              >
                <div>
                  <div className="flex items-start justify-between mb-3">
                    <div
                      className={`w-14 h-14 rounded-2xl flex items-center justify-center text-3xl shadow-sm ${
                        ach.earned
                          ? 'bg-gradient-to-tr from-amber-100 to-amber-50 border border-amber-200'
                          : 'bg-slate-200/60 grayscale opacity-40 border border-slate-300'
                      }`}
                    >
                      {ach.icon}
                    </div>

                    <span
                      className={`text-[10px] font-extrabold px-2.5 py-0.5 rounded-full flex items-center gap-1 ${
                        ach.earned
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                          : 'bg-slate-200 text-slate-600'
                      }`}
                    >
                      {ach.earned ? (
                        <>
                          <CheckCircle2 className="w-3 h-3" />
                          <span>Unlocked</span>
                        </>
                      ) : (
                        <>
                          <Lock className="w-3 h-3" />
                          <span>Locked</span>
                        </>
                      )}
                    </span>
                  </div>

                  <h4 className="text-sm font-bold text-slate-900 mb-1">
                    {ach.name}
                  </h4>
                  <p className="text-xs text-slate-500 line-clamp-2 mb-3 leading-relaxed">
                    {ach.description}
                  </p>
                </div>

                <div className="pt-3 border-t border-slate-100 space-y-1">
                  <div className="text-[11px] text-slate-500">
                    <strong>Criteria:</strong> {ach.criteria}
                  </div>
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="text-amber-700 font-bold flex items-center gap-1">
                      <Zap className="w-3 h-3 fill-amber-500 text-amber-500" />
                      +{ach.xpReward} XP Value
                    </span>
                    {ach.earned && ach.earnedAt && (
                      <span className="text-slate-400">
                        {new Date(ach.earnedAt).toLocaleDateString()}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Deterministic XP Table Explanation */}
      <div className="bg-slate-50 rounded-3xl p-6 border border-slate-200">
        <h4 className="text-xs font-bold uppercase tracking-wider text-slate-600 mb-3 flex items-center gap-1.5">
          <Info className="w-4 h-4 text-brand-600" />
          Deterministic XP Allocation Rules
        </h4>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          <div className="p-3 bg-white rounded-xl border border-slate-200">
            <span className="text-slate-500 block">Regular Quest:</span>
            <span className="text-sm font-extrabold text-brand-600">+{XP_RULES.QUEST_REGULAR} XP</span>
          </div>
          <div className="p-3 bg-white rounded-xl border border-slate-200">
            <span className="text-slate-500 block">Difficult Quest:</span>
            <span className="text-sm font-extrabold text-brand-600">+{XP_RULES.QUEST_DIFFICULT} XP</span>
          </div>
          <div className="p-3 bg-white rounded-xl border border-slate-200">
            <span className="text-slate-500 block">Milestone Conquered:</span>
            <span className="text-sm font-extrabold text-emerald-600">+{XP_RULES.MILESTONE_COMPLETION} XP</span>
          </div>
          <div className="p-3 bg-white rounded-xl border border-slate-200">
            <span className="text-slate-500 block">Weekly Cohort Challenge:</span>
            <span className="text-sm font-extrabold text-purple-600">+{XP_RULES.WEEKLY_CHALLENGE} XP</span>
          </div>
        </div>
      </div>
    </div>
  );
};
