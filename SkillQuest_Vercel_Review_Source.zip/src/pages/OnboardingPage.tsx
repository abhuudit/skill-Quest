import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useSkillQuest } from '../context/SkillQuestContext';
import { generateLearningRoadmap } from '../services/geminiService';
import { localDate } from '../utils/dailyLearning';
import { ProficiencyLevel, TargetProficiency, Milestone, Quest, LearningResource } from '../types';
import {
  Compass,
  Clock,
  Calendar,
  Sparkles,
  ArrowRight,
  ArrowLeft,
  CheckCircle2,
  Check,
  Target,
  Zap,
  BookOpen,
  HelpCircle,
  Loader2
} from 'lucide-react';

const SUGGESTED_SKILLS = [
  'Modern Web Development',
  'Python & Machine Learning',
  'Data Analytics with SQL & Pandas',
  'UI/UX Design with Figma',
  'Mobile App Dev with React Native',
  'Cybersecurity & Network Defense',
  'Cloud Architecture & DevOps',
];
const WEEKDAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
const TIME_OPTIONS = [10, 15, 20, 30, 45, 60, 90, 120];
const DEADLINE_OPTIONS = ['1 week', '2 weeks', '1 month', '2 months', '3 months', '6 months', '12 months'];
const futureDate = (deadline: string) => { const date = new Date(); const count = parseInt(deadline, 10); if (deadline.includes('week')) date.setDate(date.getDate() + count * 7); else date.setMonth(date.getMonth() + count); return localDate(undefined, date); };
const minutesFor = (time: string, custom: number, unit: 'minutes' | 'hours') => time === 'Custom' || time === 'More than 2 hours per day' ? custom * (unit === 'hours' ? 60 : 1) : time === '2 hours per day' ? 120 : parseInt(time, 10) || 30;
const questDates = (count: number, days: string[]) => { const dates: string[] = []; const d = new Date(); while (dates.length < count) { if (days.includes(WEEKDAYS[(d.getDay() + 6) % 7])) dates.push(localDate(undefined, d)); d.setDate(d.getDate() + 1); } return dates; };

export const OnboardingPage: React.FC = () => {
  const navigate = useNavigate();
  const { user, setNewLearningRoadmap } = useSkillQuest();

  const [step, setStep] = useState(1);
  const totalSteps = 4;

  // Form State
  const [skill, setSkill] = useState('');
  const [currentLevel, setCurrentLevel] = useState<ProficiencyLevel>('Beginner');
  const [targetLevel, setTargetLevel] = useState<TargetProficiency>('Intermediate');
  const [availableTime, setAvailableTime] = useState('30 minutes per day');
  const [customMinutes, setCustomMinutes] = useState(30);
  const [customUnit, setCustomUnit] = useState<'minutes' | 'hours'>('minutes');
  const [daysPerWeek, setDaysPerWeek] = useState(7);
  const [customSchedule, setCustomSchedule] = useState(false);
  const [availableDays, setAvailableDays] = useState<string[]>(WEEKDAYS);
  const [deadline, setDeadline] = useState('3 months');
  const [targetDate, setTargetDate] = useState(futureDate('3 months'));
  const [motivation, setMotivation] = useState('');

  const [isGenerating, setIsGenerating] = useState(false);
  const [generationError, setGenerationError] = useState('');

  const handleNext = () => {
    if (step === 1 && !skill.trim()) { setGenerationError('Choose or enter a skill for the new goal.'); return; }
    if (step === 3 && ((availableTime === 'Custom' || availableTime === 'More than 2 hours per day') && (!Number.isFinite(customMinutes) || minutesFor(availableTime, customMinutes, customUnit) < (availableTime === 'Custom' ? 1 : 121)) || customSchedule && !availableDays.length || deadline === 'Custom' && (!targetDate || targetDate <= new Date().toISOString().slice(0, 10)))) { setGenerationError('Choose a valid daily duration, learning day, and future deadline.'); return; }
    setGenerationError('');
    if (step < totalSteps) {
      setStep(step + 1);
    }
  };

  const handleBack = () => {
    if (step > 1) {
      setStep(step - 1);
    }
  };

  const handleGenerateRoadmap = async () => {
    if (!skill.trim()) { setGenerationError('Choose or enter a skill for the new goal.'); return; }
    setIsGenerating(true);
    setGenerationError('');

    try {
      const generated = await generateLearningRoadmap({
        skill,
        currentLevel,
        targetLevel,
        availableTime: availableTime === 'Custom' || availableTime === 'More than 2 hours per day' ? `${minutesFor(availableTime, customMinutes, customUnit)} minutes per day` : availableTime,
        deadline: deadline === 'Custom' ? targetDate : deadline,
        targetDate: deadline === 'Custom' ? targetDate : futureDate(deadline),
        daysPerWeek: customSchedule ? availableDays.length : daysPerWeek,
        availableDays: customSchedule ? availableDays : WEEKDAYS.slice(0, daysPerWeek),
        schedulePreference: customSchedule ? availableDays.join(', ') : `${daysPerWeek} days per week`,
        motivation,
        apiKey: user.settings.geminiApiKey,
      });

      const goalId = `goal_${crypto.randomUUID()}`;
      const newGoal = {
        id: goalId,
        userId: user.id,
        skill,
        currentLevel,
        targetLevel,
        availableTime: availableTime === 'Custom' || availableTime === 'More than 2 hours per day' ? `${minutesFor(availableTime, customMinutes, customUnit)} minutes per day` : availableTime,
        deadline: deadline === 'Custom' ? targetDate : deadline,
        targetDate: deadline === 'Custom' ? targetDate : futureDate(deadline),
        daysPerWeek: customSchedule ? availableDays.length : daysPerWeek,
        availableDays: customSchedule ? availableDays : WEEKDAYS.slice(0, daysPerWeek),
        schedulePreference: customSchedule ? availableDays.join(', ') : `${daysPerWeek} days per week`,
        motivation,
        overallProgress: 0,
        isAiGenerated: generated.isRealAI,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      const milestones: Milestone[] = generated.milestones.map((m, idx) => ({
        ...m,
        id: `ms_${goalId}_${idx + 1}`,
        goalId,
      }));
      const plannedDays = customSchedule ? availableDays : WEEKDAYS.slice(0, daysPerWeek);
      const dates = questDates(generated.quests.length, plannedDays);

      const quests: Quest[] = generated.quests.map((q, idx) => {
        const milestoneSeq = (q as any).associatedMilestoneSequence || (idx === 0 ? 1 : Math.min(milestones.length, Math.floor(idx / 2) + 1));
        const matchedMs = milestones.find(m => m.sequence === milestoneSeq) || milestones[0];

        return {
          ...q,
          id: `qst_${goalId}_${idx + 1}`,
          bonusQuestions: q.bonusQuestions?.map(b => ({ ...b, questId: `qst_${goalId}_${idx + 1}` })),
          milestoneId: matchedMs ? matchedMs.id : milestones[0].id,
          status: 'todo' as const,
          isToday: dates[idx] === localDate(),
          scheduledDate: dates[idx],
          durationMinutes: Math.min(q.durationMinutes, minutesFor(availableTime, customMinutes, customUnit)),
        };
      });

      const resources: LearningResource[] = generated.resources.map((r, idx) => ({
        ...r,
        id: `res_${goalId}_${idx + 1}`,
        skill,
      }));

      setNewLearningRoadmap(newGoal, milestones, quests, resources, generated.topics, generated.midwayProject);
      navigate('/roadmap');
    } catch (err: any) {
      console.error('Roadmap generation failed', err);
      setGenerationError('Failed to generate roadmap. Please check your network or try again.');
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto py-6 sm:py-10 animate-fadeIn">
      {/* Progress Header */}
      <div className="mb-8 space-y-4 text-center">
        <span className="text-xs font-bold uppercase tracking-wider text-brand-600 bg-brand-50 px-3 py-1 rounded-full border border-brand-200">
          Personalized Curriculum Setup
        </span>
        <h1 className="text-3xl font-extrabold text-navy-950">
          Design Your Learning Quest
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 max-w-lg mx-auto">
          SkillQuest converts your learning ambition into structured daily practice. Set your goal, availability, and deadline to calibrate your roadmap.
        </p>

        {/* Steps Breadcrumb */}
        <div className="flex items-center justify-center gap-2 pt-2">
          {[1, 2, 3, 4].map((s) => (
            <div key={s} className="flex items-center gap-2">
              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                  s === step
                    ? 'bg-brand-600 text-white shadow-md shadow-brand-500/30'
                    : s < step
                    ? 'bg-emerald-500 text-white'
                    : 'bg-slate-200 text-slate-500'
                }`}
              >
                {s < step ? <Check className="w-4 h-4" /> : s}
              </div>
              {s < 4 && (
                <div
                  className={`w-8 sm:w-12 h-1 rounded-full ${
                    s < step ? 'bg-emerald-500' : 'bg-slate-200'
                  }`}
                />
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Main Wizard Card */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-xl p-6 sm:p-10 text-left space-y-8">
        {generationError && (
          <div className="p-4 bg-rose-50 border border-rose-200 rounded-xl text-xs font-semibold text-rose-700">
            {generationError}
          </div>
        )}

        {/* STEP 1: Skill & Motivations */}
        {step === 1 && (
          <div className="space-y-6 animate-fadeIn">
            <div>
              <label className="block text-sm font-bold text-slate-900 mb-1">
                1. What skill do you want to learn?
              </label>
              <p className="text-xs text-slate-500 mb-3">
                Type any skill or choose from one of the popular domains below:
              </p>
              <input
                type="text"
                value={skill}
                onChange={(e) => setSkill(e.target.value)}
                placeholder="e.g. Modern Web Development, Python & Machine Learning, Data Analytics..."
                className="w-full px-4 py-3 text-sm rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-brand-500 font-semibold text-slate-900"
              />
              <div className="flex flex-wrap gap-2 mt-3">
                {SUGGESTED_SKILLS.map((item) => (
                  <button
                    key={item}
                    type="button"
                    onClick={() => setSkill(item)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                      skill === item
                        ? 'bg-brand-600 text-white shadow-sm'
                        : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                    }`}
                  >
                    {item}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-bold text-slate-900 mb-1">
                Why do you want to learn this skill?
              </label>
              <p className="text-xs text-slate-500 mb-2">
                Your 'Why' powers your consistency when motivation wanes:
              </p>
              <textarea
                value={motivation}
                onChange={(e) => setMotivation(e.target.value)}
                rows={3}
                placeholder="e.g. I want to build my own apps, land a junior developer role, or automate tedious daily workflows..."
                className="w-full px-4 py-2.5 text-sm rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-brand-500 text-slate-800"
              />
            </div>
          </div>
        )}

        {/* STEP 2: Proficiency Calibration */}
        {step === 2 && (
          <div className="space-y-6 animate-fadeIn">
            <div>
              <label className="block text-sm font-bold text-slate-900 mb-2">
                2. What is your current proficiency level?
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {(['Beginner', 'Intermediate', 'Advanced'] as ProficiencyLevel[]).map((level) => (
                  <button
                    key={level}
                    type="button"
                    onClick={() => setCurrentLevel(level)}
                    className={`p-4 rounded-2xl border text-left transition-all ${
                      currentLevel === level
                        ? 'border-brand-600 bg-brand-50/50 ring-2 ring-brand-500/20'
                        : 'border-slate-200 hover:border-slate-300 bg-white'
                    }`}
                  >
                    <div className="font-bold text-sm text-slate-900 mb-1">{level}</div>
                    <div className="text-xs text-slate-500">
                      {level === 'Beginner' && 'Little to no previous experience with this skill.'}
                      {level === 'Intermediate' && 'Understands basic syntax and core concepts.'}
                      {level === 'Advanced' && 'Has built projects; seeking architectural depth.'}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-bold text-slate-900 mb-2">
                3. What is your target proficiency?
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {(['Intermediate', 'Advanced', 'Mastery'] as TargetProficiency[]).map((level) => (
                  <button
                    key={level}
                    type="button"
                    onClick={() => setTargetLevel(level)}
                    className={`p-4 rounded-2xl border text-left transition-all ${
                      targetLevel === level
                        ? 'border-brand-600 bg-brand-50/50 ring-2 ring-brand-500/20'
                        : 'border-slate-200 hover:border-slate-300 bg-white'
                    }`}
                  >
                    <div className="font-bold text-sm text-slate-900 mb-1">{level}</div>
                    <div className="text-xs text-slate-500">
                      {level === 'Intermediate' && 'Comfortable building functional applications.'}
                      {level === 'Advanced' && 'Professional grade, production patterns.'}
                      {level === 'Mastery' && 'Instinctive fluency and deep architectural prowess.'}
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* STEP 3: Time & Schedule */}
        {step === 3 && (
          <div className="space-y-6 animate-fadeIn">
            <div>
              <label className="block text-sm font-bold text-slate-900 mb-2">
                4. How much time can you dedicate to learning per day?
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-3">
                {[...TIME_OPTIONS.map(n => n === 120 ? '2 hours per day' : `${n} minutes per day`), 'More than 2 hours per day', 'Custom'].map((t) => (
                  <button
                    key={t}
                    type="button"
                    onClick={() => { setAvailableTime(t); if (t === 'More than 2 hours per day' && minutesFor(t, customMinutes, customUnit) < 121) setCustomMinutes(customUnit === 'hours' ? 3 : 121); }}
                    className={`p-3 rounded-xl border text-center transition-all ${
                      availableTime === t
                        ? 'border-brand-600 bg-brand-50 text-brand-700 font-bold'
                        : 'border-slate-200 text-slate-700 hover:bg-slate-50 text-xs font-semibold'
                    }`}
                  >
                    {t}
                  </button>
                ))}
              </div>
              {(availableTime === 'Custom' || availableTime === 'More than 2 hours per day') && <label className="block text-xs text-slate-600">Daily duration <input type="number" min={1} value={customMinutes} onChange={e => setCustomMinutes(Number(e.target.value))} className="ml-2 w-28 p-2 rounded-lg border border-slate-300" /><select aria-label="Duration unit" value={customUnit} onChange={e => setCustomUnit(e.target.value as 'minutes' | 'hours')} className="ml-2 p-2 rounded-lg border border-slate-300"><option value="minutes">minutes</option><option value="hours">hours</option></select></label>}
            </div>

            <div>
              <label className="block text-sm font-bold text-slate-900 mb-2">
                5. How many days per week can you dedicate to learning?
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {[1, 2, 3, 4, 5, 6, 7].map((s) => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => { setDaysPerWeek(s); setCustomSchedule(false); }}
                    className={`p-3.5 rounded-xl border text-left transition-all text-xs ${
                      !customSchedule && daysPerWeek === s
                        ? 'border-brand-600 bg-brand-50 font-bold text-brand-800'
                        : 'border-slate-200 text-slate-700 hover:bg-slate-50 font-medium'
                    }`}
                  >
                    {s} {s === 1 ? 'day' : 'days'} per week
                  </button>
                ))}
                <button type="button" onClick={() => setCustomSchedule(true)} className={`p-3.5 rounded-xl border text-xs ${customSchedule ? 'border-brand-600 bg-brand-50 text-brand-800' : 'border-slate-200 text-slate-700'}`}>Custom schedule</button>
              </div>
              {customSchedule && <div className="mt-3 flex flex-wrap gap-2">{WEEKDAYS.map(day => <label key={day} className="text-xs p-2 border rounded-lg bg-white"><input type="checkbox" checked={availableDays.includes(day)} onChange={() => setAvailableDays(prev => prev.includes(day) ? prev.filter(d => d !== day) : [...prev, day])} /> {day}</label>)}</div>}
              <p className="text-xs text-slate-500 mt-2">These days determine your planned quest schedule.</p>
            </div>

            <div>
              <label className="block text-sm font-bold text-slate-900 mb-1">
                6. When would you like to achieve your learning goal?
              </label>
              <div className="flex flex-wrap gap-3">
                {[...DEADLINE_OPTIONS, 'Custom'].map((d) => (
                  <button
                    key={d}
                    type="button"
                    onClick={() => setDeadline(d)}
                    className={`px-4 py-2 rounded-xl border text-xs font-bold transition-all ${
                      deadline === d
                        ? 'border-brand-600 bg-brand-600 text-white'
                        : 'border-slate-200 text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    {d === 'Custom' ? 'Choose a custom deadline' : `Within ${d}`}
                  </button>
                ))}
              </div>
              {deadline === 'Custom' && <input aria-label="Target completion date" type="date" min={new Date(Date.now() + 86400000).toISOString().slice(0, 10)} value={targetDate} onChange={e => setTargetDate(e.target.value)} className="mt-3 p-2 rounded-xl border border-slate-300" />}
            </div>
          </div>
        )}

        {/* STEP 4: Review Summary & Confirmation */}
        {step === 4 && (
          <div className="space-y-6 animate-fadeIn">
            <div>
              <h3 className="text-base font-bold text-slate-900 mb-1">
                Review Your Learning Quest Profile
              </h3>
              <p className="text-xs text-slate-500">
                Confirm your settings before the AI constructs your ordered milestones and daily quests.
              </p>
            </div>

            <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-200">
                <span className="text-xs text-slate-500 font-semibold uppercase">Skill To Master</span>
                <span className="text-sm font-extrabold text-brand-600">{skill}</span>
              </div>

              <div className="grid grid-cols-2 gap-4 pb-3 border-b border-slate-200 text-xs">
                <div>
                  <span className="text-slate-500 block mb-0.5">Current Level:</span>
                  <span className="font-bold text-slate-800">{currentLevel}</span>
                </div>
                <div>
                  <span className="text-slate-500 block mb-0.5">Target Level:</span>
                  <span className="font-bold text-slate-800">{targetLevel}</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 pb-3 border-b border-slate-200 text-xs">
                <div>
                  <span className="text-slate-500 block mb-0.5">Daily Commitment:</span>
                  <span className="font-bold text-slate-800">{availableTime === 'Custom' || availableTime === 'More than 2 hours per day' ? `${customMinutes} ${customUnit} per day` : availableTime}</span>
                </div>
                <div>
                  <span className="text-slate-500 block mb-0.5">Estimated Duration:</span>
                  <span className="font-bold text-slate-800">{deadline === 'Custom' ? targetDate : deadline}</span>
                </div>
              </div>
              <p className="text-xs text-slate-600">Learning days: {customSchedule ? availableDays.join(', ') : `${daysPerWeek} days per week`}</p>

              <div className="text-xs">
                <span className="text-slate-500 block mb-0.5">Core Motivation:</span>
                <p className="font-medium text-slate-700 italic">"{motivation}"</p>
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-purple-50 border border-purple-200 text-purple-900 text-xs flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-purple-600" />
                <span className="font-medium">
                  {user.settings.geminiApiKey ? 'Live Gemini AI Engine Active' : 'Intelligent Curriculum Engine (Faculty Demo Ready)'}
                </span>
              </div>
              <span className="font-bold text-[11px] bg-purple-200/70 text-purple-800 px-2 py-0.5 rounded-md">
                Ready
              </span>
            </div>
          </div>
        )}

        {/* Wizard Footer Controls */}
        <div className="flex items-center justify-between pt-4 border-t border-slate-100">
          {step > 1 ? (
            <button
              type="button"
              onClick={handleBack}
              disabled={isGenerating}
              className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-slate-600 hover:text-slate-900 text-xs font-bold transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back</span>
            </button>
          ) : (
            <div />
          )}

          {step < totalSteps ? (
            <button
              type="button"
              onClick={handleNext}
              className="flex items-center gap-2 px-6 py-3 bg-brand-600 hover:bg-brand-700 text-white rounded-xl text-xs font-bold shadow-md shadow-brand-500/20 transition-all"
            >
              <span>Continue</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          ) : (
            <button
              type="button"
              onClick={handleGenerateRoadmap}
              disabled={isGenerating}
              className="flex items-center gap-2 px-8 py-3.5 bg-brand-600 hover:bg-brand-700 text-white rounded-xl text-sm font-extrabold shadow-lg shadow-brand-500/25 transition-all disabled:opacity-50"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Synthesizing Learning Roadmap...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Generate My Roadmap</span>
                </>
              )}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
