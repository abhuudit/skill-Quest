import React, { useState } from 'react';
import { useSkillQuest } from '../context/SkillQuestContext';
import { QuestModal } from '../components/common/QuestModal';
import { Quest } from '../types';
import { localDate } from '../utils/dailyLearning';

export const HomeworkPage: React.FC = () => {
  const { user, goal, quests } = useSkillQuest();
  const [selected, setSelected] = useState<Quest | null>(null);
  const today = localDate(user.settings.timeZone);
  const assignments = quests.filter(q => q.kind === 'assignment' && q.goalId === goal.id).sort((a,b) => (a.scheduledDate || '').localeCompare(b.scheduledDate || ''));
  const todayAssignments = assignments.filter(q => q.scheduledDate === today);
  const pending = assignments.filter(q => q.status !== 'completed');
  const completed = assignments.filter(q => q.status === 'completed');
  const recentXP = completed.filter(q => q.completedAt && Date.now() - new Date(q.completedAt).getTime() < 7 * 86400000).reduce((sum, q) => sum + q.xpReward, 0);
  return <div className="max-w-5xl mx-auto space-y-6 animate-fadeIn text-left">
    <div><p className="text-xs font-bold uppercase text-brand-600">Practical work</p><h1 className="text-3xl font-black text-navy-950">Daily Homework</h1><p className="text-sm text-slate-600">Apply the current milestone in a fresh exercise. Completion XP follows a cleared evaluation.</p></div>
    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-sm">{[['Today',todayAssignments.length],['Pending',pending.length],['Completed',completed.length],['Last 7 days XP',recentXP]].map(([label,value]) => <div key={label} className="bg-white border border-slate-200 rounded-2xl p-4"><div className="text-slate-500 text-xs">{label}</div><strong className="text-xl text-slate-900">{value}{label === 'Last 7 days XP' ? ' XP' : ''}</strong></div>)}</div>
    {!todayAssignments.length && <p className="p-4 bg-brand-50 text-brand-800 rounded-2xl text-sm">No homework is scheduled for today. Your daily quiz alone can satisfy today's streak requirement.</p>}
    <div className="space-y-3">{assignments.map(q => <article key={q.id} className="bg-white border border-slate-200 rounded-2xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3"><div><div className="text-xs text-slate-500">{q.scheduledDate} · {q.durationMinutes} min · {q.difficulty} · +{q.xpReward} assignment XP</div><h2 className="font-bold text-slate-900">{q.title}</h2><p className="text-sm text-slate-600">{q.learningObjective}</p><span className="text-xs font-semibold text-brand-600">{q.status === 'completed' ? 'Cleared' : q.latestEvaluation?.status === 'needs_improvement' ? 'Needs improvement' : q.latestEvaluation?.status === 'failed' ? 'Evaluation failed' : 'Pending submission'}</span></div><button onClick={() => setSelected(q)} className="px-4 py-2 bg-brand-600 text-white rounded-xl text-sm font-bold">{q.status === 'completed' ? 'Review' : 'Open assignment'}</button></article>)}</div>
    <QuestModal quest={selected} isOpen={Boolean(selected)} onClose={() => setSelected(null)} />
  </div>;
};
