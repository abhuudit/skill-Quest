import React, { useState } from 'react';
import { useSkillQuest } from '../context/SkillQuestContext';
import { QuestModal } from '../components/common/QuestModal';
import { Quest, QuestDifficulty } from '../types';
import {
  CheckSquare,
  Clock,
  Zap,
  CheckCircle2,
  Filter,
  Play,
  RotateCcw,
  Sparkles,
  ArrowRight,
  BookOpen,
  Search
} from 'lucide-react';

export const QuestsPage: React.FC = () => {
  const { quests: allQuests, milestones, resetQuest } = useSkillQuest();
  const quests = allQuests.filter(q => !q.kind);
  const [filter, setFilter] = useState<'all' | 'today' | 'upcoming' | 'completed'>('today');
  const [difficultyFilter, setDifficultyFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedQuest, setSelectedQuest] = useState<Quest | null>(null);

  // Filter logic
  const filteredQuests = quests.filter((q) => {
    // Tab filter
    if (filter === 'today' && (!q.isToday && q.status === 'completed')) return false;
    if (filter === 'today' && !q.isToday && q.status !== 'todo') return false;
    if (filter === 'upcoming' && (q.status === 'completed' || q.isToday)) return false;
    if (filter === 'completed' && q.status !== 'completed') return false;

    // Difficulty filter
    if (difficultyFilter !== 'all' && q.difficulty !== difficultyFilter) return false;

    // Search query
    if (searchQuery.trim()) {
      const qText = searchQuery.toLowerCase();
      return q.title.toLowerCase().includes(qText) || q.description.toLowerCase().includes(qText);
    }

    return true;
  });

  const completedCount = quests.filter(q => q.status === 'completed').length;

  return (
    <div className="space-y-8 animate-fadeIn text-left">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-bold uppercase tracking-wider text-brand-600 bg-brand-50 px-3 py-1 rounded-full border border-brand-200 flex items-center gap-1.5">
              <CheckSquare className="w-3.5 h-3.5 text-brand-600" />
              Deliberate Practice
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-navy-950">
            Daily Learning Quests
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 font-medium">
            Small, high-signal 10–25 minute micro-tasks designed to build muscle memory without cognitive burnout.
          </p>
        </div>

        {/* Progress Pill */}
        <div className="flex items-center gap-3">
          <div className="px-4 py-2 bg-white rounded-2xl border border-slate-200 shadow-sm flex items-center gap-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-600" />
            <div>
              <div className="text-[10px] text-slate-600 uppercase font-bold">Total Completed</div>
              <div className="text-xs font-extrabold text-slate-800">
                {completedCount} of {quests.length} Quests ({Math.round((completedCount / quests.length) * 100)}%)
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-3xl p-4 sm:p-5 border border-slate-200 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          {/* Main Status Tabs */}
          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-2xl overflow-x-auto min-w-0 max-w-full">
            {(['today', 'all', 'upcoming', 'completed'] as const).map((tab) => (
              <button
                key={tab}
                onClick={() => setFilter(tab)}
                className={`px-4 py-2 text-xs font-bold rounded-xl transition-all capitalize whitespace-nowrap ${
                  filter === tab
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {tab === 'today' ? "Today's Quests" : tab}
              </button>
            ))}
          </div>

          {/* Search Box */}
          <div className="relative w-full sm:w-60 sm:flex-shrink-0 min-w-0">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search quests..."
              className="w-full pl-9 pr-3.5 py-2 text-xs rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-brand-500 text-slate-800"
            />
          </div>
        </div>

        {/* Sub-Filter: Difficulty */}
        <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-100 text-xs">
          <span className="font-bold text-slate-600 flex items-center gap-1">
            <Filter className="w-3.5 h-3.5" />
            Difficulty:
          </span>
          {['all', 'Beginner', 'Intermediate', 'Advanced'].map((diff) => (
            <button
              key={diff}
              onClick={() => setDifficultyFilter(diff)}
              className={`px-3 py-1 rounded-lg font-semibold transition-colors ${
                difficultyFilter === diff
                  ? 'bg-brand-600 text-white'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {diff === 'all' ? 'All Difficulties' : diff}
            </button>
          ))}
        </div>
      </div>

      {/* Quests Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredQuests.map((quest) => {
          const milestone = milestones.find(m => m.id === quest.milestoneId);
          const isDone = quest.status === 'completed';

          return (
            <div
              key={quest.id}
              className={`bg-white rounded-3xl p-5 border transition-all flex flex-col justify-between quest-card-hover ${
                quest.isComebackQuest
                  ? 'border-amber-300 ring-2 ring-amber-400/20 bg-amber-50/20'
                  : isDone
                  ? 'border-emerald-200/90 bg-emerald-50/20'
                  : quest.isToday
                  ? 'border-brand-300 ring-2 ring-brand-500/20 shadow-md'
                  : 'border-slate-200 shadow-sm'
              }`}
            >
              <div>
                {/* Card Header Chips */}
                <div className="flex items-center justify-between gap-2 mb-3">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    {quest.isToday && !isDone && (
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-brand-50 text-brand-700 border border-brand-200">
                        Today's Quest
                      </span>
                    )}
                    {quest.isComebackQuest && (
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-amber-100 text-amber-800 border border-amber-300">
                        Comeback Micro-Win
                      </span>
                    )}
                    <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                      quest.difficulty === 'Beginner' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' :
                      quest.difficulty === 'Intermediate' ? 'bg-blue-50 text-blue-700 border border-blue-200' :
                      'bg-purple-50 text-purple-700 border border-purple-200'
                    }`}>
                      {quest.difficulty}
                    </span>
                  </div>

                  <span className="flex items-center gap-1 text-xs font-black text-brand-600 bg-brand-50 px-2.5 py-0.5 rounded-full border border-brand-200">
                    <Zap className="w-3.5 h-3.5 fill-brand-600" />
                    +{quest.xpReward} XP
                  </span>
                </div>

                <div className="text-[11px] font-semibold text-slate-600 mb-1 line-clamp-1">
                  {milestone ? milestone.title : 'Active Milestone'}
                </div>

                <h3 className="text-base font-bold text-slate-900 mb-2 leading-snug">
                  {quest.title}
                </h3>

                <p className="text-xs text-slate-600 line-clamp-3 mb-4 leading-relaxed">
                  {quest.description}
                </p>

                {quest.reflection && (
                  <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200/80 text-[11px] text-slate-600 italic mb-4">
                    "{quest.reflection}"
                  </div>
                )}
              </div>

              {/* Card Footer Controls */}
              <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
                <span className="flex items-center gap-1 text-xs text-slate-500 font-medium">
                  <Clock className="w-3.5 h-3.5 text-slate-400" />
                  {quest.durationMinutes} mins
                </span>

                <div className="flex items-center gap-2">
                  {isDone && (
                    <button
                      onClick={() => resetQuest(quest.id)}
                      title="Reset quest to todo for testing"
                      className="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                    </button>
                  )}

                  <button
                    onClick={() => setSelectedQuest(quest)}
                    className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
                      isDone
                        ? 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-200'
                        : 'bg-brand-600 hover:bg-brand-700 text-white shadow-sm shadow-brand-500/20'
                    }`}
                  >
                    {isDone ? (
                      <>
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Completed</span>
                      </>
                    ) : (
                      <>
                        <Play className="w-3.5 h-3.5 fill-white" />
                        <span>Start Quest</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {filteredQuests.length === 0 && (
        <div className="text-center py-16 bg-white rounded-3xl border border-slate-200 p-8 space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
            <CheckSquare className="w-6 h-6" />
          </div>
          <h3 className="text-base font-bold text-slate-800">No quests match your filter</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Try switching to 'All Quests' or clearing your search term to see the complete curriculum.
          </p>
        </div>
      )}

      {/* Quest Modal */}
      <QuestModal
        quest={selectedQuest}
        isOpen={Boolean(selectedQuest)}
        onClose={() => setSelectedQuest(null)}
      />
    </div>
  );
};
