import React from 'react';
import { Link } from 'react-router-dom';
import {
  Compass,
  Flame,
  Zap,
  Target,
  Trophy,
  BookOpen,
  Users,
  BarChart3,
  CheckCircle2,
  ArrowRight,
  Sparkles,
  Shield,
  Clock,
  Layers,
  ChevronRight,
  TrendingUp,
  Award
} from 'lucide-react';
import { ProgressBar } from '../components/common/ProgressBar';

export const HomePage: React.FC = () => {
  return (
    <div className="space-y-14 sm:space-y-20 py-3 sm:py-6 min-w-0">
      {/* Hero Section */}
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-navy-900 via-navy-950 to-slate-900 text-white p-5 sm:p-9 lg:p-12 shadow-2xl border border-slate-800">
        <div className="absolute -top-24 -right-24 w-96 h-96 bg-brand-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -left-24 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-7 lg:gap-10 items-center relative z-10 min-w-0">
          <div className="lg:col-span-7 space-y-5 text-left min-w-0">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-brand-500/10 border border-brand-400/20 text-brand-300 text-xs font-semibold backdrop-blur-md">
              <Sparkles className="w-4 h-4 text-brand-400" />
              <span>AI-Assisted Gamified Skill Mastery</span>
            </div>

            <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black tracking-tight leading-[1.1] text-white break-words">
              Stop Starting. <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-400 via-indigo-300 to-purple-400">
                Start Mastering.
              </span>
            </h1>

            <p className="text-base sm:text-lg text-slate-300 max-w-xl leading-relaxed">
              Turn your learning goals into daily quests. Let AI build your personalized roadmap, track your progress, and help you maintain relentless consistency.
            </p>

            <div className="flex flex-wrap gap-4 pt-2">
              <Link
                to="/onboarding"
                className="flex items-center gap-2 px-7 py-3.5 rounded-xl bg-brand-600 hover:bg-brand-500 text-white font-bold text-sm shadow-lg shadow-brand-600/30 transition-all hover:scale-[1.02] active:scale-[0.98]"
              >
                <span>Start Your Quest</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
              <a
                href="#how-it-works"
                className="flex items-center gap-2 px-7 py-3.5 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 text-slate-200 font-semibold text-sm border border-slate-700 transition-all hover:border-slate-600"
              >
                <span>Explore How It Works</span>
              </a>
              <Link
                to="/dashboard"
                className="flex items-center gap-2 px-5 py-3.5 rounded-xl text-slate-400 hover:text-white font-medium text-sm transition-colors"
              >
                <span>Open Learner Demo</span>
                <ChevronRight className="w-4 h-4" />
              </Link>
            </div>

            <div className="pt-4 flex flex-wrap items-center gap-3 sm:gap-6 text-xs text-slate-400">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Rewards actual work, not app time</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Empathetic, zero-guilt comeback system</span>
              </div>
            </div>
          </div>

          {/* Product Illustration / Dashboard Preview */}
          <div className="lg:col-span-5 min-w-0">
            <div className="relative mx-auto max-w-md rounded-2xl bg-slate-900/90 border border-slate-700/80 p-5 shadow-2xl backdrop-blur-xl">
              {/* Top Bar Preview */}
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3 mb-4">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-rose-500" />
                  <div className="w-3 h-3 rounded-full bg-amber-500" />
                  <div className="w-3 h-3 rounded-full bg-emerald-500" />
                  <span className="text-xs font-semibold text-slate-400 ml-2">SkillQuest Live Terminal</span>
                </div>
                <div className="flex items-center gap-2 text-xs font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-md border border-amber-500/20">
                  <Flame className="w-3 h-3 fill-amber-400" />
                  <span>4 Day Streak</span>
                </div>
              </div>

              {/* Goal Card Preview */}
              <div className="p-3.5 rounded-xl bg-slate-800/60 border border-slate-700/60 mb-3 text-left">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-brand-400">Target Skill</span>
                    <h4 className="text-sm font-bold text-white">Modern Web Development</h4>
                  </div>
                  <span className="text-xs font-extrabold text-emerald-400">44% Complete</span>
                </div>
                <div className="w-full bg-slate-700 h-2 rounded-full overflow-hidden">
                  <div className="bg-brand-500 h-2 rounded-full w-[44%]" />
                </div>
                <div className="flex justify-between text-[11px] text-slate-400 mt-2">
                  <span>Milestone 2 of 5: Modern CSS & Flexbox</span>
                  <span>Target: 3 Months</span>
                </div>
              </div>

              {/* Today's Quest Preview */}
              <div className="p-3.5 rounded-xl bg-brand-950/40 border border-brand-500/30 text-left">
                <div className="flex items-center justify-between mb-1.5">
                  <span className="px-2 py-0.5 rounded text-[10px] font-extrabold bg-brand-500/20 text-brand-300 border border-brand-500/40">
                    TODAY'S QUEST
                  </span>
                  <span className="flex items-center gap-1 text-xs font-extrabold text-brand-300">
                    <Zap className="w-3 h-3 fill-brand-400 text-brand-400" />
                    +35 XP
                  </span>
                </div>
                <h5 className="text-xs font-bold text-slate-100 mb-1">
                  Build a Responsive Navbar with CSS Flexbox
                </h5>
                <p className="text-[11px] text-slate-400 line-clamp-2 mb-2">
                  Space-between alignment, logo branding, and responsive toggle links.
                </p>
                <div className="flex items-center justify-between text-[11px]">
                  <span className="flex items-center gap-1 text-slate-400">
                    <Clock className="w-3 h-3" />
                    25 mins
                  </span>
                  <span className="text-brand-300 font-bold hover:underline cursor-pointer flex items-center gap-1">
                    Start Quest <ArrowRight className="w-3 h-3" />
                  </span>
                </div>
              </div>

              {/* Gamification Pills Preview */}
              <div className="grid grid-cols-3 gap-2 mt-3 text-center">
                <div className="p-2 rounded-lg bg-slate-800/40 border border-slate-700/50">
                  <div className="text-[10px] text-slate-400 uppercase font-semibold">Total XP</div>
                  <div className="text-xs font-black text-white">380 XP</div>
                </div>
                <div className="p-2 rounded-lg bg-slate-800/40 border border-slate-700/50">
                  <div className="text-[10px] text-slate-400 uppercase font-semibold">Rank</div>
                  <div className="text-xs font-black text-white">Apprentice</div>
                </div>
                <div className="p-2 rounded-lg bg-slate-800/40 border border-slate-700/50">
                  <div className="text-[10px] text-slate-400 uppercase font-semibold">Badges</div>
                  <div className="text-xs font-black text-amber-300">5 Earned</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Problem Section */}
      <section className="text-center space-y-12">
        <div className="max-w-2xl mx-auto space-y-3">
          <span className="text-xs font-bold uppercase tracking-wider text-brand-600 bg-brand-50 px-3 py-1 rounded-full border border-brand-200">
            The Learning Dilemma
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-navy-950">
            Why do we start learning but never finish?
          </h2>
          <p className="text-slate-600 text-sm sm:text-base">
            Students and independent learners don't fail because of a lack of talent. They abandon skills due to structural hurdles.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-left">
          <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
            <div className="w-12 h-12 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center mb-4 border border-rose-100">
              <Compass className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-slate-900 mb-2">1. No Clear Roadmap</h3>
            <p className="text-sm text-slate-600 leading-relaxed">
              "You know what you want to learn, but not what to do next." Scattered blog posts, outdated tutorials, and video spirals create paralyzing decision fatigue.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
            <div className="w-12 h-12 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center mb-4 border border-amber-100">
              <Clock className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-slate-900 mb-2">2. Inconsistent Schedules</h3>
            <p className="text-sm text-slate-600 leading-relaxed">
              "Your available time changes every day." Rigid courses assume you have 2 hours every evening, and when life happens, falling behind leads to complete abandonment.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
            <div className="w-12 h-12 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center mb-4 border border-purple-100">
              <TrendingUp className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-slate-900 mb-2">3. Invisible Progress</h3>
            <p className="text-sm text-slate-600 leading-relaxed">
              "You work hard but cannot see how far you have come." Without tangible milestones and gamified rewards, learning feels like an endless marathon with no finish line.
            </p>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section id="how-it-works" className="space-y-12 bg-white rounded-3xl p-8 sm:p-12 border border-slate-200 shadow-sm">
        <div className="text-center max-w-2xl mx-auto space-y-3">
          <span className="text-xs font-bold uppercase tracking-wider text-brand-600 bg-brand-50 px-3 py-1 rounded-full border border-brand-200">
            Four Steps to Mastery
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-navy-950">
            How SkillQuest Works
          </h2>
          <p className="text-slate-600 text-sm sm:text-base">
            Turning the intention to learn into a plan, and the plan into an unbreakable habit.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 text-left">
          <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 relative group hover:border-brand-300 transition-colors">
            <span className="text-3xl font-black text-brand-200 block mb-2">01</span>
            <h3 className="text-base font-bold text-slate-900 mb-1.5 flex items-center gap-2">
              <Target className="w-4 h-4 text-brand-600" />
              Set Your Goal
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Define your target skill, current level, target proficiency, available daily time, and target completion deadline.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 relative group hover:border-brand-300 transition-colors">
            <span className="text-3xl font-black text-brand-200 block mb-2">02</span>
            <h3 className="text-base font-bold text-slate-900 mb-1.5 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-brand-600" />
              AI Builds Your Path
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              AI crafts an ordered learning roadmap with sequential milestones and curated high-signal resources.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 relative group hover:border-brand-300 transition-colors">
            <span className="text-3xl font-black text-brand-200 block mb-2">03</span>
            <h3 className="text-base font-bold text-slate-900 mb-1.5 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-brand-600" />
              Complete Daily Quests
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Tackle bite-sized 10–25 minute micro-tasks designed for deliberate practice and concrete outputs.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 relative group hover:border-brand-300 transition-colors">
            <span className="text-3xl font-black text-brand-200 block mb-2">04</span>
            <h3 className="text-base font-bold text-slate-900 mb-1.5 flex items-center gap-2">
              <Trophy className="w-4 h-4 text-brand-600" />
              Track Your Progress
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Earn XP, unlock achievement badges, maintain streaks, and watch your skill progression chart climb.
            </p>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="space-y-12">
        <div className="text-center max-w-2xl mx-auto space-y-3">
          <span className="text-xs font-bold uppercase tracking-wider text-brand-600 bg-brand-50 px-3 py-1 rounded-full border border-brand-200">
            Engineered for Discipline
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-navy-950">
            Everything You Need to Keep Learning
          </h2>
          <p className="text-slate-600 text-sm sm:text-base">
            SkillQuest combines modern cognitive science, supportive gamification, and intelligent planning.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 text-left">
          <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-2">
            <div className="w-10 h-10 rounded-xl bg-brand-50 text-brand-600 flex items-center justify-center border border-brand-100">
              <Compass className="w-5 h-5" />
            </div>
            <h4 className="text-sm font-bold text-slate-900">AI-Powered Roadmaps</h4>
            <p className="text-xs text-slate-600">Personalized learning trees generated by Gemini API tailored to your deadline and background.</p>
          </div>

          <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-2">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center border border-emerald-100">
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <h4 className="text-sm font-bold text-slate-900">Daily Learning Quests</h4>
            <p className="text-xs text-slate-600">Actionable, bite-sized tasks with step-by-step instructions so you never wonder what to learn next.</p>
          </div>

          <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-2">
            <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center border border-purple-100">
              <Zap className="w-5 h-5" />
            </div>
            <h4 className="text-sm font-bold text-slate-900">XP & Level Progression</h4>
            <p className="text-xs text-slate-600">Deterministic 10-tier rank system from Novice to Skill Champion that rewards real work, not mindless screen time.</p>
          </div>

          <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-2">
            <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center border border-amber-100">
              <Flame className="w-5 h-5" />
            </div>
            <h4 className="text-sm font-bold text-slate-900">Streak Tracking</h4>
            <p className="text-xs text-slate-600">Consistent day tracking with visual heatmaps to motivate sustained commitment without guilt.</p>
          </div>

          <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-2">
            <div className="w-10 h-10 rounded-xl bg-teal-50 text-teal-600 flex items-center justify-center border border-teal-100">
              <Shield className="w-5 h-5" />
            </div>
            <h4 className="text-sm font-bold text-slate-900">Smart Comeback Plans</h4>
            <p className="text-xs text-slate-600">Missed a few days? SkillQuest automatically adapts your schedule with gentle recovery quests so you never quit.</p>
          </div>

          <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-2">
            <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center border border-blue-100">
              <Users className="w-4 h-4" />
            </div>
            <h4 className="text-sm font-bold text-slate-900">Peer Accountability</h4>
            <p className="text-xs text-slate-600">Join skill-based cohorts, collaborate on weekly team challenges, and celebrate collective milestones.</p>
          </div>

          <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-2">
            <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center border border-indigo-100">
              <BookOpen className="w-5 h-5" />
            </div>
            <h4 className="text-sm font-bold text-slate-900">Curated Resources</h4>
            <p className="text-xs text-slate-600">Hand-picked documentation, Harvard CS50, MDN, and interactive tutorials mapped directly to each quest.</p>
          </div>

          <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-2">
            <div className="w-10 h-10 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center border border-rose-100">
              <BarChart3 className="w-5 h-5" />
            </div>
            <h4 className="text-sm font-bold text-slate-900">Progress Analytics</h4>
            <p className="text-xs text-slate-600">28-day activity calendars, weekly consistency charts, and milestone velocity tracking powered by Recharts.</p>
          </div>
        </div>
      </section>

      {/* Gamification Preview Section */}
      <section className="bg-gradient-to-r from-navy-900 to-indigo-950 rounded-3xl p-8 sm:p-12 text-white border border-slate-800 shadow-xl">
        <div className="max-w-4xl mx-auto space-y-8">
          <div className="text-center space-y-2">
            <span className="text-xs font-bold uppercase tracking-wider text-brand-300 bg-brand-500/20 px-3 py-1 rounded-full border border-brand-400/30">
              Gamification System
            </span>
            <h3 className="text-2xl sm:text-3xl font-black">Level Up As You Build Real Competence</h3>
            <p className="text-xs sm:text-sm text-slate-300">
              SkillQuest treats skill acquisition like an RPG character progression. Every exercise has clear XP value.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-center">
            <div className="p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-sm">
              <div className="text-2xl mb-1">⚔️</div>
              <div className="text-lg font-black text-white">Level 3</div>
              <div className="text-xs font-semibold text-brand-300">Apprentice</div>
              <div className="text-[11px] text-slate-400 mt-1">380 / 450 XP</div>
            </div>

            <div className="p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-sm">
              <div className="text-2xl mb-1">🔥</div>
              <div className="text-lg font-black text-white">4 Days</div>
              <div className="text-xs font-semibold text-amber-300">Active Streak</div>
              <div className="text-[11px] text-slate-400 mt-1">Personal Best: 9d</div>
            </div>

            <div className="p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-sm">
              <div className="text-2xl mb-1">🏆</div>
              <div className="text-lg font-black text-white">5 Badges</div>
              <div className="text-xs font-semibold text-purple-300">Achievements</div>
              <div className="text-[11px] text-slate-400 mt-1">8 Total in Series</div>
            </div>

            <div className="p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-sm">
              <div className="text-2xl mb-1">🏁</div>
              <div className="text-lg font-black text-white">44%</div>
              <div className="text-xs font-semibold text-emerald-300">Goal Completion</div>
              <div className="text-[11px] text-slate-400 mt-1">1 Milestone Conquered</div>
            </div>
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="text-center rounded-3xl bg-brand-600 text-white p-8 sm:p-14 shadow-2xl space-y-6 relative overflow-hidden">
        <div className="relative z-10 max-w-2xl mx-auto space-y-4">
          <h2 className="text-3xl sm:text-5xl font-black tracking-tight">
            Your next skill starts today.
          </h2>
          <p className="text-brand-100 text-sm sm:text-base leading-relaxed">
            Stop waiting for the "perfect weekend" to start. Define your target, break it into 15-minute daily quests, and let SkillQuest guide your discipline.
          </p>
          <div className="pt-2">
            <Link
              to="/onboarding"
              className="inline-flex items-center gap-2 px-8 py-4 rounded-xl bg-white text-brand-700 hover:bg-brand-50 font-extrabold text-sm shadow-xl hover:scale-105 active:scale-95 transition-all"
            >
              <span>Build My Learning Roadmap</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="pt-12 border-t border-slate-200 text-slate-500 text-xs text-left">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-brand-600 flex items-center justify-center text-white">
                <Sparkles className="w-4 h-4" />
              </div>
              <span className="text-sm font-bold text-slate-900">SkillQuest</span>
            </div>
            <p className="text-slate-500 leading-relaxed text-xs">
              AI-assisted gamified skill development platform designed for sustained learner consistency.
            </p>
          </div>

          <div>
            <h5 className="font-bold text-slate-900 text-xs mb-3 uppercase tracking-wider">Features</h5>
            <ul className="space-y-2">
              <li><Link to="/roadmap" className="hover:text-brand-600">AI Roadmap Generator</Link></li>
              <li><Link to="/quests" className="hover:text-brand-600">Daily Learning Quests</Link></li>
              <li><Link to="/streaks" className="hover:text-brand-600">Empathetic Comeback Plans</Link></li>
              <li><Link to="/achievements" className="hover:text-brand-600">XP & Badge Progression</Link></li>
            </ul>
          </div>

          <div>
            <h5 className="font-bold text-slate-900 text-xs mb-3 uppercase tracking-wider">Community</h5>
            <ul className="space-y-2">
              <li><Link to="/cohorts" className="hover:text-brand-600">Peer Cohorts</Link></li>
              <li><Link to="/resources" className="hover:text-brand-600">Curated Resource Library</Link></li>
              <li><Link to="/analytics" className="hover:text-brand-600">Progress Analytics</Link></li>
            </ul>
          </div>

          <div>
            <h5 className="font-bold text-slate-900 text-xs mb-3 uppercase tracking-wider">About SkillQuest</h5>
            <p className="text-slate-500 text-xs leading-relaxed mb-3">
              SkillQuest Minor Project. Designed and developed with React, TypeScript, Tailwind CSS, Recharts, and Google Gemini API.
            </p>
            <div className="flex items-center gap-3 text-slate-400">
              <span className="hover:underline cursor-pointer">Privacy Policy</span>
              <span>•</span>
              <span className="hover:underline cursor-pointer">Terms of Service</span>
            </div>
          </div>
        </div>

        <div className="pt-6 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between text-slate-400">
          <span>&copy; {new Date().getFullYear()} SkillQuest. All rights reserved.</span>
          <span>"Turning intention into a plan, and the plan into a habit."</span>
        </div>
      </footer>
    </div>
  );
};
