import { LearningGoal, Milestone, Quest, LearningResource, ComebackPlan, EvaluationResult, SubmissionType, Topic, NoteReview, PdfNoteReview, QuizQuestion } from '../types';
import { PUBLIC_REVIEW_MODE } from '../utils/reviewMode';

export interface GeneratedRoadmapPayload {
  isRealAI: boolean;
  modelUsed?: string;
  milestones: Omit<Milestone, 'id' | 'goalId'>[];
  quests: Omit<Quest, 'id' | 'milestoneId'>[];
  resources: Omit<LearningResource, 'id'>[];
  topics?: Topic[];
  midwayProject?: Partial<Quest>;
}

export interface RoadmapGenerationInput {
  skill: string;
  currentLevel: 'Beginner' | 'Intermediate' | 'Advanced';
  targetLevel: 'Intermediate' | 'Advanced' | 'Mastery';
  availableTime: string;
  daysPerWeek?: number;
  availableDays?: string[];
  targetDate?: string;
  deadline: string;
  schedulePreference: string;
  motivation: string;
  apiKey?: string;
}

export interface ComebackInput {
  skill: string;
  missedDays: number;
  currentMilestoneTitle: string;
  apiKey?: string;
}

/**
 * Validate Gemini API Key by pinging model endpoint
 */
export async function validateGeminiApiKey(_apiKey = ''): Promise<{ valid: boolean; error?: string; model?: string }> {
  if (PUBLIC_REVIEW_MODE) return { valid: false, error: 'AI is unavailable in this static review preview.' };
  try { const data = await (await fetch('/api/ai/status')).json(); return { valid: data.configured, model: data.model, error: data.configured ? undefined : 'Set GEMINI_API_KEY in the server .env file.' }; }
  catch { return { valid: false, error: 'Local AI server unavailable.' }; }
}

/**
 * Safely parse JSON from LLM output, stripping markdown fences if present
 */
function cleanJsonString(str: string): string {
  let cleaned = str.trim();
  if (cleaned.startsWith('```json')) {
    cleaned = cleaned.replace(/^```json\s*/, '').replace(/\s*```$/, '');
  } else if (cleaned.startsWith('```')) {
    cleaned = cleaned.replace(/^```\s*/, '').replace(/\s*```$/, '');
  }
  return cleaned;
}

/**
 * Service to generate personalized roadmaps via Gemini API
 * or via realistic expert-curated generator with distinct indicators.
 */
export async function generateLearningRoadmap(input: RoadmapGenerationInput): Promise<GeneratedRoadmapPayload> {
  if (PUBLIC_REVIEW_MODE) return applyRoadmapConstraints(generateDeterministicRoadmap(input), input);
  const apiKey = 'server-configured';

  if (apiKey && apiKey.trim().length > 10) {
    try {
      const liveResult = await fetchGeminiRoadmap(input, apiKey.trim());
      if (liveResult) {
        return applyRoadmapConstraints(liveResult, input);
      }
    } catch (err) {
      console.warn('Gemini API call failed, falling back to curated expert engine:', err);
    }
  }

  // Fallback to intelligent deterministic generator
  return applyRoadmapConstraints(generateDeterministicRoadmap(input), input);
}

function applyRoadmapConstraints(plan: GeneratedRoadmapPayload, input: RoadmapGenerationInput): GeneratedRoadmapPayload {
  const minutes = input.availableTime.includes('hour') ? (parseInt(input.availableTime, 10) || 2) * 60 : parseInt(input.availableTime, 10) || 30;
  const days = Math.max(1, Math.min(7, input.daysPerWeek || 7));
  const availableHours = Math.max(1, (Date.parse(input.targetDate || '') - Date.now()) / 86400000 / 7 * days * minutes / 60);
  const estimatedHours = plan.quests.reduce((sum, quest) => sum + quest.durationMinutes / 60, 0);
  const tooAmbitious = estimatedHours > availableHours;
  return {
    ...plan,
    milestones: plan.milestones.map((m, i) => i === 0 && tooAmbitious ? { ...m, description: `${m.description} Your selected schedule may be too short for the full plan; prioritize the core quests or choose a later deadline.` } : m),
    quests: plan.quests.map(q => ({ ...q, durationMinutes: Math.max(1, Math.min(q.durationMinutes, minutes)) })),
  };
}

/**
 * Call Gemini REST API directly with multi-model fallback
 */
async function fetchGeminiRoadmap(input: RoadmapGenerationInput, apiKey: string): Promise<GeneratedRoadmapPayload | null> {
  const prompt = `You are SkillQuest's Senior Curriculum Engineer and Learning Architect.
Create a structured, step-by-step learning roadmap for a learner with the following profile:
- Target Skill: ${input.skill}
- Current Proficiency: ${input.currentLevel}
- Target Proficiency: ${input.targetLevel}
- Available Daily Commitment: ${input.availableTime}
- Planned Learning Days: ${input.daysPerWeek || 7} per week (${input.availableDays?.join(', ') || 'any day'})
- Target Deadline: ${input.deadline}
- Target Date: ${input.targetDate || 'not specified'}
- Motivation: ${input.motivation || 'Professional mastery'}

Requirements:
1. Provide exactly 4 sequential milestones.
2. For each milestone, provide 2 to 3 micro-quests whose duration fits the daily commitment, with clear step-by-step instructions. Schedule work only on planned learning days. If the target is too ambitious for the available hours and deadline, include a realistic pacing note in the first milestone description and prioritize a feasible core path.
3. For each milestone, curate 1-2 legitimate resources appropriate to the selected skill.
4. Include four optional learning topics: one each for core, additional, advanced, and project. Make every topic specific to ${input.skill} at ${input.currentLevel} level. Do not invent resource URLs.
5. Include a substantial midwayProject that applies the first half of the roadmap. It must specify title, description, projectObjectives, skillsAssessed, optionalEnhancements, instructions, submissionType, submissionRequirements, and at least three rubric criteria. It should be suitable for a learner portfolio only after successful evidence-based evaluation.
4. Strictly return valid JSON in this schema:
{
  "milestones": [
    {
      "sequence": 1,
      "title": "string",
      "description": "string",
      "status": "in-progress",
      "criteria": ["string", "string"],
      "estimatedWeeks": 2
    }
  ],
  "quests": [
    {
      "milestoneSequence": 1,
      "title": "string",
      "description": "string",
      "durationMinutes": 20,
      "difficulty": "Beginner",
      "xpReward": 20,
      "status": "todo",
      "isToday": true,
      "resourceTitle": "string",
      "resourceUrl": "string",
      "instructions": ["step 1", "step 2"],
      "submissionType": "video|image|document|text|code",
      "submissionRequirements": "specific evidence needed to prove the task",
      "rubric": [{"id":"r1","criterion":"specific observable requirement","description":"how the evidence proves it"}],
      "bonusQuestions": [{"questionText":"conceptual question","options":["answer A","answer B","answer C"],"correctAnswer":0,"explanation":"why","xpReward":10}]
    }
  ],
  "resources": [
    {
      "title": "string",
      "description": "string",
      "provider": "string",
      "url": "https://...",
      "resourceType": "documentation",
      "difficulty": "Beginner",
      "duration": "20 min read",
      "skill": "${input.skill}",
      "saved": false,
      "completed": false
    }
  ],
  "topics": [{"name":"string","category":"core|additional|advanced|project","description":"string","difficulty":"Beginner|Intermediate|Advanced","estimatedDuration":"string","recommendedResources":[],"practicalExercise":"string"}],
  "midwayProject": {"title":"Midway Project — Put Your Skills Into Practice","description":"specific project problem","projectObjectives":["objective"],"skillsAssessed":["skill"],"optionalEnhancements":["enhancement"],"instructions":["step 1"],"submissionType":"video|image|document|text|code","submissionRequirements":"actual evidence","rubric":[{"id":"r1","criterion":"observable criterion","description":"evidence needed"}]}
}`;

  const candidateModels = ['server-configured'];

  for (const model of candidateModels) {
    try {
      const response = await fetch('/api/ai/generate', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ prompt: typeof prompt === 'undefined' ? 'Reply with JSON {ok:true}' : prompt }) });

      if (!response.ok) {
        continue;
      }

      const data = await response.json();
      const textContent = JSON.stringify(data);
      if (!textContent) continue;

      const cleaned = cleanJsonString(textContent);
      const parsed = JSON.parse(cleaned);

      return {
        isRealAI: true,
        modelUsed: model,
        milestones: parsed.milestones || [],
        midwayProject: parsed.midwayProject && typeof parsed.midwayProject.description === 'string' && Array.isArray(parsed.midwayProject.rubric) && parsed.midwayProject.rubric.length >= 3 ? parsed.midwayProject : undefined,
        topics: Array.isArray(parsed.topics) ? parsed.topics.filter((t: any) => t && typeof t.name === 'string' && ['core','additional','advanced','project'].includes(t.category)).map((t: any, i: number) => ({ id: `top_${Date.now()}_${i}`, skill: input.skill, name: t.name, category: t.category, description: String(t.description || ''), difficulty: ['Beginner','Intermediate','Advanced'].includes(t.difficulty) ? t.difficulty : input.currentLevel, estimatedDuration: String(t.estimatedDuration || '1 week'), recommendedResources: Array.isArray(t.recommendedResources) ? t.recommendedResources.filter((r: any) => typeof r?.url === 'string' && /^https:\/\//.test(r.url)) : [], practicalExercise: String(t.practicalExercise || `Complete a practical ${input.skill} exercise`), isAddedToRoadmap: false })) : generateTopicsForSkill(input.skill),
        quests: (parsed.quests || []).map((q: any) => ({
          title: q.title,
          description: q.description,
          durationMinutes: q.durationMinutes || 20,
          difficulty: q.difficulty || 'Intermediate',
          xpReward: q.xpReward || 25,
          status: 'todo',
          submissionType: ['video','image','document','text','code'].includes(q.submissionType) ? q.submissionType : 'text',
          submissionRequirements: typeof q.submissionRequirements === 'string' ? q.submissionRequirements : 'Submit evidence of the practical work.',
          rubric: Array.isArray(q.rubric) && q.rubric.length ? q.rubric.filter((r: any) => typeof r?.criterion === 'string').map((r: any, i: number) => ({ id: `r${i + 1}`, criterion: r.criterion, description: String(r.description || '') })) : [{ id: 'task', criterion: 'Practical task completed', description: 'The submitted evidence demonstrates the requested work.' }],
          bonusQuestions: Array.isArray(q.bonusQuestions) ? q.bonusQuestions.filter((b: any) => Array.isArray(b?.options) && Number.isInteger(b.correctAnswer) && b.correctAnswer >= 0 && b.correctAnswer < b.options.length).map((b: any, i: number) => ({ id: `bonus_${Date.now()}_${i}`, questId: '', questionText: String(b.questionText), options: b.options.map(String), correctAnswer: b.correctAnswer, explanation: String(b.explanation || ''), xpReward: 10 })) : [],
          submissions: [],
          isToday: Boolean(q.isToday),
          resourceTitle: q.resourceTitle,
          resourceUrl: q.resourceUrl,
          instructions: q.instructions || ['Read documentation', 'Apply concept in small code snippet', 'Review output'],
          associatedMilestoneSequence: q.milestoneSequence || 1,
        })),
        resources: parsed.resources || [],
      };
    } catch (err) {
      console.warn(`Error generating with model ${model}`, err);
    }
  }

  return null;
}

/**
 * High-fidelity deterministic roadmap generator for any skill
 */
function generateDeterministicRoadmap(input: RoadmapGenerationInput): GeneratedRoadmapPayload {
  const normalizedSkill = input.skill.toLowerCase().trim();
  if (/guitar|music|piano|sing|speaking|speech|writing|draw|paint|photograph|cook|dance/.test(normalizedSkill)) {
    const isGuitar = normalizedSkill.includes('guitar');
    const task = isGuitar ? 'Play the G, C, and D major chords in sequence' : `Create and perform a short ${input.skill} exercise`;
    const evidence: SubmissionType = /writing/.test(normalizedSkill) ? 'text' : /draw|paint|photograph|cook/.test(normalizedSkill) ? 'image' : 'video';
    return {
      isRealAI: false,
      milestones: [
        { sequence: 1, title: isGuitar ? 'Learn Basic Guitar Chords' : `${input.skill} Foundations`, description: `Practice the essential techniques of ${input.skill}.`, status: 'in-progress', criteria: [task], estimatedWeeks: 2 },
        { sequence: 2, title: `${input.skill} Practice`, description: 'Apply the fundamentals in a complete exercise.', status: 'locked', criteria: ['Complete a sustained practical performance'], estimatedWeeks: 2 },
      ],
      quests: [
        { title: task, description: isGuitar ? 'Practice G, C, and D major chords. Play each clearly and transition without stopping.' : `Practice a focused ${input.skill} exercise and demonstrate the result.`, durationMinutes: 25, difficulty: input.currentLevel, xpReward: 30, status: 'todo', isToday: true, instructions: isGuitar ? ['Practice each chord separately.', 'Play G, C, and D in sequence.', 'Record your performance and submit the video.'] : ['Review the essential technique.', 'Complete a short practical exercise.', 'Submit evidence of the result.'], submissionType: evidence, submissionRequirements: isGuitar ? 'Upload a video showing G, C, and D major chords and the complete progression.' : `Submit ${evidence} evidence demonstrating your ${input.skill} work.`, rubric: isGuitar ? [{ id: 'r1', criterion: 'G, C, and D chords are demonstrated', description: 'The video visibly and audibly shows each chord.' }, { id: 'r2', criterion: 'Progression is completed', description: 'The learner transitions through the chords without stopping.' }] : [{ id: 'r1', criterion: 'Practical work is shown', description: 'The evidence shows the requested exercise.' }, { id: 'r2', criterion: 'Core technique is demonstrated', description: 'The evidence shows skill appropriate to the learner level.' }], submissions: [], bonusQuestions: [] },
      ],
      resources: [], topics: generateTopicsForSkill(input.skill),
    };
  }

  if (normalizedSkill.includes('data') || normalizedSkill.includes('python')) {
    return {
      isRealAI: false,
      milestones: [
        {
          sequence: 1,
          title: 'Python Essentials & Data Types',
          description: 'Establish rock-solid programming basics, variables, list comprehensions, and functional methods.',
          status: 'in-progress',
          criteria: ['Write clean Pythonic functions with type hints', 'Manipulate nested JSON and CSV datasets natively'],
          estimatedWeeks: 2,
        },
        {
          sequence: 2,
          title: 'Pandas & NumPy Scientific Stack',
          description: 'Vectorized computing, exploratory data analysis, filtering dataframes, and missing-value imputation.',
          status: 'locked',
          criteria: ['Clean a real-world messy dataset with missing values', 'Aggregate multi-index grouping with agg and pivot_table'],
          estimatedWeeks: 3,
        },
        {
          sequence: 3,
          title: 'Data Visualization & Storytelling',
          description: 'Create publication-ready charts using Matplotlib, Seaborn, and interactive dashboards.',
          status: 'locked',
          criteria: ['Build 5 statistical chart types (histograms, box plots, heatmaps)', 'Design an executive summary dashboard'],
          estimatedWeeks: 2,
        },
        {
          sequence: 4,
          title: 'Statistical Inference & Machine Learning Foundations',
          description: 'Hypothesis testing, regression modeling with Scikit-Learn, and evaluation metrics.',
          status: 'locked',
          criteria: ['Train and evaluate a supervised regression model', 'Measure performance using RMSE and R-squared'],
          estimatedWeeks: 3,
        },
      ],
      quests: [
        {
          title: 'Python List Comprehensions & Data Extraction',
          description: 'Refactor standard for-loops into concise, readable list and dictionary comprehensions.',
          durationMinutes: 20,
          difficulty: 'Beginner',
          xpReward: 20,
          status: 'todo',
          submissionType: 'text', submissionRequirements: 'Submit your actual work and explain how it meets each task instruction.', rubric: [{ id: 'task', criterion: 'Practical task completed', description: 'All task instructions are demonstrated by the submitted evidence.' }], submissions: [],
          isToday: true,
          resourceTitle: 'Real Python: List Comprehensions Guide',
          resourceUrl: 'https://realpython.com/list-comprehension-python/',
          instructions: [
            'Filter a list of numbers for multiples of 3 and 5.',
            'Construct a dictionary mapping student names to percentage scores.',
            'Profile execution speed compared to traditional loops.'
          ],
        },
        {
          title: 'Read and Clean a Messy CSV with Pandas',
          description: 'Load a Kaggle open dataset, identify null values, and apply mean/median imputations.',
          durationMinutes: 25,
          difficulty: 'Intermediate',
          xpReward: 35,
          status: 'todo',
          submissionType: 'text', submissionRequirements: 'Submit your actual work and explain how it meets each task instruction.', rubric: [{ id: 'task', criterion: 'Practical task completed', description: 'All task instructions are demonstrated by the submitted evidence.' }], submissions: [],
          isToday: false,
          resourceTitle: 'Pandas Documentation: Working with Missing Data',
          resourceUrl: 'https://pandas.pydata.org/docs/user_guide/missing_data.html',
          instructions: [
            'Import pandas as pd and read sample CSV.',
            'Use df.isna().sum() to inspect null distributions.',
            'Apply fillna() and dropna() strategically.'
          ],
        },
        {
          title: 'Generate a Correlation Heatmap with Seaborn',
          description: 'Compute a Pearson correlation matrix and plot a customized color-mapped heatmap.',
          durationMinutes: 20,
          difficulty: 'Intermediate',
          xpReward: 25,
          status: 'todo',
          submissionType: 'text', submissionRequirements: 'Submit your actual work and explain how it meets each task instruction.', rubric: [{ id: 'task', criterion: 'Practical task completed', description: 'All task instructions are demonstrated by the submitted evidence.' }], submissions: [],
          isToday: false,
          resourceTitle: 'Seaborn Heatmap Documentation',
          resourceUrl: 'https://seaborn.pydata.org/generated/seaborn.heatmap.html',
          instructions: [
            'Compute df.corr() for numerical features.',
            'Configure sns.heatmap with annot=True and cmap="Blues".',
            'Save plot to high-res PNG.'
          ],
        },
      ],
      resources: [
        {
          title: 'Kaggle Python Micro-Course',
          description: 'Hands-on interactive notebooks covering Python programming for data science.',
          provider: 'Kaggle Learn',
          url: 'https://www.kaggle.com/learn/python',
          resourceType: 'course',
          difficulty: 'Beginner',
          duration: '5 hours',
          skill: input.skill,
          saved: true,
          completed: false,
        },
        {
          title: 'Python Data Science Handbook',
          description: 'Free open-access text by Jake VanderPlas covering NumPy, Pandas, and Scikit-Learn.',
          provider: 'O’Reilly / GitHub',
          url: 'https://jakevdp.github.io/PythonDataScienceHandbook/',
          resourceType: 'documentation',
          difficulty: 'Intermediate',
          duration: 'Comprehensive',
          skill: input.skill,
          saved: true,
          completed: false,
        },
      ],
    };
  }

  if (normalizedSkill.includes('ui') || normalizedSkill.includes('ux') || normalizedSkill.includes('design')) {
    return {
      isRealAI: false,
      milestones: [
        {
          sequence: 1,
          title: 'Design Principles & Visual Hierarchy',
          description: 'Understand contrast, typography scale, 8pt spacing grid, and color accessibility.',
          status: 'in-progress',
          criteria: ['Establish a cohesive typography and color token system', 'Audit an existing interface for WCAG AA compliance'],
          estimatedWeeks: 2,
        },
        {
          sequence: 2,
          title: 'Figma Mastery: Auto Layout & Design Systems',
          description: 'Harness responsive auto-layout frames, component properties, and variable tokens.',
          status: 'locked',
          criteria: ['Create a flexible button component with variants and hover states', 'Build a responsive card component using nested Auto Layout'],
          estimatedWeeks: 3,
        },
        {
          sequence: 3,
          title: 'User Research & Wireframing Flows',
          description: 'Conduct user interviews, synthesize empathy maps, and design low-fidelity wireframes.',
          status: 'locked',
          criteria: ['Map out a frictionless 3-step checkout or onboarding user journey', 'Assemble an interactive clickable prototype in Figma'],
          estimatedWeeks: 2,
        },
        {
          sequence: 4,
          title: 'Micro-Interactions & Usability Testing',
          description: 'Prototype subtle transitions, measure task success rate, and conduct usability tests.',
          status: 'locked',
          criteria: ['Test prototype with 3 target users and log friction points', 'Deliver design handoff specs for engineering teams'],
          estimatedWeeks: 2,
        },
      ],
      quests: [
        {
          title: 'Establish an 8-Point Spacing Scale in Figma',
          description: 'Configure standard spacing tokens (4px, 8px, 16px, 24px, 32px, 48px) and apply them to a layout.',
          durationMinutes: 15,
          difficulty: 'Beginner',
          xpReward: 20,
          status: 'todo',
          submissionType: 'text', submissionRequirements: 'Submit your actual work and explain how it meets each task instruction.', rubric: [{ id: 'task', criterion: 'Practical task completed', description: 'All task instructions are demonstrated by the submitted evidence.' }], submissions: [],
          isToday: true,
          resourceTitle: 'Refactoring UI: Spacing & Layout',
          resourceUrl: 'https://www.refactoringui.com/',
          instructions: [
            'Create global spacing variables in Figma.',
            'Audit an existing UI card and snap all paddings to the 8pt grid.',
            'Verify consistency across mobile and desktop mockups.'
          ],
        },
        {
          title: 'Build a Fully Variable Auto-Layout Button Set',
          description: 'Create Primary, Secondary, Ghost, and Destructive buttons with icon slots and loading states.',
          durationMinutes: 25,
          difficulty: 'Intermediate',
          xpReward: 35,
          status: 'todo',
          submissionType: 'text', submissionRequirements: 'Submit your actual work and explain how it meets each task instruction.', rubric: [{ id: 'task', criterion: 'Practical task completed', description: 'All task instructions are demonstrated by the submitted evidence.' }], submissions: [],
          isToday: false,
          resourceTitle: 'Figma Auto Layout Official Guide',
          resourceUrl: 'https://help.figma.com/hc/en-us/articles/360040451373-Explore-auto-layout-properties',
          instructions: [
            'Draw a frame, set Auto Layout (horizontal).',
            'Define padding: 12px vertical, 20px horizontal.',
            'Create component variants for Default, Hover, and Disabled.'
          ],
        },
      ],
      resources: [
        {
          title: 'Nielsen Norman Group UX Articles',
          description: 'Evidence-based user experience research guidelines and heuristic evaluations.',
          provider: 'NN/g',
          url: 'https://www.nngroup.com/articles/',
          resourceType: 'article',
          difficulty: 'Intermediate',
          duration: '15 min read',
          skill: input.skill,
          saved: true,
          completed: false,
        },
      ],
    };
  }

  // Universal Default / Software Development Roadmap
  return {
    isRealAI: false,
    milestones: [
      {
        sequence: 1,
        title: `Core Foundations of ${input.skill}`,
        description: `Establish core vocabulary, syntax, fundamental mental models, and environment setup for ${input.skill}.`,
        status: 'in-progress',
        criteria: [
          `Set up local development workflow and toolchains for ${input.skill}`,
          `Understand syntax, core data structures, and execution flow`,
          `Complete 3 hands-on practical micro-exercises`
        ],
        estimatedWeeks: 2,
      },
      {
        sequence: 2,
        title: `Intermediate Patterns & Practical Applications`,
        description: `Apply patterns, modular design, error handling, and component composition in ${input.skill}.`,
        status: 'locked',
        criteria: [
          `Break complex requirements into reusable modular functions/components`,
          `Handle edge cases, validations, and state transitions reliably`,
          `Build a functional real-world miniature prototype`
        ],
        estimatedWeeks: 3,
      },
      {
        sequence: 3,
        title: `Advanced Architecture & Optimization`,
        description: `Performance tuning, testing strategies, async data flow, and modern ecosystem tooling.`,
        status: 'locked',
        criteria: [
          `Implement automated testing and debugging procedures`,
          `Optimize performance and efficiency metrics`,
          `Integrate external libraries and data endpoints`
        ],
        estimatedWeeks: 3,
      },
      {
        sequence: 4,
        title: `Production Portfolio Capstone`,
        description: `Synthesize all concepts into a production-grade capstone project ready for your portfolio.`,
        status: 'locked',
        criteria: [
          `Complete end-to-end user experience with persistent storage`,
          `Write comprehensive project documentation and architectural notes`,
          `Deploy live to a cloud platform for peer feedback`
        ],
        estimatedWeeks: 2,
      },
    ],
    quests: [
      {
        title: `Environment & Foundational Architecture of ${input.skill}`,
        description: `Configure your development environment, verify toolchains, and build your initial "Hello World" scaffold.`,
        durationMinutes: 20,
        difficulty: 'Beginner',
        xpReward: 20,
        status: 'todo',
          submissionType: 'text', submissionRequirements: 'Submit your actual work and explain how it meets each task instruction.', rubric: [{ id: 'task', criterion: 'Practical task completed', description: 'All task instructions are demonstrated by the submitted evidence.' }], submissions: [],
        isToday: true,
        resourceTitle: `Getting Started with ${input.skill}`,
        resourceUrl: 'https://developer.mozilla.org/',
        instructions: [
          'Verify your IDE and runtime installations.',
          'Create a dedicated sandbox repository.',
          'Execute the starter template and inspect output.'
        ],
      },
      {
        title: `Core Syntax & Practical Execution Drill`,
        description: `Implement the three primary fundamental concepts of ${input.skill} in an interactive drill.`,
        durationMinutes: 25,
        difficulty: 'Intermediate',
        xpReward: 35,
        status: 'todo',
          submissionType: 'text', submissionRequirements: 'Submit your actual work and explain how it meets each task instruction.', rubric: [{ id: 'task', criterion: 'Practical task completed', description: 'All task instructions are demonstrated by the submitted evidence.' }], submissions: [],
        isToday: false,
        resourceTitle: `Documentation & Best Practices`,
        resourceUrl: 'https://devdocs.io/',
        instructions: [
          'Write a clean implementation testing key input transformations.',
          'Add meaningful error boundaries and assertions.',
          'Review code against modern style guidelines.'
        ],
      },
      {
        title: `Build a Mini Functional Prototype`,
        description: `Combine inputs, logic, and output display to create a working feature in under 30 minutes.`,
        durationMinutes: 30,
        difficulty: 'Intermediate',
        xpReward: 35,
        status: 'todo',
          submissionType: 'text', submissionRequirements: 'Submit your actual work and explain how it meets each task instruction.', rubric: [{ id: 'task', criterion: 'Practical task completed', description: 'All task instructions are demonstrated by the submitted evidence.' }], submissions: [],
        isToday: false,
        resourceTitle: `Code Patterns & Examples`,
        resourceUrl: 'https://github.com/',
        instructions: [
          'Wire up user inputs with internal state.',
          'Render real-time visual feedback.',
          'Test against edge cases and verify responsiveness.'
        ],
      },
    ],
    resources: [
      {
        title: `${input.skill} Official Documentation & Reference`,
        description: `Definitive documentation, API references, and official getting-started guides.`,
        provider: 'Official Documentation',
        url: 'https://devdocs.io/',
        resourceType: 'documentation',
        difficulty: 'Beginner',
        duration: 'Self-paced',
        skill: input.skill,
        saved: true,
        completed: false,
      },
      {
        title: `Interactive Coding Sandbox for ${input.skill}`,
        description: `Browser-based coding environment with zero setup friction.`,
        provider: 'StackBlitz / CodeSandbox',
        url: 'https://stackblitz.com/',
        resourceType: 'project',
        difficulty: 'Intermediate',
        duration: 'Hands-on',
        skill: input.skill,
        saved: false,
        completed: false,
      },
    ],
  };
}

/**
 * Generate a supportive Comeback Plan when a learner misses days
 */
export async function generateComebackPlan(input: ComebackInput): Promise<ComebackPlan> {
  const apiKey = PUBLIC_REVIEW_MODE ? '' : 'server-configured';

  if (apiKey && apiKey.trim().length > 10) {
    try {
      const prompt = `You are SkillQuest's Empathetic Learning Coach. A learner studying ${input.skill} (currently on milestone: "${input.currentMilestoneTitle}") has missed approximately ${input.missedDays} days of practice.
Return a gentle, encouraging comeback plan in JSON with:
{
  "message": "Empathetic, zero-guilt encouragement acknowledging life happens and celebrating their return",
  "suggestedSchedule": "Gentle pacing suggestion for the next 3 days",
  "dailyQuests": [
    {
      "title": "Low-friction 10-minute micro-win quest title",
      "description": "Short explanation focused on review or tiny drill",
      "durationMinutes": 10,
      "difficulty": "Beginner",
      "xpReward": 25,
      "instructions": ["Step 1", "Step 2"]
    },
    {
      "title": "15-minute reactivation exercise",
      "description": "Short micro-exercise",
      "durationMinutes": 15,
      "difficulty": "Beginner",
      "xpReward": 25,
      "instructions": ["Step 1", "Step 2"]
    }
  ]
}`;

      const resp = await fetch('/api/ai/generate', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ prompt: typeof prompt === 'undefined' ? 'Reply with JSON {ok:true}' : prompt }) });

      if (resp.ok) {
        const data = await resp.json();
        const text = JSON.stringify(data);
        if (text) {
          const parsed = JSON.parse(cleanJsonString(text));
          return {
            id: `comeback_${Date.now()}`,
            active: true,
            missedDays: input.missedDays,
            message: parsed.message || "Welcome back! What matters is that you're here today.",
            suggestedSchedule: parsed.suggestedSchedule || "15 minutes per day for the next 3 days.",
            dailyQuests: (parsed.dailyQuests || []).map((q: any, i: number) => ({
              id: `cb_${Date.now()}_${i + 1}`,
              milestoneId: 'ms_current',
              title: q.title,
              description: q.description,
              durationMinutes: q.durationMinutes || 10,
              difficulty: 'Beginner',
              xpReward: 25,
              status: 'todo',
          submissionType: 'text', submissionRequirements: 'Submit your actual work and explain how it meets each task instruction.', rubric: [{ id: 'task', criterion: 'Practical task completed', description: 'All task instructions are demonstrated by the submitted evidence.' }], submissions: [],
              isToday: i === 0,
              instructions: q.instructions || ['Review previous notes', 'Test a 5-line code snippet'],
              isComebackQuest: true,
            })),
            generatedAt: new Date().toISOString(),
          };
        }
      }
    } catch (e) {
      console.warn('Live Gemini comeback plan generation failed, using standard plan', e);
    }
  }

  // Standard supportive fallback plan
  const gentleQuests: Quest[] = [
    {
      id: `cb_${Date.now()}_1`,
      milestoneId: 'ms_current',
      title: 'Gentle 10-Minute Knowledge Refresh',
      description: `Welcome back! Take 10 relaxing minutes to review the last concept you worked on in ${input.currentMilestoneTitle}. No pressure, just getting your feet back in the water.`,
      durationMinutes: 10,
      difficulty: 'Beginner',
      xpReward: 25,
      status: 'todo',
          submissionType: 'text', submissionRequirements: 'Submit your actual work and explain how it meets each task instruction.', rubric: [{ id: 'task', criterion: 'Practical task completed', description: 'All task instructions are demonstrated by the submitted evidence.' }], submissions: [],
      isToday: true,
      instructions: [
        'Open your code or notes from your last session.',
        'Read through the logic for 5 minutes without writing new code.',
        'Write one sentence summary of what you accomplished last time.'
      ],
      isComebackQuest: true,
    },
    {
      id: `cb_${Date.now()}_2`,
      milestoneId: 'ms_current',
      title: 'Quick Micro-Win Coding Drill',
      description: 'Solve one tiny exercise to reactivate muscle memory and regain your momentum.',
      durationMinutes: 15,
      difficulty: 'Beginner',
      xpReward: 25,
      status: 'todo',
          submissionType: 'text', submissionRequirements: 'Submit your actual work and explain how it meets each task instruction.', rubric: [{ id: 'task', criterion: 'Practical task completed', description: 'All task instructions are demonstrated by the submitted evidence.' }], submissions: [],
      isToday: false,
      instructions: [
        'Pick one small function or component.',
        'Run it and verify it executes properly.',
        'Celebrate your return!'
      ],
      isComebackQuest: true,
    },
  ];

  return {
    id: `comeback_${Date.now()}`,
    active: true,
    missedDays: input.missedDays,
    message: "Every learner takes a break. What matters is that you're back today. We've simplified your schedule into two low-friction micro-quests so you can regain your rhythm without feeling overwhelmed.",
    suggestedSchedule: '15 minutes per day for the next 3 days, then ease back to normal.',
    dailyQuests: gentleQuests,
    generatedAt: new Date().toISOString(),
  };
}

export interface EvaluationInput {
  quest: Quest;
  submissionType: SubmissionType;
  content: string;
  fileName?: string;
  fileSize?: string;
  apiKey?: string;
}

/**
 * AI-powered Practical Quest Evaluation
 * Evaluates submitted student evidence (code, text, screenshot, document) against defined rubrics.
 */
export async function evaluateQuestSubmission(input: EvaluationInput): Promise<EvaluationResult> {
  if (PUBLIC_REVIEW_MODE) return { status: 'failed', score: 0, criteriaMet: [], criteriaNotMet: [], feedback: 'AI evaluation is unavailable in this static review preview.', suggestions: [], recommendedNextAction: 'Try evaluation in the locally hosted app. No completion XP was awarded.', evaluatedAt: new Date().toISOString() };
  try {
    const response = await fetch('/api/ai/evaluate', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ quest: { title: input.quest.title, description: input.quest.description, submissionRequirements: input.quest.submissionRequirements, rubric: input.quest.rubric }, content: input.content }), signal: AbortSignal.timeout(100000) });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || 'Evaluation unavailable.');
    return result;
  } catch (error) {
    return { status: 'failed', score: 0, criteriaMet: [], criteriaNotMet: [], feedback: error instanceof Error ? error.message : 'Evaluation unavailable.', suggestions: ['Retry when AI is available, or submit another supported evidence format.'], recommendedNextAction: 'Retry your saved submission. No completion XP was awarded.', evaluatedAt: new Date().toISOString() };
  }
}

export async function reviewLearningNotes(notes: string, context: string, skill: string): Promise<NoteReview> {
  if (PUBLIC_REVIEW_MODE) throw new Error('AI notes review is unavailable in this static review preview. Your draft remains saved.');
  const response = await fetch('/api/ai/notes', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ notes, context, skill }), signal: AbortSignal.timeout(100000) });
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || 'AI notes review is unavailable. Your draft remains saved.');
  if (!Array.isArray(result.issues) || typeof result.summary !== 'string') throw new Error('AI notes review returned an invalid result. Your draft remains saved.');
  return result as NoteReview;
}

export async function reviewPdfLearningNotes(content: string, context: string, skill: string): Promise<PdfNoteReview> {
  if (PUBLIC_REVIEW_MODE) throw new Error('PDF notes review is unavailable in this static review preview. Your file remains saved.');
  const response = await fetch('/api/ai/notes/pdf', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ content, context, skill }), signal: AbortSignal.timeout(100000) });
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || 'PDF notes review is unavailable. Your file remains saved.');
  if (!Array.isArray(result.pages) || !Array.isArray(result.issues) || typeof result.summary !== 'string') throw new Error('PDF notes review returned an invalid result. Your file remains saved.');
  return result as PdfNoteReview;
}

export async function generateDailyQuizQuestions(skill: string, level: string, milestones: Milestone[], quests: Quest[]): Promise<QuizQuestion[] | null> {
  if (PUBLIC_REVIEW_MODE) return null;
  const current = Math.max(1, ...milestones.filter(m => m.status !== 'locked').map(m => m.sequence));
  const covered = milestones.filter(m => m.sequence <= current);
  const practiced = quests.filter(q => !q.kind && covered.some(m => m.id === q.milestoneId)).slice(-8);
  const prompt = `Create exactly 10 distinct multiple-choice revision questions for a learner studying ${skill} at ${level} level. Use only the lessons and tasks below, including current and earlier milestones. Do not test unfamiliar advanced topics. Favor conceptual understanding over memorizing the plan. Return JSON {"questions":[{"questionText":"string","options":["A","B","C","D"],"correctAnswer":0,"explanation":"string","difficulty":"Beginner|Medium|Advanced"}]}. Context: ${JSON.stringify({ milestones: covered.map(m => ({ title:m.title, description:m.description, criteria:m.criteria })), quests: practiced.map(q => ({ title:q.title, description:q.description, instructions:q.instructions, bonusQuestions:q.bonusQuestions?.map(b => ({ question:b.questionText, explanation:b.explanation })) })) })}`;
  try {
    const response = await fetch('/api/ai/generate', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ prompt }), signal: AbortSignal.timeout(45000) });
    if (!response.ok) return null;
    const result = await response.json();
    if (!Array.isArray(result.questions) || result.questions.length !== 10) return null;
    if (!result.questions.every((q: any) => typeof q.questionText === 'string' && q.questionText.trim() && Array.isArray(q.options) && q.options.length === 4 && q.options.every((x: any) => typeof x === 'string' && x.trim()) && Number.isInteger(q.correctAnswer) && q.correctAnswer >= 0 && q.correctAnswer < 4 && typeof q.explanation === 'string')) return null;
    return result.questions.map((q: any, i: number) => ({ id: `ai_daily_${i}`, skill, milestoneSequence: current, questionText: q.questionText, options: q.options, correctAnswer: q.correctAnswer, explanation: q.explanation, difficulty: ['Beginner','Medium','Advanced'].includes(q.difficulty) ? q.difficulty : 'Beginner', xpReward: 5 }));
  } catch { return null; }
}

/**
 * Generate customizable topic catalog for any skill
 */
export function generateTopicsForSkill(skill: string): Topic[] {
  return [
    {
      id: `top_${Date.now()}_1`,
      skill,
      name: `${skill} Fundamentals`,
      category: 'core',
      description: `Build the essential knowledge and techniques needed for ${skill}.`,
      difficulty: 'Beginner',
      estimatedDuration: '1.5 weeks',
      recommendedResources: [
        { title: `${skill} learning resources`, url: 'https://www.youtube.com/results?search_query=' + encodeURIComponent(skill + ' fundamentals'), provider: 'Video search' }
      ],
      practicalExercise: `Demonstrate three foundational ${skill} techniques in a short practical exercise.`,
      isAddedToRoadmap: true,
    },
    {
      id: `top_${Date.now()}_2`,
      skill,
      name: `${skill} Practice Methods`,
      category: 'additional',
      description: `Explore effective ways to practice and measure progress in ${skill}.`,
      difficulty: 'Intermediate',
      estimatedDuration: '1 week',
      recommendedResources: [
        { title: `${skill} practice resources`, url: 'https://www.youtube.com/results?search_query=' + encodeURIComponent(skill + ' practice'), provider: 'Video search' }
      ],
      practicalExercise: `Complete a focused ${skill} practice session and document one improvement.`,
      isAddedToRoadmap: false,
    },
    {
      id: `top_${Date.now()}_3`,
      skill,
      name: `Advanced ${skill} Techniques`,
      category: 'advanced',
      description: `Apply more demanding techniques and combine earlier skills.`,
      difficulty: 'Advanced',
      estimatedDuration: '2 weeks',
      recommendedResources: [
        { title: `Advanced ${skill} resources`, url: 'https://www.youtube.com/results?search_query=' + encodeURIComponent('advanced ' + skill), provider: 'Video search' }
      ],
      practicalExercise: `Demonstrate an advanced ${skill} technique and explain your choices.`,
      isAddedToRoadmap: false,
    },
    {
      id: `top_${Date.now()}_4`,
      skill,
      name: `${skill} Capstone Project`,
      category: 'project',
      description: `Combine the techniques you learned in a complete practical project.`,
      difficulty: 'Intermediate',
      estimatedDuration: '2 weeks',
      recommendedResources: [
        { title: `${skill} project ideas`, url: 'https://www.youtube.com/results?search_query=' + encodeURIComponent(skill + ' project ideas'), provider: 'Video search' }
      ],
      practicalExercise: `Create, document, and present a finished ${skill} project.`,
      isAddedToRoadmap: false,
    }
  ];
}

