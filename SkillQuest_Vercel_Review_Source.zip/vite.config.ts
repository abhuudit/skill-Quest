import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';

// https://vitejs.dev/config/
import { aiMiddleware } from './server/ai.mjs';
import { chatMiddleware } from './server/chat.mjs';

export default defineConfig(({ mode }) => {
  const env = { ...loadEnv(mode, process.cwd(), ''), ...process.env };
  return {
  plugins: [react(), { name: 'skillquest-api', configureServer(server) { server.middlewares.use(aiMiddleware(env)); server.middlewares.use(chatMiddleware); }, configurePreviewServer(server) { server.middlewares.use(aiMiddleware(env)); server.middlewares.use(chatMiddleware); } }],
  server: {
    port: 3000,
    open: false,
    host: '127.0.0.1',
    fs: { deny: ['**/.skillquest-private/**'] }
  }
}; });
