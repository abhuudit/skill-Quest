# SkillQuest — AI-Assisted Gamified Skill Development Platform

> **"Turning the intention to learn into a plan, and the plan into a habit."**

SkillQuest is an AI-assisted, gamified platform built to help students and young adults independently master modern technical and professional skills with sustained discipline and consistency.

---

## 🎯 The Core Problem & Solution

Many learners start learning a new skill but abandon it because:
1. **No Clear Roadmap:** They know what they want to learn, but not what exact step to take next.
2. **Inconsistent Schedules:** Life happens, and rigid multi-hour courses cause learners to fall behind and give up.
3. **Invisible Progress:** Learners work hard but cannot visualize how far they have advanced.
4. **Guilt & Drop-off:** Missing a few days in traditional streak-tracking apps triggers guilt and demotivation.

**SkillQuest solves this** by converting a learner's ambition into an ordered, milestone-driven curriculum, breaking each milestone into achievable 10–25 minute daily quests, rewarding deliberate practice with deterministic XP, and providing an **empathetic comeback engine** when life causes interruptions.

---

## 🚀 Key Features Across the 11 Core Pages

1. **Home / Landing Page (`/`):**
   - High-impact SaaS visual identity with Deep Navy surfaces, subtle indigo accents, and emerald completion cues.
   - Hero section ("Stop Starting. Start Mastering."), interactive live dashboard illustration preview.
   - Problem comparison, 4-step workflow, 8 feature pillars, gamification preview, and comprehensive footer.

2. **Authentication Interface (`/login` & `/signup`):**
   - Clean credentials form with validation, password visibility toggle, and error states.
   - **1-Click Evaluator Demo Sign-In** allowing faculty and reviewers to instantly explore the pre-calibrated Level 3 learner profile (Alex Rivera).

3. **Onboarding & Goal Setup Wizard (`/onboarding`):**
   - 4-step wizard capturing: target skill, current level (Beginner/Intermediate/Advanced), target proficiency, daily commitment (15–60 min), schedule preference, deadline, and core motivation.
   - Summary confirmation card with "Generate My Roadmap" invoking Gemini AI or the Smart Curriculum Engine.

4. **Learner Dashboard (`/dashboard`):**
   - Personalized welcome banner and learner rank badge.
   - **Daily Quest Spotlight:** Centrally featured quest making the next action immediately obvious.
   - Learning Goal Card with progress bar, pace commitment, and target date.
   - 6-metric Gamification Overview (Level rank, Total XP, Current streak, Longest streak, Completed quests, Earned badges).
   - Recharts-powered 7-day weekly consistency chart and upcoming milestones preview.

5. **AI Learning Roadmap (`/roadmap`):**
   - Expandable milestone tree with sequence numbers, time estimates, and completion criteria.
   - Milestone progress indicators (Completed, Active In-Progress, Locked).
   - Embedded quests and 3–6 curated high-signal learning resources per milestone.
   - In-app "Edit Goal" modal and "Regenerate Roadmap" trigger.
   - Distinct badge indicator separating Live Gemini API from Demo Engine.

6. **Daily Quests (`/quests`):**
   - Dedicated learning tasks center with filters (Today's Quests, All, Upcoming, Completed, Difficulty).
   - Interactive Quest Modal featuring step-by-step instructions, curated resource links, and optional learner reflection notes.
   - Deterministic XP allocation, sound effects, celebration modal, and confetti animations.
   - Includes evaluator "Reset Quest" action for testing.

7. **Gamification & Achievements (`/achievements`):**
   - **Deterministic XP Allocation:** Regular Quest (+20 XP), Difficult Quest (+35 XP), Milestone (+100 XP), Weekly Challenge (+75 XP), Comeback Micro-Win (+25 XP).
   - **10-Tier Mastery Hierarchy:**
     - Level 1: Novice (0–99 XP)
     - Level 2: Explorer (100–249 XP)
     - Level 3: Apprentice (250–449 XP)
     - Level 4: Practitioner (450–699 XP)
     - Level 5: Builder (700–999 XP)
     - Level 6: Achiever (1000–1399 XP)
     - Level 7: Specialist (1400–1899 XP)
     - Level 8: Expert (1900–2499 XP)
     - Level 9: Master (2500–3299 XP)
     - Level 10: Skill Champion (3300+ XP)
   - Visual badge collection (First Quest, 3-Day Fire, Weekly Ironclad, Milestone Conqueror, Consistency Champion, Comeback Hero, etc.).

8. **Streaks & Empathetic Comeback System (`/streaks`):**
   - 28-day deliberate practice heatmap grid (GitHub/Duolingo style).
   - Non-punishing philosophy: streaks are preserved, XP is never deducted.
   - **AI Comeback Plan Generator:** When falling behind, provides low-friction 10–15 minute micro-quests to rebuild momentum without guilt.

9. **Curated Resource Library (`/resources`):**
   - High-signal public resources categorized by skill, difficulty, and type (Documentation, Interactive Courses, Articles, Practice Projects).
   - Legitimate references to MDN Web Docs, Harvard CS50, freeCodeCamp, Frontend Mentor, and JavaScript.info.
   - Bookmark/save and completion tracking.

10. **Peer Cohorts & Leaderboard (`/cohorts`):**
    - Skill-based cohorts (Web Development Pathfinders, Python Analysts, UI/UX Design, Competitive Programming) with weekly collective challenges.
    - **Opt-In Peer Leaderboard:** Participants ranked by verified XP. Learners can toggle Private Mode at any time for zero peer-pressure learning.

11. **Progress Analytics (`/analytics`):**
    - 14-day XP Trajectory Area Chart.
    - Weekly consistency bar chart.
    - Milestone velocity breakdown.
    - Personalized actionable insights derived strictly from verified user activity.

---

## 🛠️ Technology Stack

- **Frontend Framework:** React 18 with TypeScript
- **Build Tool:** Vite 6
- **Styling:** Tailwind CSS (Custom Navy SaaS theme with Emerald/Amber accents)
- **Icons:** Lucide React
- **Routing:** React Router v6
- **Data Visualizations:** Recharts
- **Celebration Effects:** Canvas-Confetti & Web Audio API Harmonic Sound Synthesizer
- **AI Integration:** Local Vite middleware using Gemini (`gemini-2.5-flash` by default); roadmap and daily quiz generation have clearly labeled local fallbacks
- **Persistence:** LocalStorage Engine with instant baseline demo restore

---

## ⚡ Quick Start & Local Execution

### Prerequisites
- Node.js (v18 or newer)
- npm or pnpm

### Installation & Run

```bash
# 1. Install dependencies
npm install

# 2. Start the local development server
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your web browser.

### Optional: Configure Live Gemini AI

1. Copy `.env.example` to `.env` in the project directory.
2. Set `GEMINI_API_KEY` in `.env` and restart `npm run dev`.
3. Open Settings to check whether the local AI server is configured. Practical quest evaluation requires the server key. Failed evaluations keep the attempt and award no quest XP.

Uploaded media is sent to Gemini for rubric evaluation when configured. SkillQuest does not keep uploaded media in browser storage; it saves attempt metadata and feedback locally. The app uses browser localStorage for progress and has no multi-user authentication or private server-side submission store.

### Cohort chat demo

Cohort chat messages are shared through the local Vite server and persist in `.skillquest-private/demo-chat.json` across page refreshes and server restarts. This path is blocked from direct Vite file access and ignored by Git. A demo session cookie and server-side cohort membership check gate chat reads and sends. The current sign-in is mock authentication, so these identities are **not verified** and this chat must not be deployed as a private production service. Replace demo sessions with real authentication and a database before public deployment.

Quest completion rewards are fixed by difficulty: Beginner 15 XP, Medium (including legacy Intermediate quests) 35 XP, and Advanced 70 XP. Bonus question XP remains separate. Theme preference is saved with the existing user settings and defaults to the operating system preference.

### Daily learning and portfolio

- `/homework` shows practical assignments derived from the current roadmap. Each assignment needs submitted evidence and a cleared rubric evaluation before assignment XP is awarded.
- `/quiz` saves a 10-question review for each user, goal, and local date. All 10 answers are required for daily completion; the score affects quiz XP, but a perfect score is not required for a streak. If Gemini is unavailable, the page labels its learning-plan question fallback.
- A daily streak credit is recorded once after the quiz and any assignment scheduled for that local day are complete. Existing historical streak values are kept during migration. The time zone can be set in Settings.
- `/projects` unlocks the midway project after the foundational roadmap milestones are complete. Only a cleared submission can produce a portfolio entry; the learner can edit and copy its CV summary.
- `/notes` saves drafts and links them to quests or resources. AI review is advisory, keeps the original note under learner control, and never changes XP or quest status. Without a Gemini key, the draft remains saved and review reports that it is unavailable.
- The Notes page also accepts handwritten PDF scans up to 6 MB. The browser keeps each PDF version in IndexedDB and saves review metadata with the note. Gemini receives the PDF only when the learner requests review, reads it page by page, and reports unreadable handwriting without awarding or removing XP. PDF preview requires a browser with built-in PDF viewing. The current app uses mock sign-in and browser-local storage, so this is local demo storage, not a secure multi-user document service.

Run `npm test` for the domain and AI-response smoke checks and `npm run build` for the production build.

### Share a static review preview on Vercel

The production build sets `VITE_PUBLIC_REVIEW=true` via `.env.production`. It uses local roadmap and quiz fallbacks, hides shared chat, and disables AI evaluation. Progress and notes stay in each visitor's browser. Sign-in and cohorts are demonstrations, and leaderboard entries are sample data. Do not ask reviewers to upload sensitive work or use a real password.

To publish with a Vercel account:

1. Create a new Vercel project from this source directory or a repository containing it. Use the Vite framework preset. The included `vercel.json` sets `npm run build`, `dist`, and the SPA route rewrite.
2. Deploy, then open the generated `*.vercel.app` URL. Check `/`, `/login`, `/dashboard`, and a direct refresh of `/cohorts` after entering the demo.
3. Share that URL with reviewers. Each person gets independent browser-local progress.

Do not put `GEMINI_API_KEY` in a `VITE_` variable or upload `.env` or `.skillquest-private`. A full public version with AI, real accounts, and shared chat needs a separately deployed API, authenticated users, and persistent server storage.

### Multiple learning goals

The dashboard's Learning Goal Switcher opens any active or completed goal and links to `/goals` for renaming, progress, completion, archiving, and resuming. The existing single goal and its roadmap migrate into the first saved workspace automatically. New goals created through onboarding keep independent milestones, quests, homework, resources, topics, and notes. Quiz records are keyed by user, goal, and local date. XP and streaks remain user-level; completing two goals on one date does not award a second streak day. Archived goals keep their progress and portfolio entries. The current sign-in is still a local demo identity, not verified multi-user authentication.
