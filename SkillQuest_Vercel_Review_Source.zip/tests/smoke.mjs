import assert from 'node:assert/strict';
import { Readable } from 'node:stream';
import { createRequire } from 'node:module';
import { build } from 'esbuild';
import React from 'react';
import { renderToString } from 'react-dom/server';
import { aiMiddleware, validateEvaluation, validateNotesReview, validatePdfNotesReview, evidenceParts, pdfNoteParts } from '../server/ai.mjs';

async function bundled(entry) {
  const result = await build({ entryPoints: [entry], bundle: true, platform: 'node', format: 'esm', write: false });
  return import(`data:text/javascript;base64,${Buffer.from(result.outputFiles[0].contents).toString('base64')}`);
}

const { INITIAL_GOAL, INITIAL_MILESTONES, INITIAL_QUESTS, INITIAL_QUIZ_QUESTIONS } = await bundled('./src/data/initialData.ts');
const { createAssignments, createMidwayProject, midwayUnlocked, fallbackDailyQuestions, localDate } = await bundled('./src/utils/dailyLearning.ts');
const { upsertGoalWorkspace } = await bundled('./src/utils/goalWorkspaces.ts');
const workspaceA = { goal: INITIAL_GOAL, milestones: INITIAL_MILESTONES, quests: INITIAL_QUESTS, resources: [], topics: [], comebackPlan: null };
const workspaceB = { goal: { ...INITIAL_GOAL, id: 'goal_b', skill: 'Guitar' }, milestones: [], quests: [], resources: [], topics: [], comebackPlan: null };
assert.equal(upsertGoalWorkspace([workspaceA], workspaceB).length, 2);
assert.equal(upsertGoalWorkspace([workspaceA], workspaceB)[0].goal.id, INITIAL_GOAL.id);
assert.equal(upsertGoalWorkspace([workspaceA, workspaceB], { ...workspaceB, goal: { ...workspaceB.goal, overallProgress: 50 } })[0].goal.id, INITIAL_GOAL.id);

const contextBundle = await build({ entryPoints: ['./src/context/SkillQuestContext.tsx'], bundle: true, platform: 'node', format: 'cjs', external: ['react', 'canvas-confetti'], write: false });
const contextModule = { exports: {} };
new Function('require', 'module', 'exports', contextBundle.outputFiles[0].text)(createRequire(import.meta.url), contextModule, contextModule.exports);
const { SkillQuestProvider, useSkillQuest } = contextModule.exports;
const storage = new Map();
globalThis.localStorage = { getItem: key => storage.get(key) || null, setItem: (key, value) => storage.set(key, value), removeItem: key => storage.delete(key), clear: () => storage.clear() };
storage.set('skillquest_daily_credits_v1', JSON.stringify(['2026-10-29']));
storage.set('skillquest_notes_v1', JSON.stringify([{ id: 'legacy_note', userId: INITIAL_GOAL.userId, skill: INITIAL_GOAL.skill, title: 'Old notes', topic: 'CSS', content: 'Flexbox', context: '', createdAt: '2026-10-29', updatedAt: '2026-10-29', revisions: [] }]));
let captured;
const Inspect = () => { captured = useSkillQuest(); return React.createElement('span', null, captured.goal.skill); };
renderToString(React.createElement(SkillQuestProvider, null, React.createElement(Inspect)));
assert.equal(captured.goals.length, 1);
assert.equal(captured.goal.id, INITIAL_GOAL.id);
assert.ok(captured.quests.some(q => q.kind === 'assignment'));
assert.ok(captured.dailyCredits.includes(`${INITIAL_GOAL.id}:2026-10-29`));
assert.equal(captured.notes[0].goalId, INITIAL_GOAL.id);
const secondGoal = { ...INITIAL_GOAL, id: 'goal_guitar_test', skill: 'Guitar', userId: captured.user.id, overallProgress: 12 };
storage.set('skillquest_goal_workspaces_v2', JSON.stringify([
  { goal: INITIAL_GOAL, milestones: INITIAL_MILESTONES, quests: INITIAL_QUESTS, resources: [{ id: 'web_resource', skill: INITIAL_GOAL.skill }], topics: [], comebackPlan: null },
  { goal: secondGoal, milestones: [{ ...INITIAL_MILESTONES[0], id: 'guitar_ms', goalId: secondGoal.id }], quests: [], resources: [{ id: 'guitar_resource', skill: 'Guitar' }], topics: [], comebackPlan: null },
  { goal: { ...secondGoal, id: 'other_user_goal', userId: 'another_user' }, milestones: [], quests: [], resources: [{ id: 'private_resource' }], topics: [], comebackPlan: null },
]));
storage.set('skillquest_active_goal_v2', JSON.stringify(secondGoal.id));
renderToString(React.createElement(SkillQuestProvider, null, React.createElement(Inspect)));
assert.equal(captured.goal.id, secondGoal.id);
assert.equal(captured.goals.length, 2);
assert.deepEqual(captured.resources.map(r => r.id), ['guitar_resource']);
storage.clear();

const today = localDate('Asia/Kolkata');
assert.match(today, /^\d{4}-\d{2}-\d{2}$/);
const assignments = createAssignments(INITIAL_GOAL, INITIAL_QUESTS, today);
assert.ok(assignments.length > 0);
assert.equal(assignments[0].sourceQuestId, INITIAL_QUESTS.find(q => q.status !== 'completed').id);
assert.equal(assignments[0].scheduledDate, today);
assert.equal(assignments[0].status, 'todo');
assert.ok(assignments[0].learningObjective && assignments[0].rubric.length);

const project = createMidwayProject(INITIAL_GOAL, INITIAL_MILESTONES, INITIAL_QUESTS);
assert.ok(project);
assert.equal(project.kind, 'midway');
assert.equal(project.prerequisiteMilestoneIds.length, Math.ceil(INITIAL_MILESTONES.length / 2));
assert.equal(midwayUnlocked(project, INITIAL_MILESTONES), false);
assert.equal(midwayUnlocked(project, INITIAL_MILESTONES.map(m => project.prerequisiteMilestoneIds.includes(m.id) ? { ...m, status: 'completed' } : m)), true);

const questions = fallbackDailyQuestions(INITIAL_GOAL, INITIAL_MILESTONES, INITIAL_QUESTS, INITIAL_QUIZ_QUESTIONS);
assert.equal(questions.length, 10);
assert.equal(new Set(questions.map(q => q.id)).size, 10);
assert.ok(questions.every(q => q.options[q.correctAnswer]));

const rubric = [{ criterion: 'Evidence' }];
assert.throws(() => validateEvaluation({ status: 'cleared', score: 100, criteriaMet: [], criteriaNotMet: ['Evidence'], feedback: 'ok', suggestions: [], recommendedNextAction: 'done' }, rubric));
assert.equal(validateEvaluation({ status: 'cleared', score: 90, criteriaMet: ['Evidence'], criteriaNotMet: [], feedback: 'ok', suggestions: [], recommendedNextAction: 'done' }, rubric).status, 'cleared');
assert.throws(() => validateNotesReview({ summary: 'Review', issues: [{ passage: 'invented', category: 'incorrect', explanation: 'x', suggestedCorrection: 'y', whyItMatters: 'z' }] }, 'Actual note'));
assert.equal(validateNotesReview({ summary: 'Review', issues: [{ passage: 'Actual note', category: 'clarify', explanation: 'x', suggestedCorrection: 'y', whyItMatters: 'z' }] }, 'Actual note').issues.length, 1);
assert.throws(() => evidenceParts('data:image/png;base64,SGVsbG8='));
assert.throws(() => pdfNoteParts('data:application/pdf;base64,SGVsbG8='));
const pdfBytes = Buffer.from('%PDF-1.4\n1 0 obj << /Type /Catalog >> endobj\nstartxref\n0\n%%EOF');
assert.equal(pdfNoteParts(`data:application/pdf;base64,${pdfBytes.toString('base64')}`)[0].inlineData.mimeType, 'application/pdf');
const twoPages = { summary: 'Two pages reviewed', pages: [{ pageNumber: 1, status: 'readable', extractedText: 'Flexbox aligns items.', message: '' }, { pageNumber: 2, status: 'unreadable', extractedText: '', message: 'Upload a clearer scan.' }], issues: [{ pageNumber: 1, passage: 'Flexbox aligns items.', category: 'correct', explanation: 'Accurate.', suggestedCorrection: '', whyItMatters: 'Shows understanding.' }] };
assert.equal(validatePdfNotesReview(twoPages).pages.length, 2);
assert.throws(() => validatePdfNotesReview({ ...twoPages, pages: [twoPages.pages[0], { ...twoPages.pages[1], pageNumber: 3 }] }));
assert.throws(() => validatePdfNotesReview({ ...twoPages, issues: [{ ...twoPages.issues[0], passage: 'Invented handwriting' }] }));

const originalFetch = globalThis.fetch;
let sawPdf = false;
globalThis.fetch = async (_url, options) => {
  const sent = JSON.parse(options.body);
  sawPdf = sent.contents[0].parts.some(part => part.inlineData?.mimeType === 'application/pdf');
  return { ok: true, json: async () => ({ candidates: [{ content: { parts: [{ text: JSON.stringify(twoPages) }] } }] }) };
};
try {
  const request = Readable.from([JSON.stringify({ content: `data:application/pdf;base64,${pdfBytes.toString('base64')}`, context: 'Flexbox lesson', skill: 'Web Development' })]);
  Object.assign(request, { method: 'POST', url: '/api/ai/notes/pdf', headers: { host: 'localhost:3000' } });
  const response = { status: 0, body: '', writeHead(status) { this.status = status; }, end(body) { this.body = body; } };
  await aiMiddleware({ GEMINI_API_KEY: 'test-key' })(request, response, () => { throw new Error('Unexpected next middleware'); });
  assert.equal(response.status, 200);
  assert.equal(JSON.parse(response.body).pages.length, 2);
  assert.equal(sawPdf, true);
} finally { globalThis.fetch = originalFetch; }
console.log('SkillQuest smoke checks passed.');
